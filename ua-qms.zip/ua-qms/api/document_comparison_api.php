<?php
/**
 * Document Comparison API
 * Feature 2: Admin can see previous and new documents and automatically view paired documents
 */

session_start();
include "../config/db.php";

header('Content-Type: application/json');

// Verify user is authenticated and is QMO Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'QMO Admin') {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized - Admin access required']);
    exit();
}

$action = $_GET['action'] ?? '';
$user_id = $_SESSION['user_id'];

// Get paired documents (previous and current versions)
if ($action === 'get_paired_documents') {
    $document_id = $_GET['document_id'] ?? null;

    if (!$document_id) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Missing document_id']);
        exit();
    }

    // Get current document
    $sql_current = "SELECT d.*, dt.doc_code, dt.description, o.office_name, o.office_code 
                    FROM documents d 
                    JOIN document_types dt ON d.doc_type_id = dt.doc_type_id 
                    JOIN offices o ON d.office_id = o.office_id 
                    WHERE d.document_id = ?";
    $stmt_current = $conn->prepare($sql_current);
    $stmt_current->bind_param("i", $document_id);
    $stmt_current->execute();
    $current_doc = $stmt_current->get_result()->fetch_assoc();

    if (!$current_doc) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Document not found']);
        exit();
    }

    // Get previous document (if exists)
    $previous_doc = null;
    if ($current_doc['previous_document_id']) {
        $sql_prev = "SELECT d.*, dt.doc_code, dt.description 
                     FROM documents d 
                     JOIN document_types dt ON d.doc_type_id = dt.doc_type_id 
                     WHERE d.document_id = ?";
        $stmt_prev = $conn->prepare($sql_prev);
        $stmt_prev->bind_param("i", $current_doc['previous_document_id']);
        $stmt_prev->execute();
        $previous_doc = $stmt_prev->get_result()->fetch_assoc();
    }

    // Get reviews for both documents
    $sql_reviews = "SELECT * FROM document_reviews WHERE document_id IN (?, ?) ORDER BY reviewed_at DESC";
    $stmt_reviews = $conn->prepare($sql_reviews);
    $prev_id = $current_doc['previous_document_id'] ?? 0;
    $stmt_reviews->bind_param("ii", $document_id, $prev_id);
    $stmt_reviews->execute();
    $reviews = [];
    while ($review = $stmt_reviews->get_result()->fetch_assoc()) {
        $reviews[] = $review;
    }

    echo json_encode([
        'success' => true,
        'current_document' => $current_doc,
        'previous_document' => $previous_doc,
        'reviews' => $reviews
    ]);
    exit();
}

// Get all paired documents for an office
if ($action === 'get_office_paired_documents') {
    $office_id = $_GET['office_id'] ?? null;

    if (!$office_id) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Missing office_id']);
        exit();
    }

    $sql = "SELECT d.document_id, d.file_name, d.status, d.submitted_at, d.version_number,
                   dt.doc_code, dt.description,
                   o.office_name, o.office_code,
                   prev_d.document_id as prev_doc_id, prev_d.file_name as prev_file_name
            FROM documents d
            JOIN document_types dt ON d.doc_type_id = dt.doc_type_id
            JOIN offices o ON d.office_id = o.office_id
            LEFT JOIN documents prev_d ON d.previous_document_id = prev_d.document_id
            WHERE d.office_id = ? AND d.previous_document_id IS NOT NULL
            ORDER BY d.submitted_at DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $office_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $paired_docs = [];
    while ($row = $result->fetch_assoc()) {
        $paired_docs[] = $row;
    }

    echo json_encode([
        'success' => true,
        'paired_documents' => $paired_docs,
        'count' => count($paired_docs)
    ]);
    exit();
}

// Create document comparison record
if ($action === 'create_comparison') {
    $previous_document_id = $_POST['previous_document_id'] ?? null;
    $current_document_id = $_POST['current_document_id'] ?? null;
    $admin_notes = $_POST['admin_notes'] ?? null;

    if (!$previous_document_id || !$current_document_id) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Missing document IDs']);
        exit();
    }

    // Link documents
    $sql_link = "UPDATE documents SET previous_document_id = ? WHERE document_id = ?";
    $stmt_link = $conn->prepare($sql_link);
    $stmt_link->bind_param("ii", $previous_document_id, $current_document_id);
    $stmt_link->execute();

    // Create comparison record
    $sql_comp = "INSERT INTO document_comparisons (previous_document_id, current_document_id, admin_notes, comparison_date) 
                 VALUES (?, ?, ?, NOW())";
    $stmt_comp = $conn->prepare($sql_comp);
    $stmt_comp->bind_param("iis", $previous_document_id, $current_document_id, $admin_notes);

    if ($stmt_comp->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Comparison created successfully',
            'comparison_id' => $conn->insert_id
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to create comparison']);
    }
    exit();
}

// Get comparison details
if ($action === 'get_comparison') {
    $comparison_id = $_GET['comparison_id'] ?? null;

    if (!$comparison_id) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Missing comparison_id']);
        exit();
    }

    $sql = "SELECT dc.*, 
                   prev_d.file_name as prev_file_name, prev_d.file_path as prev_file_path, prev_d.submitted_at as prev_submitted_at,
                   curr_d.file_name as curr_file_name, curr_d.file_path as curr_file_path, curr_d.submitted_at as curr_submitted_at
            FROM document_comparisons dc
            JOIN documents prev_d ON dc.previous_document_id = prev_d.document_id
            JOIN documents curr_d ON dc.current_document_id = curr_d.document_id
            WHERE dc.comparison_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $comparison_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($comparison = $result->fetch_assoc()) {
        echo json_encode([
            'success' => true,
            'comparison' => $comparison
        ]);
    } else {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Comparison not found']);
    }
    exit();
}

// Get all comparisons
if ($action === 'get_all_comparisons') {
    $limit = $_GET['limit'] ?? 50;
    $offset = $_GET['offset'] ?? 0;

    $sql = "SELECT dc.*, 
                   prev_d.file_name as prev_file_name, prev_d.status as prev_status,
                   curr_d.file_name as curr_file_name, curr_d.status as curr_status,
                   o.office_name, o.office_code
            FROM document_comparisons dc
            JOIN documents prev_d ON dc.previous_document_id = prev_d.document_id
            JOIN documents curr_d ON dc.current_document_id = curr_d.document_id
            JOIN offices o ON curr_d.office_id = o.office_id
            ORDER BY dc.comparison_date DESC
            LIMIT ? OFFSET ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $limit, $offset);
    $stmt->execute();
    $result = $stmt->get_result();

    $comparisons = [];
    while ($row = $result->fetch_assoc()) {
        $comparisons[] = $row;
    }

    // Get total count
    $sql_count = "SELECT COUNT(*) as total FROM document_comparisons";
    $count_result = $conn->query($sql_count);
    $count_row = $count_result->fetch_assoc();

    echo json_encode([
        'success' => true,
        'comparisons' => $comparisons,
        'total' => $count_row['total'],
        'limit' => $limit,
        'offset' => $offset
    ]);
    exit();
}

// Default response
http_response_code(400);
echo json_encode(['success' => false, 'message' => 'Invalid action']);
?>
