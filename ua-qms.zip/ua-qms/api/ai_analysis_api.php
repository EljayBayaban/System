<?php
/**
 * AI Analysis API
 * Handles Gemini API requests for the AI Compliance Consultant
 */

session_start();
include "../config/db.php";

header('Content-Type: application/json');

// Verify user is authenticated and is QMO Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'QMO Admin') {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$action = $_GET['action'] ?? '';

if ($action === 'generate_analysis') {
    $year = $_GET['year'] ?? '';
    $semester = $_GET['semester'] ?? '';

    if (!$year || !$semester) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Missing year or semester']);
        exit();
    }

    // 1. Fetch Gemini Settings
    $sql_settings = "SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ('gemini_api_key', 'gemini_model')";
    $result_settings = $conn->query($sql_settings);
    $settings = [];
    while ($row = $result_settings->fetch_assoc()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

    $api_key = $settings['gemini_api_key'] ?? '';
    $model_name = $settings['gemini_model'] ?? 'gemini-1.5-flash';

    if (!$api_key) {
        echo json_encode(['success' => false, 'message' => 'Gemini API Key not configured in System Settings.']);
        exit();
    }

    // 2. Gather Data for Prompt
    
    // Top 5 Performing Units for the selected period
    $top_units = [];
    $units_sql = "SELECT o.office_name, 
                  (SUM(CASE WHEN d.status = 'Approved' THEN 1 ELSE 0 END) / COUNT(dt.doc_type_id) * 100) as completion_rate
                  FROM offices o
                  CROSS JOIN document_types dt
                  LEFT JOIN documents d ON o.office_id = d.office_id 
                                       AND dt.doc_type_id = d.doc_type_id
                                       AND d.submitted_at LIKE ?
                  WHERE o.status = 'Active'
                  GROUP BY o.office_id
                  ORDER BY completion_rate DESC
                  LIMIT 5";
    $stmt_units = $conn->prepare($units_sql);
    $year_prefix = substr($year, 0, 4) . '%'; // Simple year filtering
    $stmt_units->bind_param("s", $year_prefix);
    $stmt_units->execute();
    $units_res = $stmt_units->get_result();
    while ($row = $units_res->fetch_assoc()) {
        $top_units[] = $row['office_name'] . " (" . round($row['completion_rate']) . "%)";
    }

    // Bottom 5 Performing Units for the selected period
    $bottom_units = [];
    $bottom_sql = "SELECT o.office_name, 
                  (SUM(CASE WHEN d.status = 'Approved' THEN 1 ELSE 0 END) / COUNT(dt.doc_type_id) * 100) as completion_rate
                  FROM offices o
                  CROSS JOIN document_types dt
                  LEFT JOIN documents d ON o.office_id = d.office_id 
                                       AND dt.doc_type_id = d.doc_type_id
                                       AND d.submitted_at LIKE ?
                  WHERE o.status = 'Active'
                  GROUP BY o.office_id
                  ORDER BY completion_rate ASC
                  LIMIT 5";
    $stmt_bottom = $conn->prepare($bottom_sql);
    $stmt_bottom->bind_param("s", $year_prefix);
    $stmt_bottom->execute();
    $bottom_res = $stmt_bottom->get_result();
    while ($row = $bottom_res->fetch_assoc()) {
        $bottom_units[] = $row['office_name'] . " (" . round($row['completion_rate']) . "%)";
    }

    // Major Document Bottlenecks for the selected period
    $bottlenecks = [];
    $bn_sql = "SELECT dt.doc_code, COUNT(dt.doc_type_id) as issue_count
               FROM document_types dt
               LEFT JOIN documents d ON dt.doc_type_id = d.doc_type_id 
                                     AND d.submitted_at LIKE ?
               WHERE d.status IN ('Awaiting Review', 'Revision', 'Not Submitted') OR d.document_id IS NULL
               GROUP BY dt.doc_code
               ORDER BY issue_count DESC
               LIMIT 3";
    $stmt_bn = $conn->prepare($bn_sql);
    $stmt_bn->bind_param("s", $year_prefix);
    $stmt_bn->execute();
    $bn_res = $stmt_bn->get_result();
    while ($row = $bn_res->fetch_assoc()) {
        $bottlenecks[] = $row['doc_code'] . " (" . $row['issue_count'] . " issues)";
    }

    // 3. Construct Prompt
    $top5_str = implode(', ', $top_units);
    $bottom5_str = implode(', ', $bottom_units);
    $bottlenecks_str = implode(', ', $bottlenecks);

    $prompt = "
        Context: University Quality Management System (UA QMS)
        Period: $year - $semester
        
        Data Summary:
        - Top 5 Performing Units: $top5_str
        - Bottom 5 Units (Delinquent): $bottom5_str
        - Major Document Bottlenecks: $bottlenecks_str
        
        System Instruction: You are a University QA Consultant. Provide a concise executive summary (approx 150-200 words) and 3 specific, actionable bulleted recommendations to improve compliance for the next period. Use a professional and encouraging tone.
    ";

    // 4. Call Gemini API via cURL
    $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model_name}:generateContent?key={$api_key}";

    $data = [
        "contents" => [
            [
                "parts" => [
                    ["text" => $prompt]
                ]
            ]
        ]
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code === 200) {
        $result = json_decode($response, true);
        $analysis_text = $result['candidates'][0]['content']['parts'][0]['text'] ?? 'Failed to parse AI response.';
        echo json_encode(['success' => true, 'analysis' => $analysis_text]);
    } else {
        $error_msg = "API Error (HTTP $http_code)";
        if ($response) {
            $error_data = json_decode($response, true);
            $error_msg .= ": " . ($error_data['error']['message'] ?? 'Unknown error');
        }
        echo json_encode(['success' => false, 'message' => $error_msg]);
    }
    exit();
}

http_response_code(400);
echo json_encode(['success' => false, 'message' => 'Invalid action']);
