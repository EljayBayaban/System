<?php
session_start();
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

// Security: Make sure the user is an Admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'QMO Admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized Access']);
    exit();
}

// Determine Action
$action = $_GET['action'] ?? '';

// Read JSON input for POST requests
$input = json_decode(file_get_contents('php://input'), true);

// Utility function to log actions
function addLog($conn, $action, $details) {
    $user_id = $_SESSION['user_id'] ?? null;
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $stmt = $conn->prepare("INSERT INTO system_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $action, $details, $ip_address);
    $stmt->execute();
}

switch ($action) {
    
    // 1. Get Deadlines
    case 'get_deadlines':
        $sql = "SELECT ts.target_id, dt.doc_code, dt.description, ts.deadline, ts.quarter, ts.year 
                FROM target_submissions ts 
                JOIN document_types dt ON ts.doc_type_id = dt.doc_type_id 
                ORDER BY ts.deadline ASC";
        $result = $conn->query($sql);
        $deadlines = [];
        while ($row = $result->fetch_assoc()) {
            $deadlines[] = $row;
        }
        echo json_encode(['success' => true, 'deadlines' => $deadlines]);
        break;

    // 2. Update Deadline
    case 'update_deadline':
        $target_id = $input['target_id'] ?? null;
        $deadline = $input['deadline'] ?? null;
        
        if ($target_id && $deadline) {
            $stmt = $conn->prepare("UPDATE target_submissions SET deadline = ? WHERE target_id = ?");
            $stmt->bind_param("si", $deadline, $target_id);
            if ($stmt->execute()) {
                addLog($conn, "Deadline Updated", "Target ID $target_id deadline moved to $deadline");
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Update failed']);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Missing data']);
        }
        break;

    // 3. Get Logs
    case 'get_logs':
        $sql = "SELECT * FROM system_logs ORDER BY created_at DESC LIMIT 50";
        $result = $conn->query($sql);
        $logs = [];
        while ($row = $result->fetch_assoc()) {
            $logs[] = $row;
        }
        echo json_encode(['success' => true, 'logs' => $logs]);
        break;

    // 4. Update Academic Period
    case 'update_period':
        $year = $input['year'] ?? '';
        $semester = $input['semester'] ?? '';
        
        // Update system_settings table
        $stmt = $conn->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'active_academic_year'");
        $stmt->bind_param("s", $year);
        $stmt->execute();
        
        $stmt = $conn->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'active_semester'");
        $stmt->bind_param("s", $semester);
        $stmt->execute();
        
        addLog($conn, "Academic Lifecycle Updated", "Set to $semester, AY $year");
        echo json_encode(['success' => true]);
        break;

    // 5. Toggle Maintenance Mode
    case 'toggle_maintenance':
        $status = $input['status'] ? 'Enabled' : 'Disabled';
        $val = $input['status'] ? '1' : '0';
        
        $stmt = $conn->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'maintenance_mode'");
        $stmt->bind_param("s", $val);
        $stmt->execute();
        
        addLog($conn, "Maintenance Mode Toggled", "Maintenance mode was $status");
        echo json_encode(['success' => true]);
        break;

    // 6. Save AI Configuration
    case 'save_ai_config':
        $api_key = $input['api_key'] ?? '';
        $model = $input['model'] ?? '';
        
        $stmt = $conn->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'gemini_api_key'");
        $stmt->bind_param("s", $api_key);
        $stmt->execute();
        
        $stmt = $conn->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'gemini_model'");
        $stmt->bind_param("s", $model);
        $stmt->execute();
        
        addLog($conn, "AI Settings Updated", "Changed AI Model to $model");
        echo json_encode(['success' => true]);
        break;

    // 7. Test AI Connection (Gemini)
    case 'test_gemini':
        // Fetch the saved API key and model from system_settings
        $sql_key = "SELECT setting_value FROM system_settings WHERE setting_key = 'gemini_api_key'";
        $result_key = $conn->query($sql_key);
        $row_key = $result_key->fetch_assoc();
        $api_key = $row_key['setting_value'] ?? '';
        
        $sql_model = "SELECT setting_value FROM system_settings WHERE setting_key = 'gemini_model'";
        $result_model = $conn->query($sql_model);
        $row_model = $result_model->fetch_assoc();
        $model = $row_model['setting_value'] ?? 'gemini-1.5-flash';
        
        if (!$api_key) {
            addLog($conn, "AI Connectivity Test Failed", "No API key configured");
            echo json_encode(['success' => false, 'message' => 'No API key configured. Please save your Gemini API key first.']);
            break;
        }
        
        // Test the connection with a simple API call
        $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$api_key}";
        $test_data = [
            "contents" => [
                [
                    "parts" => [
                        ["text" => "Test connection"]
                    ]
                ]
            ]
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($test_data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        
        $start_time = microtime(true);
        $response = curl_exec($ch);
        $elapsed = round((microtime(true) - $start_time) * 1000);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 200) {
            addLog($conn, "AI Connectivity Test", "Successfully connected to Gemini API (${elapsed}ms)");
            echo json_encode(['success' => true, 'message' => "Connected to Google Gemini API successfully (${elapsed}ms)"]);
        } else {
            $error_msg = "Connection failed (HTTP $http_code)";
            if ($response) {
                $error_data = json_decode($response, true);
                $error_msg = $error_data['error']['message'] ?? $error_msg;
            }
            addLog($conn, "AI Connectivity Test Failed", $error_msg);
            echo json_encode(['success' => false, 'message' => $error_msg]);
        }
        break;

    // 8. Blast Announcement
    case 'blast_announcement':
        $title = $input['title'] ?? '';
        $message_text = $input['message'] ?? '';
        $sender_id = $_SESSION['user_id'];
        
        if ($title && $message_text) {
            $conn->begin_transaction();
            try {
                // Create a new conversation for the announcement
                $stmt = $conn->prepare("INSERT INTO conversations () VALUES ()");
                $stmt->execute();
                $conversation_id = $conn->insert_id;
                $stmt->close();

                // Get all Unit/Office heads (Dean, Office, RMO, HMO) and QMO Admin (sender)
                $sql = "SELECT user_id FROM users WHERE role IN ('Dean', 'Office', 'RMO', 'HMO', 'QMO Admin') AND status = 'Active'";
                $result = $conn->query($sql);
                
                $recipients_count = 0;
                if ($result->num_rows > 0) {
                    $participant_values = [];
                    $participant_types = '';
                    while ($row = $result->fetch_assoc()) {
                        $participant_values[] = $conversation_id;
                        $participant_values[] = $row['user_id'];
                        $participant_types .= 'ii';
                        $recipients_count++;
                    }
                    // Add sender to participants if not already included
                    if (!in_array($sender_id, array_column($result->fetch_all(MYSQLI_ASSOC), 'user_id'))) {
                         $participant_values[] = $conversation_id;
                         $participant_values[] = $sender_id;
                         $participant_types .= 'ii';
                         $recipients_count++;
                    }

                    $stmt = $conn->prepare("INSERT INTO conversation_participants (conversation_id, user_id) VALUES " . implode(", ", array_fill(0, $recipients_count, "(?, ?)")));
                    $stmt->bind_param($participant_types, ...$participant_values);
                    $stmt->execute();
                    $stmt->close();
                }

                // Insert the announcement message
                $stmt = $conn->prepare("INSERT INTO messages (conversation_id, sender_id, message_text, status) VALUES (?, ?, ?, 'sent')");
                $stmt->bind_param("iis", $conversation_id, $sender_id, $message_text);
                $stmt->execute();
                $stmt->close();

                // Update last_message_at for the conversation
                $stmt = $conn->prepare("UPDATE conversations SET last_message_at = CURRENT_TIMESTAMP WHERE conversation_id = ?");
                $stmt->bind_param("i", $conversation_id);
                $stmt->execute();
                $stmt->close();

                $conn->commit();
                addLog($conn, "Announcement Blasted", "Title: $title. Sent to $recipients_count recipients in conversation $conversation_id.");
                echo json_encode(['success' => true, 'count' => $recipients_count, 'conversation_id' => $conversation_id]);
            } catch (mysqli_sql_exception $e) {
                $conn->rollback();
                addLog($conn, "Announcement Blast Failed", "Error: " . $e->getMessage());
                echo json_encode(['success' => false, 'error' => 'Failed to blast announcement: ' . $e->getMessage()]);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Missing fields']);
        }
        break;

    // 9. Notify Individual Unit
    case 'notify_unit':
        $target_id = $input['target_id'] ?? '';
        $sender_id = $_SESSION['user_id'] ?? null;
        $receiver_id = $input['receiver_id'] ?? null; // Assuming receiver_id is passed for individual notification

        if (!$target_id || !$sender_id || !$receiver_id) {
            echo json_encode(['success' => false, 'error' => 'Missing required parameters']);
            break;
        }
        
        $conn->begin_transaction();
        try {
            // Get the document code and deadline info from target_submissions
            $sql_target = "SELECT dt.doc_code, ts.deadline 
                           FROM target_submissions ts
                           JOIN document_types dt ON ts.doc_type_id = dt.doc_type_id 
                           WHERE ts.target_id = ?";
            $stmt_target = $conn->prepare($sql_target);
            $stmt_target->bind_param("i", $target_id);
            $stmt_target->execute();
            $res_target = $stmt_target->get_result();
            
            if (!($row_target = $res_target->fetch_assoc())) {
                echo json_encode(['success' => false, 'error' => 'Target submission not found']);
                exit;
            }
            
            $doc_code = $row_target['doc_code'];
            $deadline = $row_target['deadline'];
            
            $message_text = "This is a reminder regarding the deadline for $doc_code. The deadline is $deadline. Please ensure timely submission.";

            // Find or create conversation
            $conversation_id = null;
            $stmt = $conn->prepare("SELECT cp1.conversation_id FROM conversation_participants cp1 JOIN conversation_participants cp2 ON cp1.conversation_id = cp2.conversation_id WHERE cp1.user_id = ? AND cp2.user_id = ?");
            $stmt->bind_param("ii", $sender_id, $receiver_id);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $conversation_id = $row['conversation_id'];
            } else {
                // Create new conversation
                $stmt = $conn->prepare("INSERT INTO conversations () VALUES ()");
                $stmt->execute();
                $conversation_id = $conn->insert_id;
                $stmt->close();

                // Add participants
                $stmt = $conn->prepare("INSERT INTO conversation_participants (conversation_id, user_id) VALUES (?, ?), (?, ?)");
                $stmt->bind_param("iiii", $conversation_id, $sender_id, $conversation_id, $receiver_id);
                $stmt->execute();
                $stmt->close();
            }

            // Insert message
            $stmt = $conn->prepare("INSERT INTO messages (conversation_id, sender_id, message_text, status) VALUES (?, ?, ?, 'sent')");
            $stmt->bind_param("iis", $conversation_id, $sender_id, $message_text);
            $stmt->execute();
            $stmt->close();

            // Update last_message_at for the conversation
            update_last_message_at($conn, $conversation_id);

            $conn->commit();
            addLog($conn, "Unit Notified", "Sent deadline reminder for $doc_code (Target ID $target_id) to user $receiver_id in conversation $conversation_id.");
            echo json_encode(['success' => true, 'conversation_id' => $conversation_id]);
        } catch (mysqli_sql_exception $e) {
            $conn->rollback();
            addLog($conn, "Unit Notification Failed", "Error: " . $e->getMessage());
            echo json_encode(['success' => false, 'error' => 'Failed to notify unit: ' . $e->getMessage()]);
        }
        break;

    // Default Fallback
    default:
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
        break;
}
?>
