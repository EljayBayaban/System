<?php
session_start();
include "config/db.php";

$message = "";

if (isset($_POST['submit'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=? AND status='Active'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['office_id'] = $user['office_id'] ?? null;

            // Redirect based on role
            if($user['role'] === 'QMO Admin'){
                header("Location: dashboard/qmo/index.php");
            } elseif($user['role'] === 'Office' || $user['role'] === 'Dean'){
                // Both Office (Unit/Office Head) and Dean roles go to Dean Dashboard
                header("Location: dashboard/dean/index.php");
            } else {
                // Default redirect for other roles
                header("Location: dashboard/qmo/index.php");
            }
            exit();
        } else {
            $message = "Invalid password!";
        }
    } else {
        $message = "Email not found or inactive!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>UA QMS | Login</title>
    <link rel="stylesheet" href="assets/css/login.css">
</head>
<body>
<div class="container">
    <div class="login-box">
        <img src="assets/img/ua-qms-logo.jpg" alt="UA Logo">
        <h2>Login</h2>
        <?php if($message) { echo "<p class='error'>".htmlspecialchars($message)."</p>"; } ?>
        <form method="POST">
            <input type="email" name="email" placeholder="user@ua.edu.ph" required>
            <input type="password" name="password" placeholder="••••••••" required>
            <button type="submit" name="submit">Sign In</button>
        </form>
        <p><a href="auth/forgot-password.php">Forgot Password?</a></p>
        <p>Don't have an account? <a href="auth/register.php">Register</a></p>
    </div>
</div>
</body>
</html>
