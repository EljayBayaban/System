<?php
if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'QMO Admin') {
    header("Location: ../../index.php");
    exit;
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!-- Sidebar -->
<aside class="w-64 bg-maroon border-r border-gray-200 flex-shrink-0 hidden md:flex flex-col z-20 shadow-sm">
    
    <!-- Logo & Branding -->
    <div class="p-6 flex items-center gap-3 border-b border-gray-50">
        <img src="../../assets/img/ua-qms-logo.jpg" alt="UA Logo" class="w-10 h-10 rounded-full shadow-sm">
        <span class="font-bold text-xl text-ua-maroon tracking-wide">UA QMS</span>
    </div>
    
    <!-- Navigation Links -->
    <nav class="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
        
        <p class="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-3 px-2">Main</p>
        <a href="index.php" class="flex items-center px-3 py-2.5 <?php echo $current_page == 'index.php' ? 'bg-ua-maroon text-white shadow-md' : 'text-gray-700 hover:bg-red-50 hover:text-ua-maroon hover:translate-x-1'; ?> rounded-lg transition-all duration-200 group">
            <i class="fas fa-chart-line w-6 text-center opacity-90 group-hover:opacity-100 transition-opacity"></i> 
            <span class="font-medium ml-1">Dashboard</span>
        </a>
        
        <p class="text-[11px] font-bold text-gray-400 uppercase tracking-wider mt-6 mb-3 px-2">Management</p>
        <a href="monitoring.php" class="flex items-center px-3 py-2.5 <?php echo $current_page == 'monitoring.php' ? 'bg-[#800000] text-white shadow-md' : 'text-gray-700 hover:bg-red-50 hover:text-ua-maroon hover:translate-x-1'; ?> rounded-lg transition-all duration-200 group">
            <i class="fas fa-eye w-6 text-center opacity-90 group-hover:opacity-100 transition-opacity"></i> 
            <span class="font-medium ml-1">Monitoring</span>
        </a>
        <a href="review_submissions.php" class="flex items-center px-3 py-2.5 <?php echo $current_page == 'review_submissions.php' ? 'bg-ua-maroon text-white shadow-md' : 'text-gray-700 hover:bg-red-50 hover:text-ua-maroon hover:translate-x-1'; ?> rounded-lg transition-all duration-200 group">
            <i class="fas fa-check-square w-6 text-center opacity-90 group-hover:opacity-100 transition-opacity"></i> 
            <span class="font-medium ml-1">Review Submissions</span>
        </a>

        <p class="text-[11px] font-bold text-gray-400 uppercase tracking-wider mt-6 mb-3 px-2">Analytics & Reporting</p>
        <a href="document_comparison.php" class="flex items-center px-3 py-2.5 <?php echo $current_page == 'document_comparison.php' ? 'bg-ua-maroon text-white shadow-md' : 'text-gray-700 hover:bg-red-50 hover:text-ua-maroon hover:translate-x-1'; ?> rounded-lg transition-all duration-200 group">
            <i class="fas fa-code-branch w-6 text-center opacity-90 group-hover:opacity-100 transition-opacity"></i> 
            <span class="font-medium ml-1">Document Comparison</span>
        </a>
        <a href="target_achievement.php" class="flex items-center px-3 py-2.5 <?php echo $current_page == 'target_achievement.php' ? 'bg-ua-maroon text-white shadow-md' : 'text-gray-700 hover:bg-red-50 hover:text-ua-maroon hover:translate-x-1'; ?> rounded-lg transition-all duration-200 group">
            <i class="fas fa-bullseye w-6 text-center opacity-90 group-hover:opacity-100 transition-opacity"></i> 
            <span class="font-medium ml-1">Target Achievement</span>
        </a>

        <p class="text-[11px] font-bold text-gray-400 uppercase tracking-wider mt-6 mb-3 px-2">Administration</p>
        <a href="repository.php" class="flex items-center px-3 py-2.5 <?php echo $current_page == 'repository.php' ? 'bg-[#800000] text-white shadow-md' : 'text-gray-700 hover:bg-red-50 hover:text-ua-maroon hover:translate-x-1'; ?> rounded-lg transition-all duration-200 group">
            <i class="fas fa-eye w-6 text-center opacity-90 group-hover:opacity-100 transition-opacity"></i> 
            <span class="font-medium ml-1">Repository</span>
        </a>
        <a href="manage_accounts.php" class="flex items-center px-3 py-2.5 <?php echo $current_page == 'manage_accounts.php' ? 'bg-ua-maroon text-white shadow-md' : 'text-gray-700 hover:bg-red-50 hover:text-ua-maroon hover:translate-x-1'; ?> rounded-lg transition-all duration-200 group">
            <i class="fas fa-users w-6 text-center opacity-90 group-hover:opacity-100 transition-opacity"></i> 
            <span class="font-medium ml-1">Manage Accounts</span>
        </a>
        <a href="settings.php" class="flex items-center px-3 py-2.5 <?php echo $current_page == 'settings.php' ? 'bg-primary-light text-white shadow-md' : 'text-gray-700 hover:bg-red-50 hover:text-ua-maroon hover:translate-x-1'; ?> rounded-lg transition-all duration-200 group">
            <i class="fas fa-cog w-6 text-center opacity-90 group-hover:opacity-100 transition-opacity"></i> 
            <span class="font-medium ml-1">Settings</span>
        </a>

    </nav>
</aside>

<!-- Profile Dropdown Menu Styles -->
<style>
    .profile-dropdown {
        display: none;
        position: absolute;
        top: 100%;
        right: 0;
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        z-index: 50;
        min-width: 220px;
        margin-top: 8px;
    }
    .profile-dropdown.active {
        display: block;
    }
    .profile-dropdown-header {
        padding: 12px 16px;
        border-bottom: 1px solid #e5e7eb;
    }
    .profile-dropdown-header p {
        margin: 0;
        font-weight: 600;
        color: #111827;
        font-size: 14px;
    }
    .profile-dropdown-header span {
        display: block;
        font-size: 12px;
        color: #6b7280;
        margin-top: 2px;
    }
    .profile-dropdown-item {
        display: flex;
        align-items: center;
        padding: 12px 16px;
        color: #374151;
        text-decoration: none;
        transition: background-color 0.2s;
        border: none;
        background: none;
        width: 100%;
        text-align: left;
        cursor: pointer;
        font-size: 14px;
    }
    .profile-dropdown-item:hover {
        background-color: #f3f4f6;
    }
    .profile-dropdown-item.logout {
        color: #dc2626;
        border-top: 1px solid #e5e7eb;
    }
    .profile-dropdown-item.logout:hover {
        background-color: #fee2e2;
    }
    .profile-dropdown-item i {
        margin-right: 12px;
        width: 16px;
        text-align: center;
    }
</style>
