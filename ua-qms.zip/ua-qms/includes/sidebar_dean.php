<?php
if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'Dean' && $_SESSION['role'] !== 'Office')) {
    header("Location: ../../index.php");
    exit;
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!-- Sidebar -->
<aside class="w-64 bg-white border-r border-gray-200 flex-shrink-0 hidden md:flex flex-col">
    <div class="p-6 flex items-center gap-3">
        <img src="../../assets/img/ua-qms-logo.jpg" alt="UA Logo" class="w-10 h-10 rounded-full">
        <span class="font-bold text-xl text-ua-maroon">UA QMS</span>
    </div>
    <nav class="flex-1 px-4 space-y-1 overflow-y-auto">
        <p class="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 px-2">Main</p>
        <a href="index.php" class="flex items-center px-3 py-2 <?php echo $current_page == 'index.php' ? 'bg-ua-maroon text-white' : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'; ?> rounded-lg transition">
            <i class="fas fa-chart-line w-6"></i> Dashboard
        </a>
        
        <p class="text-xs font-semibold text-gray-400 uppercase tracking-wider mt-6 mb-2 px-2">Operations</p>
        <a href="submit_document.php" class="flex items-center px-3 py-2 <?php echo $current_page == 'submit_document.php' ? 'bg-ua-maroon text-white' : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'; ?> rounded-lg transition">
            <i class="fas fa-upload w-6"></i> Submit Documents
        </a>
        <a href="my_submissions.php" class="flex items-center px-3 py-2 <?php echo $current_page == 'my_submissions.php' ? 'bg-ua-maroon text-white' : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'; ?> rounded-lg transition">
            <i class="fas fa-folder-open w-6"></i> My Submissions
        </a>
        <a href="compliance_status.php" class="flex items-center px-3 py-2 <?php echo $current_page == 'compliance_status.php' ? 'bg-ua-maroon text-white' : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'; ?> rounded-lg transition">
            <i class="fas fa-check-circle w-6"></i> Compliance Status
        </a>

    </nav>
</aside>

<!-- Profile Dropdown Menu Styles -->
<style>
    .profile-dropdown {
        display: none;
        position: absolute;
        top: 100%;
        right: 0;
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        z-index: 50;
        min-width: 200px;
        margin-top: 8px;
    }
    .profile-dropdown.active {
        display: block;
    }
    .profile-dropdown-header {
        padding: 12px 16px;
        border-bottom: 1px solid #e5e7eb;
    }
    .profile-dropdown-header p {
        margin: 0;
        font-weight: 600;
        color: #111827;
        font-size: 14px;
    }
    .profile-dropdown-header span {
        display: block;
        font-size: 12px;
        color: #6b7280;
        margin-top: 2px;
    }
    .profile-dropdown-item {
        display: flex;
        align-items: center;
        padding: 12px 16px;
        color: #374151;
        text-decoration: none;
        transition: background-color 0.2s;
        border: none;
        background: none;
        width: 100%;
        text-align: left;
        cursor: pointer;
        font-size: 14px;
    }
    .profile-dropdown-item:hover {
        background-color: #f3f4f6;
    }
    .profile-dropdown-item.logout {
        color: #dc2626;
        border-top: 1px solid #e5e7eb;
    }
    .profile-dropdown-item.logout:hover {
        background-color: #fee2e2;
    }
    .profile-dropdown-item i {
        margin-right: 12px;
        width: 16px;
        text-align: center;
    }
</style>
