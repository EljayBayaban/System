<?php
session_start();
include "../config/db.php";

$message = "";
$show_form = false;

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE password_reset_token=? AND token_expiry > NOW() AND status='Active'");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $show_form = true;
        $user = $result->fetch_assoc();

        if (isset($_POST['submit'])) {
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];

            if ($password !== $confirm_password) {
                $message = "Passwords do not match!";
            } elseif (strlen($password) < 6) {
                $message = "Password must be at least 6 characters!";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $update = $conn->prepare("UPDATE users SET password=?, password_reset_token=NULL, token_expiry=NULL WHERE user_id=?");
                $update->bind_param("si", $hashed_password, $user['user_id']);
                $update->execute();

                $message = "Password updated successfully! <a href='../index.php'>Login</a>";
                $show_form = false;
            }
        }
    } else {
        $message = "Invalid or expired token!";
    }
} else {
    $message = "No token provided!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password | UA QMS</title>
    <link rel="stylesheet" href="../assets/css/login.css">
</head>
<body>
<div class="login-container">
    <h2>Reset Password</h2>
    <?php if($message) { echo "<p>".htmlspecialchars($message)."</p>"; } ?>
    <?php if($show_form): ?>
    <form method="POST">
        <input type="password" name="password" placeholder="New Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <button type="submit" name="submit">Reset Password</button>
    </form>
    <?php endif; ?>
    <a href="../index.php">Back to Login</a>
</div>
</body>
</html>
