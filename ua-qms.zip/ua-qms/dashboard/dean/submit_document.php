<?php
session_start();
include "../../config/db.php";
require_once "../../includes/file-type-detector.php";
require_once "../../includes/convert-to-pdf.php";

/**
 * Helper function to trigger a notification
 */
function triggerNotification($user_id, $title, $message, $type = 'System', $conn) {
    $sql_notif = "INSERT INTO notifications (title, message, type) VALUES (?, ?, ?)";
    $stmt_notif = $conn->prepare($sql_notif);
    $stmt_notif->bind_param("sss", $title, $message, $type);
    
    if ($stmt_notif->execute()) {
        $notification_id = $conn->insert_id;
        $sql_user_notif = "INSERT INTO user_notifications (user_id, notification_id) VALUES (?, ?)";
        $stmt_user_notif = $conn->prepare($sql_user_notif);
        $stmt_user_notif->bind_param("ii", $user_id, $notification_id);
        return $stmt_user_notif->execute();
    }
    return false;
}

// Initialize submission token to prevent double-post on refresh
if (!isset($_SESSION['submit_token'])) {
    $_SESSION['submit_token'] = bin2hex(random_bytes(32));
}

if (!isset($_SESSION['role']) || ($_SESSION['role'] != 'Dean' && $_SESSION['role'] != 'Office')) {
    header('Location: ../../index.php');
    exit();
}

$office_id = $_SESSION['office_id'] ?? null;
$re_submit_id = $_GET['re-submit'] ?? null;
$previous_version = null;

// CRITICAL FIX: Handle missing office_id
// If office_id is not set, attempt to retrieve it from the database
if (!$office_id) {
    $user_id = $_SESSION['user_id'] ?? null;
    if ($user_id) {
        $sql_user = "SELECT office_id FROM users WHERE user_id = ?";
        $stmt_user = $conn->prepare($sql_user);
        $stmt_user->bind_param("i", $user_id);
        $stmt_user->execute();
        $user_result = $stmt_user->get_result();
        if ($user_row = $user_result->fetch_assoc()) {
            $office_id = $user_row['office_id'];
            // Update session with retrieved office_id
            $_SESSION['office_id'] = $office_id;
        }
    }
}

// If re-submitting, fetch previous version details for Comparison Mode
if ($re_submit_id) {
    $sql_prev = "SELECT d.*, dt.doc_code, dr.remarks 
                 FROM documents d 
                 JOIN document_types dt ON d.doc_type_id = dt.doc_type_id
                 LEFT JOIN document_reviews dr ON d.document_id = dr.document_id
                 WHERE d.document_id = ? AND d.office_id = ?
                 ORDER BY dr.review_id DESC LIMIT 1";
    $stmt_prev = $conn->prepare($sql_prev);
    $stmt_prev->bind_param("ii", $re_submit_id, $office_id);
    $stmt_prev->execute();
    $previous_version = $stmt_prev->get_result()->fetch_assoc();
}

// Fetch available document types
$doc_types = [];
$res_types = $conn->query("SELECT * FROM document_types WHERE required = 'Yes'");
while($row = $res_types->fetch_assoc()) {
    $doc_types[] = $row;
}

// Handle Form Submission
$message = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check for duplicate submission via token
    if (!isset($_POST['submit_token']) || $_POST['submit_token'] !== $_SESSION['submit_token']) {
        $message = "Error: Duplicate submission detected or session expired.";
    } else {
        // Refresh token for next submission
        $_SESSION['submit_token'] = bin2hex(random_bytes(32));
        
        $doc_type_id = $_POST['doc_type_id'];
        $file = $_FILES['document_file'];
    
    // Server-side validation
    $allowed_exts = ['pdf', 'docx', 'xlsx', 'jpg', 'jpeg', 'png'];
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $max_size = 10 * 1024 * 1024; // 10MB

    if (!in_array($file_ext, $allowed_exts)) {
        $message = "Error: Invalid file format. Only PDF, DOCX, XLSX, JPG, PNG are allowed.";
    } elseif ($file['size'] > $max_size) {
        $message = "Error: File size exceeds 10MB limit.";
    } else {
        // Process upload
        $upload_dir = "../../uploads/documents/";
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        
        $new_filename = time() . "_" . basename($file['name']);
        $target_path = $upload_dir . $new_filename;
        
        if (move_uploaded_file($file['tmp_name'], $target_path)) {
            // CRITICAL FIX: Enhanced office_id validation with detailed error handling
            if (!$office_id) {
                // Attempt to auto-assign default office if available
                $sql_default_office = "SELECT office_id FROM offices WHERE status = 'Active' LIMIT 1";
                $result_default = $conn->query($sql_default_office);
                if ($result_default && $result_default->num_rows > 0) {
                    $default_office = $result_default->fetch_assoc();
                    $office_id = $default_office['office_id'];
                    $_SESSION['office_id'] = $office_id;
                    $message = "Warning: Office ID was not set. Auto-assigned to default office. Please contact administrator to verify.";
                } else {
                    $message = "Error: Office ID not found in session and no default office available. Please contact administrator to set up your office assignment.";
                    // Log this critical error
                    error_log("CRITICAL: User {$_SESSION['user_id']} ({$_SESSION['full_name']}) attempted to submit document without office assignment.");
                }
            }
            
            if ($office_id) {
                $preview_path = NULL;
                $fileInfo = FileTypeDetector::detectFileType($target_path);

                // If it's an office document, convert to PDF
                if ($fileInfo['type'] === 'office') {
                    $preview_dir = "../../uploads/previews/";
                    if (!is_dir($preview_dir)) mkdir($preview_dir, 0777, true);
                    $converted_pdf_path = PdfConverter::convertToPdf($target_path, $preview_dir);
                    if ($converted_pdf_path) {
                        $preview_path = $converted_pdf_path;
                    } else {
                        // Log error, but still proceed with original file
                        error_log("Failed to convert Office document to PDF: " . $target_path);
                    }
                }

                $sql_insert = "INSERT INTO documents (office_id, doc_type_id, file_name, file_path, preview_path, status) VALUES (?, ?, ?, ?, ?, 'Awaiting Review')";
                $stmt_ins = $conn->prepare($sql_insert);
                $stmt_ins->bind_param("iisss", $office_id, $doc_type_id, $file['name'], $target_path, $preview_path);
                
                if ($stmt_ins->execute()) {
                    $message = "Success: Document submitted successfully!";
                    
                    // Get the newly inserted document ID for routing
                    $new_document_id = $stmt_ins->insert_id;
                    
                    // Trigger Notification for QMO Admin
                    $office_name = "Unknown Unit";
                    $sql_off_name = "SELECT office_name FROM offices WHERE office_id = ?";
                    $stmt_off_name = $conn->prepare($sql_off_name);
                    $stmt_off_name->bind_param("i", $office_id);
                    $stmt_off_name->execute();
                    $off_res = $stmt_off_name->get_result()->fetch_assoc();
                    if ($off_res) $office_name = $off_res['office_name'];

                    $doc_type_code = "Document";
                    $sql_dt_code = "SELECT doc_code FROM document_types WHERE doc_type_id = ?";
                    $stmt_dt_code = $conn->prepare($sql_dt_code);
                    $stmt_dt_code->bind_param("i", $doc_type_id);
                    $stmt_dt_code->execute();
                    $dt_res = $stmt_dt_code->get_result()->fetch_assoc();
                    if ($dt_res) $doc_type_code = $dt_res['doc_code'];

                    $notif_title = "New Submission: " . $office_name;
                    $notif_msg = "A new " . $doc_type_code . " has been submitted and is awaiting review.";
                    
                    // Find QMO Admin users
                    $sql_qmo = "SELECT user_id FROM users WHERE role = 'QMO Admin' AND status = 'Active'";
                    $qmo_res = $conn->query($sql_qmo);
                    while ($qmo = $qmo_res->fetch_assoc()) {
                        // Create notification with routing metadata
                        $sql_notif = "INSERT INTO notifications (title, message, type, target_url, target_type, related_document_id) VALUES (?, ?, ?, ?, ?, ?)";
                        $stmt_notif = $conn->prepare($sql_notif);
                        $target_url = "dashboard/qmo/review_submissions.php?id=" . $new_document_id;
                        $target_type = "review";
                        $notif_type = "System";
                        $stmt_notif->bind_param("sssssi", $notif_title, $notif_msg, $notif_type, $target_url, $target_type, $new_document_id);
                        
                        if ($stmt_notif->execute()) {
                            $notification_id = $conn->insert_id;
                            $sql_user_notif = "INSERT INTO user_notifications (user_id, notification_id) VALUES (?, ?)";
                            $stmt_user_notif = $conn->prepare($sql_user_notif);
                            $stmt_user_notif->bind_param("ii", $qmo['user_id'], $notification_id);
                            $stmt_user_notif->execute();
                        }
                    }
                } else {
                    $message = "Error: Database error - " . $conn->error;
                }
            }
        } else {
            $message = "Error: Failed to upload file.";
        }
    }
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Document | UA QMS</title>
    <link rel="stylesheet" href="../../assets/css/dashboard.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="../../assets/js/messaging.js" defer></script>
    <script src="../../assets/js/notifications.js" defer></script>
    <style>
        :root {
            --ua-maroon: #800000;
            --ua-gold: #FFD700;
            --ua-green: #006400;
        }
        .bg-ua-maroon { background-color: var(--ua-maroon); }
        .text-ua-maroon { color: var(--ua-maroon); }
        .border-ua-maroon { border-color: var(--ua-maroon); }
        
        /* Modal Styles */
        #successModal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease-in-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        .modal-content {
            background-color: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            max-width: 500px;
            width: 90%;
            text-align: center;
            animation: slideUp 0.3s ease-out;
        }

        @keyframes slideUp {
            from {
                transform: translateY(30px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .modal-icon {
            font-size: 60px;
            color: var(--ua-green);
            margin-bottom: 20px;
        }

        .modal-title {
            font-size: 24px;
            font-weight: bold;
            color: var(--ua-maroon);
            margin-bottom: 10px;
        }

        .modal-message {
            font-size: 16px;
            color: #666;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        .modal-button {
            background-color: var(--ua-maroon);
            color: white;
            padding: 12px 40px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }

        .modal-button:hover {
            background-color: #600000;
        }
    </style>
</head>
<body class="bg-gray-50 font-sans">
    <div class="flex h-screen overflow-hidden">
        <?php include "../../includes/sidebar_dean.php"; ?>

        <!-- Main Content -->
        <main class="flex-1 flex flex-col overflow-hidden">
            <!-- Topbar with Profile Icon -->
            <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 flex-shrink-0">
                <h1 class="text-xl font-bold text-gray-800">Submit Document</h1>
                <div class="flex items-center gap-6">
                    <div class="flex items-center gap-2">
                        <!-- Message Inbox -->
                        <button id="inbox-btn" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-envelope text-lg"></i>
                            <span id="message-badge" class="absolute top-1 right-1 w-4 h-4 bg-ua-maroon text-white text-[10px] flex items-center justify-center rounded-full hidden">0</span>
                        </button>
                        <!-- Notifications -->
                        <button id="notification-bell" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-bell text-lg"></i>
                            <span id="notification-badge" class="absolute top-1 right-1 min-w-[16px] h-4 px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center hidden">0</span>
                        </button>
                        <!-- Profile Dropdown -->
                        <div class="relative">
                            <button id="profile-btn" class="w-10 h-10 rounded-full bg-ua-maroon flex items-center justify-center text-white font-bold cursor-pointer hover:opacity-80 transition">
                                <?php echo isset($_SESSION['full_name']) ? substr($_SESSION['full_name'], 0, 1) : 'U'; ?>
                            </button>
                            <div id="profile-dropdown" class="profile-dropdown">
                                <div class="profile-dropdown-header">
                                    <p><?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></p>
                                    <span><?php echo htmlspecialchars($_SESSION['role'] ?? 'Role'); ?></span>
                                </div>
                                <a href="../../logout.php" class="profile-dropdown-item logout">
                                    <i class="fas fa-sign-out-alt"></i> Sign Out
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Page Content -->
            <div class="flex-1 overflow-auto p-8">
                <!-- Original Content Area -->
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div class="app">

        <main class="content">
            

            <?php if($message): ?>
                <?php if(strpos($message, 'Success') !== false): ?>
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            showSuccessModal('<?php echo htmlspecialchars($message, ENT_QUOTES); ?>');
                        });
                    </script>
                <?php else: ?>
                    <div class="alert <?php echo strpos($message, 'Warning') !== false ? 'alert-warning' : 'alert-error'; ?>">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <!-- CRITICAL FIX: Display office assignment status -->
            <?php if(!$office_id): ?>
                <div class="alert alert-error" style="margin-bottom: 20px;">
                    <strong>Critical Error:</strong> Your office assignment is not configured. Please contact the QMO Administrator to assign you to an office before submitting documents.
                </div>
            <?php else: ?>
                <div class="alert alert-info" style="margin-bottom: 20px; display: none;" id="officeInfo">
                    <strong>Office Assignment:</strong> <span id="officeDisplay"></span>
                </div>
            <?php endif; ?>

            <div class="grid" style="grid-template-columns: <?php echo $previous_version ? '1fr 1fr' : '1fr'; ?>; gap: 30px;">
                
                <!-- Submission Form -->
                <div class="panel">
                    <div class="panel-header">
                        <h2><i data-lucide="upload-cloud" style="vertical-align: middle;"></i> <?php echo $previous_version ? 'Upload Revision' : 'New Submission'; ?></h2>
                    </div>
                    
                    <!-- Tab Navigation -->
                    <div style="display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #eee;">
                        <button type="button" class="tab-btn active" onclick="switchTab(event, 'upload')" style="padding: 12px 0; border: none; background: none; cursor: pointer; font-weight: 600; color: var(--ua-maroon); border-bottom: 3px solid var(--ua-maroon); flex: 1; text-align: left;">
                            <i class="fas fa-upload" style="margin-right: 8px;"></i> Upload File
                        </button>
                        <button type="button" class="tab-btn" onclick="switchTab(event, 'scanner')" style="padding: 12px 0; border: none; background: none; cursor: pointer; font-weight: 600; color: #999; flex: 1; text-align: left;">
                            <i class="fas fa-camera" style="margin-right: 8px;"></i> Scan Document
                        </button>
                    </div>
                    
                    <!-- Upload Tab -->
                    <div id="upload-tab" style="display: block;">
                    <form id="submissionForm" action="submit_document.php" method="POST" enctype="multipart/form-data" onsubmit="return preventDoubleSubmit()">
                            <input type="hidden" name="submit_token" value="<?php echo $_SESSION['submit_token']; ?>">
                        <div class="form-group">
                            <label for="doc_type">Document Type</label>
                            <select name="doc_type_id" id="doc_type" required <?php echo !$office_id ? 'disabled' : ''; ?>>
                                <option value="">-- Select Type --</option>
                                <?php foreach($doc_types as $type): ?>
                                    <option value="<?php echo $type['doc_type_id']; ?>" <?php echo ($previous_version && $previous_version['doc_type_id'] == $type['doc_type_id']) ? 'selected' : ''; ?>>
                                        <?php echo $type['doc_code']; ?> - <?php echo $type['description']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="document_file">Select File</label>
                            <input type="file" name="document_file" id="document_file" required <?php echo !$office_id ? 'disabled' : ''; ?>>
                            <p class="validation-hint">Allowed formats: .pdf, .docx, .xlsx, .jpg, .png | Max size: 10MB</p>
                            <p id="fileError" style="color: #dc2626; font-size: 0.85rem; margin-top: 5px; display: none;"></p>
                        </div>

                        <div style="margin-top: 30px;">
                            <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center; padding: 15px;" <?php echo !$office_id ? 'disabled' : ''; ?>>
                                <i data-lucide="send"></i> Submit Document
                            </button>
                        </div>
                    </form>
                    </div>
                    
                    <!-- Scanner Tab -->
                    <div id="scanner-tab" style="display: none;">
                        <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                            <h4 style="margin-bottom: 15px; font-weight: 600;">Document Scanner</h4>
                            <p style="font-size: 0.9rem; color: #666; margin-bottom: 15px;">Use your device camera to capture and scan documents directly.</p>
                            
                            <div id="scanner-container" style="background: #000; border-radius: 8px; overflow: hidden; margin-bottom: 15px; display: none;">
                                <video id="scanner-video" style="width: 100%; height: 400px; object-fit: cover;"></video>
                            </div>
                            
                            <canvas id="scanner-canvas" style="display: none;"></canvas>
                            <div id="scanner-preview" style="margin-bottom: 15px;"></div>
                            
                            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                                <button type="button" id="start-scanner-btn" class="btn btn-primary" onclick="startScanner()" style="flex: 1; min-width: 120px;">
                                    <i class="fas fa-camera"></i> Start Camera
                                </button>
                                <button type="button" id="capture-btn" class="btn btn-primary" onclick="captureFrame()" style="flex: 1; min-width: 120px; display: none;">
                                    <i class="fas fa-camera"></i> Capture
                                </button>
                                <button type="button" id="stop-scanner-btn" class="btn" onclick="stopScanner()" style="flex: 1; min-width: 120px; display: none;">
                                    <i class="fas fa-times"></i> Cancel
                                </button>
                            </div>
                            
                            <div id="scanner-message" style="margin-top: 10px; padding: 10px; border-radius: 4px; display: none; border-left: 4px solid #33c;"></div>
                        </div>
                    </div>
                </div>

                <!-- Comparison Mode (Feedback Integration) -->
                <?php if($previous_version): ?>
                <div class="panel" style="border-left: 4px solid var(--ua-maroon);">
                    <div class="panel-header">
                        <h2><i data-lucide="git-compare" style="vertical-align: middle;"></i> Previous Version & Feedback</h2>
                    </div>
                    
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                        <h4 style="margin-bottom: 10px; font-weight: 600;">Previous Submission</h4>
                        <p><strong>File:</strong> <?php echo htmlspecialchars($previous_version['file_name']); ?></p>
                        <p><strong>Submitted:</strong> <?php echo date('M d, Y H:i', strtotime($previous_version['submitted_at'])); ?></p>
                    </div>

                    <?php if($previous_version['remarks']): ?>
                    <div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                        <h4 style="margin-bottom: 10px; font-weight: 600; color: #92400e;">Admin Feedback</h4>
                        <p style="color: #78350f; margin: 0;"><?php echo htmlspecialchars($previous_version['remarks']); ?></p>
                    </div>
                    <?php endif; ?>

                    <div style="background: #e0f2fe; padding: 15px; border-radius: 8px; border-left: 4px solid #0284c7;">
                        <p style="margin: 0; color: #0c4a6e; font-size: 0.9rem;">
                            <strong>Tip:</strong> Review the feedback above and make necessary changes before uploading your revised version.
                        </p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script>
        function switchTab(event, tabName) {
            event.preventDefault();
            
            // Hide all tabs
            document.getElementById('upload-tab').style.display = 'none';
            document.getElementById('scanner-tab').style.display = 'none';
            
            // Show selected tab
            document.getElementById(tabName + '-tab').style.display = 'block';
            
            // Update button styles
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.style.color = '#999';
                btn.style.borderBottomColor = 'transparent';
            });
            event.target.closest('.tab-btn').style.color = 'var(--ua-maroon)';
            event.target.closest('.tab-btn').style.borderBottomColor = 'var(--ua-maroon)';
        }

        // File validation
        document.getElementById('document_file')?.addEventListener('change', function() {
            const file = this.files[0];
            const errorEl = document.getElementById('fileError');
            
            if (!file) return;
            
            const maxSize = 10 * 1024 * 1024;
            const allowedExts = ['pdf', 'docx', 'xlsx', 'jpg', 'jpeg', 'png'];
            const fileExt = file.name.split('.').pop().toLowerCase();
            
            if (!allowedExts.includes(fileExt)) {
                errorEl.textContent = 'Invalid file format. Only PDF, DOCX, XLSX, JPG, PNG are allowed.';
                errorEl.style.display = 'block';
                this.value = '';
            } else if (file.size > maxSize) {
                errorEl.textContent = 'File size exceeds 10MB limit.';
                errorEl.style.display = 'block';
                this.value = '';
            } else {
                errorEl.style.display = 'none';
            }
        });

        // Scanner functions
        let stream = null;
        async function startScanner() {
            try {
                stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
                const video = document.getElementById('scanner-video');
                video.srcObject = stream;
                document.getElementById('scanner-container').style.display = 'block';
                document.getElementById('start-scanner-btn').style.display = 'none';
                document.getElementById('capture-btn').style.display = 'block';
                document.getElementById('stop-scanner-btn').style.display = 'block';
            } catch (err) {
                alert('Unable to access camera: ' + err.message);
            }
        }

        function stopScanner() {
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
            }
            document.getElementById('scanner-container').style.display = 'none';
            document.getElementById('start-scanner-btn').style.display = 'block';
            document.getElementById('capture-btn').style.display = 'none';
            document.getElementById('stop-scanner-btn').style.display = 'none';
        }

        function captureFrame() {
            const video = document.getElementById('scanner-video');
            const canvas = document.getElementById('scanner-canvas');
            const ctx = canvas.getContext('2d');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            ctx.drawImage(video, 0, 0);
            
            const preview = document.getElementById('scanner-preview');
            preview.innerHTML = '<img src="' + canvas.toDataURL() + '" style="max-width: 100%; border-radius: 8px;">';
            
            canvas.toBlob(blob => {
                const file = new File([blob], 'scanned_' + Date.now() + '.png', { type: 'image/png' });
                const dt = new DataTransfer();
                dt.items.add(file);
                document.getElementById('document_file').files = dt.files;
            });
            
            stopScanner();
        }

        // Display office info if available
        const officeId = <?php echo json_encode($office_id); ?>;
        if (officeId) {
            document.getElementById('officeInfo').style.display = 'block';
            document.getElementById('officeDisplay').textContent = 'Office ID: ' + officeId;
        }

        // Prevent double submission
        let isSubmitting = false;
        function preventDoubleSubmit() {
            if (isSubmitting) return false;
            isSubmitting = true;
            const submitBtn = document.querySelector('#submissionForm button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
            }
            return true;
        }

        // Modal functions
        function showSuccessModal(message) {
            const modal = document.getElementById('successModal');
            const modalMessage = document.getElementById('modalMessage');
            modalMessage.textContent = message;
            modal.style.display = 'flex';
        }

        function closeSuccessModal() {
            const modal = document.getElementById('successModal');
            modal.style.display = 'none';
            // Reset form after closing modal
            document.getElementById('submissionForm').reset();
        }

        // Close modal when clicking outside
        window.addEventListener('click', function(event) {
            const modal = document.getElementById('successModal');
            if (event.target === modal) {
                closeSuccessModal();
            }
        });

        // Profile Dropdown Toggle
        const profileBtn = document.getElementById('profile-btn');
        const profileDropdown = document.getElementById('profile-dropdown');
        
        if (profileBtn && profileDropdown) {
            profileBtn.addEventListener('click', function() {
                profileDropdown.classList.toggle('active');
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(event) {
                if (!event.target.closest('#profile-btn') && !event.target.closest('#profile-dropdown')) {
                    profileDropdown.classList.remove('active');
                }
            });
        }
    </script>

    <!-- Success Modal -->
    <div id="successModal">
        <div class="modal-content">
            <div class="modal-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="modal-title">Success!</div>
            <div class="modal-message" id="modalMessage"></div>
            <button class="modal-button" onclick="closeSuccessModal()">OK</button>
        </div>
    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
