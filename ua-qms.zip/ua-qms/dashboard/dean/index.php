<?php
session_start();
include "../../config/db.php";

if (!isset($_SESSION['role']) || ($_SESSION['role'] != 'Dean' && $_SESSION['role'] != 'Office')) {
    header('Location: ../../index.php');
    exit();
}

$dean_id = $_SESSION['user_id']; 
$dean_name = $_SESSION['full_name'];
$office_id = $_SESSION['office_id'] ?? 0;

// Fetch Unit Statistics
$stats = [
    'completion_rate' => 0,
    'approved' => 0,
    'pending' => 0,
    'revision' => 0
];

// Get document counts
$sql_counts = "SELECT status, COUNT(*) as count FROM documents WHERE office_id = ? GROUP BY status";
$stmt = $conn->prepare($sql_counts);
$stmt->bind_param("i", $office_id);
$stmt->execute();
$result = $stmt->get_result();
while($row = $result->fetch_assoc()) {
    if($row['status'] == 'Approved') $stats['approved'] = $row['count'];
    if($row['status'] == 'Awaiting Review') $stats['pending'] = $row['count'];
    if($row['status'] == 'Revision') $stats['revision'] = $row['count'];
}

// Calculate completion rate (simplified)
$total_docs = $stats['approved'] + $stats['pending'] + $stats['revision'];
if($total_docs > 0) {
    $stats['completion_rate'] = round(($stats['approved'] / $total_docs) * 100);
}

// Fetch Upcoming Deadlines from target_submissions
$deadlines = [];
$sql_deadlines = "SELECT ts.deadline, dt.doc_code, dt.description 
                  FROM target_submissions ts 
                  JOIN document_types dt ON ts.doc_type_id = dt.doc_type_id 
                  WHERE ts.deadline >= CURDATE() 
                  ORDER BY ts.deadline ASC LIMIT 3";
$res_deadlines = $conn->query($sql_deadlines);
while($row = $res_deadlines->fetch_assoc()) {
    $deadlines[] = $row;
}

// Fetch Revision Inbox (Documents with Revision status and latest comment)
$revisions = [];
$sql_revisions = "SELECT d.document_id, d.file_name, dt.doc_code, dr.remarks, dr.reviewed_at 
                  FROM documents d
                  JOIN document_types dt ON d.doc_type_id = dt.doc_type_id
                  LEFT JOIN document_reviews dr ON d.document_id = dr.document_id
                  WHERE d.office_id = ? AND d.status = 'Revision'
                  AND dr.review_id = (SELECT MAX(review_id) FROM document_reviews WHERE document_id = d.document_id)
                  ORDER BY dr.reviewed_at DESC";
$stmt_rev = $conn->prepare($sql_revisions);
$stmt_rev->bind_param("i", $office_id);
$stmt_rev->execute();
$res_rev = $stmt_rev->get_result();
while($row = $res_rev->fetch_assoc()) {
    $revisions[] = $row;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unit Dashboard | UA QMS</title>
    <link rel="stylesheet" href="../../assets/css/dashboard.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/lucide@latest"></script>
        <script>
        window.CURRENT_USER_ID = <?php echo json_encode($_SESSION["user_id"]); ?>;
        window.CURRENT_USER_ROLE = <?php echo json_encode($_SESSION["role"]); ?>;
    </script>
    <script src="../../assets/js/messaging.js" defer></script>
    <script src="../../assets/js/notifications.js" defer></script>
    <style>
        :root {
            --ua-maroon: #800000;
            --ua-gold: #FFD700;
            --ua-green: #006400;
        }
        .bg-ua-maroon { background-color: var(--ua-maroon); }
        .text-ua-maroon { color: var(--ua-maroon); }
        .border-ua-maroon { border-color: var(--ua-maroon); }
    </style>
</head>
<body class="bg-gray-50 font-sans">
    <div class="flex h-screen overflow-hidden">
        <?php include "../../includes/sidebar_dean.php"; ?>

        <!-- Main Content -->
        <main class="flex-1 flex flex-col overflow-hidden">
            <!-- Topbar -->
            <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 flex-shrink-0">
                <h1 class="text-xl font-bold text-gray-800">Unit Dashboard</h1>
                <div class="flex items-center gap-4">
                    <div class="flex items-center gap-2">
                        <!-- Message Inbox -->
                        <button id="inbox-btn" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-envelope text-lg"></i>
                            <span id="message-badge" class="absolute top-1 right-1 w-4 h-4 bg-ua-maroon text-white text-[10px] flex items-center justify-center rounded-full hidden">0</span>
                        </button>
                        <!-- Notifications -->
                        <button id="notification-bell" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-bell text-lg"></i>
                            <span id="notification-badge" class="absolute top-1 right-1 min-w-[16px] h-4 px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center hidden">0</span>
                        </button>
                        <!-- Profile Dropdown -->
                        <div class="relative">
                            <button id="profile-btn" class="w-10 h-10 rounded-full bg-ua-maroon flex items-center justify-center text-white font-bold cursor-pointer hover:opacity-80 transition">
                                <?php echo isset($_SESSION['full_name']) ? substr($_SESSION['full_name'], 0, 1) : 'U'; ?>
                            </button>
                            <div id="profile-dropdown" class="profile-dropdown">
                                <div class="profile-dropdown-header">
                                    <p><?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></p>
                                    <span><?php echo htmlspecialchars($_SESSION['role'] ?? 'Role'); ?></span>
                                </div>
                                <a href="../../logout.php" class="profile-dropdown-item logout">
                                    <i class="fas fa-sign-out-alt"></i> Sign Out
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Page Content -->
            <div class="flex-1 overflow-auto p-8">
                <!-- Original Content Area -->
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div class="app">
        

        <main class="content">
            

            <!-- Personal Compliance Dashboard -->
            <section class="cards">
                <div class="card">
                    <p>Completion Rate</p>
                    <h3><?php echo $stats['completion_rate']; ?>%</h3>
                    <div style="width: 100%; background: #eee; height: 8px; border-radius: 4px; margin-top: 10px;">
                        <div style="width: <?php echo $stats['completion_rate']; ?>%; background: var(--ua-green); height: 100%; border-radius: 4px;"></div>
                    </div>
                </div>
                <div class="card" style="border-top-color: var(--ua-green);">
                    <p>Approved</p>
                    <h3><?php echo $stats['approved']; ?></h3>
                </div>
                <div class="card" style="border-top-color: #f97316;">
                    <p>Awaiting Review</p>
                    <h3><?php echo $stats['pending']; ?></h3>
                </div>
                <div class="card" style="border-top-color: #dc2626;">
                    <p>Revisions Needed</p>
                    <h3><?php echo $stats['revision']; ?></h3>
                </div>
            </section>

            <div class="grid" style="display: grid; grid-template-columns: 2fr 1fr; gap: 25px;">
                <!-- Revision Inbox -->
                <div class="panel">
                    <div class="panel-header">
                        <h2><i data-lucide="alert-circle" style="vertical-align: middle; color: #dc2626;"></i> Revision Inbox</h2>
                    </div>
                    <?php if(empty($revisions)): ?>
                        <p style="text-align: center; padding: 20px; color: var(--text-muted);">No documents currently require revision. Great job!</p>
                    <?php else: ?>
                        <div class="revision-list">
                            <?php foreach($revisions as $rev): ?>
                                <div class="activity" style="border-left: 4px solid #dc2626; padding-left: 15px; margin-bottom: 15px; background: #fffafa;">
                                    <div style="display: flex; justify-content: space-between;">
                                        <strong><?php echo htmlspecialchars($rev['doc_code'] . ' - ' . $rev['file_name']); ?></strong>
                                        <span class="badge badge-revision">Revision</span>
                                    </div>
                                    <p style="margin-top: 8px; font-size: 0.95rem;">
                                        <strong>Admin Comment:</strong> <span style="color: #b91c1c; font-weight: 600;"><?php echo htmlspecialchars($rev['remarks']); ?></span>
                                    </p>
                                    <div style="margin-top: 10px;">
                                        <a href="submit_document.php?re-submit=<?php echo $rev['document_id']; ?>" class="btn btn-primary" style="font-size: 0.8rem; padding: 5px 12px;">
                                            <i data-lucide="upload-cloud" style="width: 14px;"></i> Re-submit Version
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Upcoming Deadlines -->
                <div class="panel">
                    <div class="panel-header">
                        <h2><i data-lucide="clock" style="vertical-align: middle;"></i> Deadlines</h2>
                    </div>
                    <?php if(empty($deadlines)): ?>
                        <p style="color: var(--text-muted);">No upcoming deadlines found.</p>
                    <?php else: ?>
                        <?php foreach($deadlines as $dl): ?>
                            <div style="margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #eee;">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <span style="font-weight: 600; color: var(--ua-maroon);"><?php echo $dl['doc_code']; ?></span>
                                    <span style="font-size: 0.8rem; color: var(--text-muted);"><?php echo date('M d, Y', strtotime($dl['deadline'])); ?></span>
                                </div>
                                <p style="font-size: 0.85rem; margin: 5px 0;"><?php echo htmlspecialchars($dl['description']); ?></p>
                                <div class="countdown-timer" data-deadline="<?php echo $dl['deadline']; ?>">
                                    <div class="timer-unit"><span class="timer-value days">00</span><span class="timer-label">Days</span></div>
                                    <div class="timer-unit"><span class="timer-value hours">00</span><span class="timer-label">Hrs</span></div>
                                    <div class="timer-unit"><span class="timer-value mins">00</span><span class="timer-label">Min</span></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <!-- Toast Notification for Revisions -->
    <?php if(!empty($revisions)): ?>
    <div class="toast" id="revisionToast">
        <i data-lucide="bell-ring"></i>
        <div>
            <strong>Action Required!</strong><br>
            You have <?php echo count($revisions); ?> document(s) that need revision.
        </div>
        <button onclick="document.getElementById('revisionToast').style.display='none'" style="background:none; border:none; color:white; cursor:pointer; margin-left:10px;">✕</button>
    </div>
    <?php endif; ?>

    <script>
        // Initialize Lucide Icons
        

        // Countdown Timer Logic
        function updateCountdowns() {
            const timers = document.querySelectorAll('.countdown-timer');
            timers.forEach(timer => {
                const deadline = new Date(timer.dataset.deadline).getTime();
                const now = new Date().getTime();
                const distance = deadline - now;

                if (distance < 0) {
                    timer.innerHTML = "<span style='color: #dc2626; font-weight: bold;'>OVERDUE</span>";
                    return;
                }

                const days = Math.floor(distance / (1000 * 60 * 60 * 24));
                const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));

                timer.querySelector('.days').innerText = days.toString().padStart(2, '0');
                timer.querySelector('.hours').innerText = hours.toString().padStart(2, '0');
                timer.querySelector('.mins').innerText = minutes.toString().padStart(2, '0');
            });
        }

        setInterval(updateCountdowns, 60000);
        updateCountdowns();
        lucide.createIcons();

        // Profile Dropdown Toggle
        const profileBtn = document.getElementById('profile-btn');
        const profileDropdown = document.getElementById('profile-dropdown');
        
        profileBtn.addEventListener('click', function() {
            profileDropdown.classList.toggle('active');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            if (!event.target.closest('#profile-btn') && !event.target.closest('#profile-dropdown')) {
                profileDropdown.classList.remove('active');
            }
        });

        // Auto-hide toast after 8 seconds
        setTimeout(() => {
            const toast = document.getElementById('revisionToast');
            if(toast) toast.style.display = 'none';
        }, 8000);
    </script>
                </div>
            </div>
        </main>
    </div>
</body>
</html>