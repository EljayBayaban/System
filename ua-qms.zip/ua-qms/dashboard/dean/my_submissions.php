<?php
session_start();
include "../../config/db.php";

if (!isset($_SESSION['role']) || ($_SESSION['role'] != 'Dean' && $_SESSION['role'] != 'Office')) {
    header('Location: ../../index.php');
    exit();
}

$office_id = $_SESSION['office_id'] ?? 0;

// Fetch all submissions for this unit with review details
$submissions = [];

$sql = "SELECT 
            d.document_id,
            d.doc_type_id,
            d.office_id,
            d.file_name,
            d.file_path,
            d.preview_path,
            d.status,
            d.submitted_at,
            dt.doc_code,
            dt.description,
            dr.remarks AS review_remarks,
            dr.reviewed_at
        FROM documents d
        JOIN document_types dt 
            ON d.doc_type_id = dt.doc_type_id
        LEFT JOIN document_reviews dr 
            ON d.document_id = dr.document_id
        WHERE d.office_id = ?
        ORDER BY d.submitted_at DESC, dr.reviewed_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $office_id);
$stmt->execute();

$result = $stmt->get_result();

// Group by document to only show latest review
$docs = [];

while($row = $result->fetch_assoc()) {
    if (!isset($docs[$row['document_id']])) {
        $docs[$row['document_id']] = $row;
    }
}

$submissions = array_values($docs);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Submissions | UA QMS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="../../assets/js/messaging.js" defer></script>
    <script src="../../assets/js/notifications.js" defer></script>
    <script src="../../assets/js/universal-file-viewer.js" defer></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body { font-family: 'Inter', sans-serif; }
        :root {
            --ua-maroon: #800000;
        }
        .bg-ua-maroon { background-color: var(--ua-maroon); }
        .text-ua-maroon { color: var(--ua-maroon); }
        
        /* Status Badges */
        .badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-block;
        }
        .badge-awaiting { background-color: #FEF3C7; color: #92400E; }
        .badge-approved { background-color: #D1FAE5; color: #065F46; }
        .badge-revision { background-color: #FEE2E2; color: #991B1B; }
        


        /* Print styles */
        @media print {
            .no-print { display: none !important; }
            table { width: 100%; }
            tr { page-break-inside: avoid; }
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="flex min-h-screen">
        <?php include "../../includes/sidebar_dean.php"; ?>

        <!-- Main Content -->
        <main class="flex-1 flex flex-col overflow-hidden">
            <!-- Topbar -->
            <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 flex-shrink-0">
                <h1 class="text-xl font-bold text-gray-800">My Submissions</h1>
                <div class="flex items-center gap-4">
                    <div class="flex items-center gap-2">
                        <!-- Message Inbox -->
                        <button id="inbox-btn" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-envelope text-lg"></i>
                            <span id="message-badge" class="absolute top-1 right-1 w-4 h-4 bg-ua-maroon text-white text-[10px] flex items-center justify-center rounded-full hidden">0</span>
                        </button>
                        <!-- Notifications -->
                        <button id="notification-bell" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-bell text-lg"></i>
                            <span id="notification-badge" class="absolute top-1 right-1 min-w-[16px] h-4 px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center hidden">0</span>
                        </button>
                        <!-- Profile Dropdown -->
                        <div class="relative">
                            <button id="profile-btn" class="w-10 h-10 rounded-full bg-ua-maroon flex items-center justify-center text-white font-bold cursor-pointer hover:opacity-80 transition">
                                <?php echo isset($_SESSION['full_name']) ? substr($_SESSION['full_name'], 0, 1) : 'U'; ?>
                            </button>
                            <div id="profile-dropdown" class="profile-dropdown">
                                <div class="profile-dropdown-header">
                                    <p><?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></p>
                                    <span><?php echo htmlspecialchars($_SESSION['role'] ?? 'Role'); ?></span>
                                </div>
                                <a href="../../logout.php" class="profile-dropdown-item logout">
                                    <i class="fas fa-sign-out-alt"></i> Sign Out
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Page Content -->
            <div class="flex-1 overflow-auto p-8">
                <div class="max-w-7xl mx-auto">
                    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                        <div class="p-6 border-b border-gray-100 flex justify-between items-center no-print">
                            <h3 class="font-bold text-gray-900">Document Submission History</h3>
                            <a href="submit_document.php" class="px-4 py-2 bg-[#800000] text-white rounded-xl text-sm font-bold hover:bg-[#600000] transition-colors">
                                <i data-lucide="plus" class="w-4 h-4 inline mr-1"></i> New Submission
                            </a>
                        </div>
                        
                        <div class="overflow-x-auto">
                            <table class="w-full text-left">
                                <thead class="bg-gray-50 text-gray-500 text-xs uppercase font-bold">
                                    <tr>
                                        <th class="px-6 py-4">Document Type</th>
                                        <th class="px-6 py-4">File Name</th>
                                        <th class="px-6 py-4">Submitted At</th>
                                        <th class="px-6 py-4">Status</th>

                                        <th class="px-6 py-4 no-print">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-100" id="submissionsTableBody">
                                    <?php if(empty($submissions)): ?>
                                        <tr>
                                            <td colspan="5" class="px-6 py-12 text-center text-gray-500">
                                                No documents submitted yet.
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach($submissions as $sub): ?>
                                            <tr class="hover:bg-gray-50/50 transition-colors submission-row" data-doc-id="<?php echo $sub['document_id']; ?>">
                                                <td class="px-6 py-4">
                                                    <span class="font-bold text-gray-900"><?php echo $sub['doc_code']; ?></span>
                                                    <p class="text-[10px] text-gray-400"><?php echo htmlspecialchars($sub['description']); ?></p>
                                                </td>
                                                <td class="px-6 py-4 text-sm text-gray-600">
                                                    <?php echo htmlspecialchars($sub['file_name']); ?>
                                                </td>
                                                <td class="px-6 py-4 text-sm text-gray-500">
                                                    <?php echo date('M d, Y', strtotime($sub['submitted_at'])); ?>
                                                    <p class="text-[10px]"><?php echo date('H:i', strtotime($sub['submitted_at'])); ?></p>
                                                </td>
                                                <td class="px-6 py-4">
                                                    <?php 
                                                        $statusClass = 'badge-awaiting';
                                                        if($sub['status'] == 'Approved') $statusClass = 'badge-approved';
                                                        if($sub['status'] == 'Revision') $statusClass = 'badge-revision';
                                                    ?>
                                                    <span class="badge <?php echo $statusClass; ?>">
                                                        <?php echo $sub['status']; ?>
                                                    </span>
                                                </td>

                                                <td class="px-6 py-4 no-print">
    <div class="flex gap-2">

        <button 
            onclick="openUniversalFileViewer(
                '<?php echo htmlspecialchars($sub['file_path']); ?>',
                '<?php echo htmlspecialchars($sub['preview_path'] ?? $sub['file_path']); ?>',
                '<?php echo htmlspecialchars($sub['file_name']); ?>'
            )"
            class="px-4 py-2 bg-gray-100 text-gray-700 text-xs font-bold rounded-lg hover:bg-[#800000] hover:text-white transition-all">
            PREVIEW
        </button>

        <?php if($sub['status'] == 'Revision'): ?>
            <a href="submit_document.php?re-submit=<?php echo $sub['document_id']; ?>" 
               class="p-2 text-orange-600 hover:bg-orange-50 rounded-lg transition-colors" 
               title="Re-submit">
                <i data-lucide="refresh-cw" class="w-4 h-4"></i>
            </a>
        <?php endif; ?>

    </div>
</td>
                                            </tr>
                                            <?php if(!empty($sub['review_remarks'])): ?>
                                                <tr class="bg-gray-50/30">
                                                    <td colspan="5" class="px-6 py-3">
                                                        <div class="flex items-start gap-2 text-xs">
                                                            <span class="font-bold text-gray-500">Reviewer Remarks:</span>
                                                            <span class="text-gray-600 italic"><?php echo htmlspecialchars($sub['review_remarks']); ?></span>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        lucide.createIcons();

        function printDocument(filePath, fileName) {
            const fileExt = fileName.split('.').pop().toLowerCase();
            
            if (['pdf'].includes(fileExt)) {
                // Open PDF in new window for printing
                window.open(filePath, '_blank');
            } else if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(fileExt)) {
                // Open image in new window for printing
                const printWindow = window.open(filePath, '_blank');
                printWindow.addEventListener('load', function() {
                    printWindow.print();
                });
            } else {
                alert('Print preview not available for this file type. Please download and print manually.');
            }
        }

        // Profile Dropdown Toggle
        const profileBtn = document.getElementById('profile-btn');
        const profileDropdown = document.getElementById('profile-dropdown');
        
        if (profileBtn && profileDropdown) {
            profileBtn.addEventListener('click', function() {
                profileDropdown.classList.toggle('active');
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(event) {
                if (!event.target.closest('#profile-btn') && !event.target.closest('#profile-dropdown')) {
                    profileDropdown.classList.remove('active');
                }
            });
        }

    </script>
    <!-- Universal File Viewer Modal will be injected here by universal-file-viewer.js -->
</body>
</html>
