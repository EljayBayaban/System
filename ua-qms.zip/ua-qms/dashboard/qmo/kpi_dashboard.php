<?php
session_start();
include "../../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'QMO Admin') {
    header("Location: ../../index.php");
    exit();
}

// Get active period from settings
$sql_settings = "SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ('active_academic_year', 'active_semester')";
$result_settings = $conn->query($sql_settings);
$settings = [];
while ($row = $result_settings->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

$active_year = $settings['active_academic_year'] ?? date('Y') . '-' . (date('Y') + 1);
$active_semester = $settings['active_semester'] ?? '1st Semester';

// Handle filters
$selected_year = $_GET['year'] ?? $active_year;
$selected_semester = $_GET['semester'] ?? $active_semester;

// 1. Multi-Year Compliance Trend Data
$trend_data = [];
$years_sql = "SELECT DISTINCT year FROM compliance_tracking ORDER BY year ASC LIMIT 5";
$years_res = $conn->query($years_sql);
while ($y_row = $years_res->fetch_assoc()) {
    $yr = $y_row['year'];
    $trend_sql = "SELECT AVG((total_submitted / total_required) * 100) as avg_rate 
                  FROM compliance_tracking 
                  WHERE year = '$yr'";
    $trend_res = $conn->query($trend_sql);
    $trend_val = $trend_res->fetch_assoc();
    $trend_data[] = [
        'year' => $yr,
        'rate' => round($trend_val['avg_rate'] ?? 0),
        'target' => 85 // Strategic Target
    ];
}

// 2. Document Type Bottlenecks (Non-submissions/Pending for selected period)
$bottleneck_data = [];
$bn_sql = "SELECT dt.doc_code, COUNT(dt.doc_type_id) as issue_count
           FROM document_types dt
           LEFT JOIN documents d ON dt.doc_type_id = d.doc_type_id 
           WHERE d.status IN ('Awaiting Review', 'Revision', 'Not Submitted') OR d.document_id IS NULL
           GROUP BY dt.doc_code
           ORDER BY issue_count DESC";
$bn_res = $conn->query($bn_sql);
while ($bn_row = $bn_res->fetch_assoc()) {
    $bottleneck_data[] = [
        'name' => $bn_row['doc_code'],
        'value' => (int)$bn_row['issue_count']
    ];
}

// 3. Top Performing Units
$units_data = [];
$units_sql = "SELECT o.office_name, o.office_code, 
              (SUM(CASE WHEN d.status = 'Approved' THEN 1 ELSE 0 END) / COUNT(dt.doc_type_id) * 100) as completion_rate
              FROM offices o
              CROSS JOIN document_types dt
              LEFT JOIN documents d ON o.office_id = d.office_id AND dt.doc_type_id = d.doc_type_id
              WHERE o.status = 'Active'
              GROUP BY o.office_id
              ORDER BY completion_rate DESC
              LIMIT 8";
$units_res = $conn->query($units_sql);
$rank = 1;
while ($u_row = $units_res->fetch_assoc()) {
    $units_data[] = [
        'rank' => '#' . $rank++,
        'name' => $u_row['office_name'],
        'rate' => round($u_row['completion_rate'] ?? 0) . '%',
        'status' => $u_row['completion_rate'] >= 80 ? 'On Track' : 'Needs Attention'
    ];
}

// Overall Compliance for AI Header
$overall_sql = "SELECT AVG(completion_rate) as avg_comp FROM (
    SELECT (SUM(CASE WHEN d.status = 'Approved' THEN 1 ELSE 0 END) / COUNT(dt.doc_type_id) * 100) as completion_rate
    FROM offices o
    CROSS JOIN document_types dt
    LEFT JOIN documents d ON o.office_id = d.office_id AND dt.doc_type_id = d.doc_type_id
    WHERE o.status = 'Active'
    GROUP BY o.office_id
) as sub";
$overall_res = $conn->query($overall_sql);
$overall_comp = round($overall_res->fetch_assoc()['avg_comp'] ?? 0);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KPI Dashboard & Strategic Reports | UA QMS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="../../assets/js/messaging.js" defer></script>
    <script src="../../assets/js/notifications.js" defer></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #F9FAFB; }
        .bg-ua-maroon { background-color: #800000; }
        .text-ua-maroon { color: #800000; }
        .glass-card { background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(10px); border: 1px solid rgba(229, 231, 235, 0.5); }
        .chart-container { position: relative; height: 300px; width: 100%; }
    </style>
</head>
<body class="flex h-screen overflow-hidden">
    <?php include "../../includes/sidebar_qmo.php"; ?>

    <main class="flex-1 flex flex-col overflow-hidden">
        <!-- Topbar -->
        <!-- Topbar -->
            <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 flex-shrink-0">
                <h1 class="text-xl font-bold text-gray-800">KPI Dashboard & Strategic Reports</h1>
                <div class="flex items-center gap-6">
                    <div class="flex items-center gap-2">
                        <!-- Message Inbox -->
                        <button id="inbox-btn" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-envelope text-lg"></i>
                            <span id="message-badge" class="absolute top-1 right-1 w-4 h-4 bg-[#800000] text-white text-[10px] flex items-center justify-center rounded-full hidden">0</span>
                        </button>
                        <!-- Notifications -->
                        <button id="notification-bell" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-bell text-lg"></i>
                            <span id="notification-badge" class="absolute top-1 right-1 min-w-[16px] h-4 px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center hidden">0</span>
                        </button>
                        <!-- Profile Dropdown -->
                        <div class="relative">
                            <button id="profile-btn" class="w-10 h-10 rounded-full bg-ua-maroon flex items-center justify-center text-white font-bold cursor-pointer hover:opacity-80 transition">
                                <?php echo isset($_SESSION['full_name']) ? substr($_SESSION['full_name'], 0, 1) : 'U'; ?>
                            </button>
                            <div id="profile-dropdown" class="profile-dropdown">
                                <div class="profile-dropdown-header">
                                    <p><?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></p>
                                    <span><?php echo htmlspecialchars($_SESSION['role'] ?? 'Role'); ?></span>
                                </div>
                                <a href="../../logout.php" class="profile-dropdown-item logout">
                                    <i class="fas fa-sign-out-alt"></i> Sign Out
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

        <!-- Content -->
        <div class="flex-1 overflow-y-auto p-8">
            <div class="max-w-7xl mx-auto space-y-8">
                <!-- Header Info -->
                <div>
                    <h2 class="text-2xl font-bold text-gray-900">KPI Dashboard & Strategic Reports</h2>
                    <p class="text-gray-500 text-sm">Performance analysis for <span class="text-red-700 font-semibold"><?php echo $selected_semester; ?>, <?php echo $selected_year; ?></span>.</p>
                </div>

                <!-- AI Consultant Card -->
                <div class="bg-indigo-50/50 border border-indigo-100 rounded-2xl p-6 flex items-center justify-between">
                    <div class="flex items-center gap-4">
                        <div class="w-12 h-12 bg-white rounded-xl shadow-sm flex items-center justify-center text-indigo-600">
                            <i class="fas fa-robot text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="font-bold text-gray-900">AI Compliance Consultant</h3>
                            <p class="text-xs text-gray-500">Analysis for <?php echo $selected_semester; ?> <?php echo $selected_year; ?></p>
                        </div>
                    </div>
                    <div class="flex-1 px-10">
                        <div id="aiOutput" class="border-2 border-dashed border-indigo-200 rounded-xl p-3 text-center max-h-48 overflow-y-auto">
	                            <p class="text-sm text-indigo-400 italic">"Generate Analysis" to identify specific issues and recommendations for the selected academic period.</p>
	                        </div>
                    </div>
                    <button id="generateAI" class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2.5 rounded-xl font-semibold text-sm transition-all flex items-center gap-2 shadow-lg shadow-indigo-200">
	                        <i class="fas fa-wand-magic-sparkles"></i>
	                        <span id="btnText">Generate Analysis</span>
	                    </button>
                </div>

                <!-- Charts Grid -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <!-- Trend Chart -->
                    <div class="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                        <div class="mb-6">
                            <h3 class="font-bold text-gray-900">Multi-Year Compliance Trend</h3>
                            <p class="text-xs text-gray-400">Historical Performance (Global View)</p>
                        </div>
                        <div class="chart-container">
                            <canvas id="trendChart"></canvas>
                        </div>
                        <div class="mt-4 flex items-center justify-center gap-6 text-xs font-medium">
                            <div class="flex items-center gap-2"><span class="w-3 h-3 rounded-full bg-red-700"></span> Actual Compliance</div>
                            <div class="flex items-center gap-2"><span class="w-3 h-3 border-t-2 border-dashed border-green-600"></span> Strategic Target</div>
                        </div>
                    </div>

                    <!-- Bottlenecks Chart -->
                    <div class="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                        <div class="mb-6">
                            <h3 class="font-bold text-gray-900">Document Type Bottlenecks</h3>
                            <p class="text-xs text-gray-400">Issues in <?php echo $selected_year; ?> <?php echo $selected_semester; ?></p>
                        </div>
                        <div class="chart-container">
                            <canvas id="bottleneckChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Bottom Section -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <!-- Leaderboard -->
                    <div class="lg:col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                        <div class="p-6 border-b border-gray-50">
                            <h3 class="font-bold text-gray-900">Top Performing Units (<?php echo $selected_semester; ?>)</h3>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left">
                                <thead class="bg-gray-50/50 text-[10px] uppercase tracking-wider text-gray-400 font-bold">
                                    <tr>
                                        <th class="px-6 py-4">Rank</th>
                                        <th class="px-6 py-4">Unit Name</th>
                                        <th class="px-6 py-4 text-center">Completion Rate</th>
                                        <th class="px-6 py-4 text-right">Status</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-50">
                                    <?php foreach($units_data as $unit): ?>
                                    <tr class="hover:bg-gray-50/50 transition-colors">
                                        <td class="px-6 py-4 text-xs font-bold text-gray-400"><?php echo $unit['rank']; ?></td>
                                        <td class="px-6 py-4 text-sm font-bold text-gray-700"><?php echo $unit['name']; ?></td>
                                        <td class="px-6 py-4 text-center text-sm font-bold text-red-700"><?php echo $unit['rate']; ?></td>
                                        <td class="px-6 py-4 text-right">
                                            <span class="px-3 py-1 bg-gray-100 text-gray-500 rounded-full text-[10px] font-bold"><?php echo $unit['status']; ?></span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

    <script>
        // Trend Chart
        const trendCtx = document.getElementById('trendChart').getContext('2d');
        new Chart(trendCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($trend_data, 'year')); ?>,
                datasets: [{
                    label: 'Actual Compliance',
                    data: <?php echo json_encode(array_column($trend_data, 'rate')); ?>,
                    borderColor: '#800000',
                    backgroundColor: (context) => {
                        const gradient = context.chart.ctx.createLinearGradient(0, 0, 0, 400);
                        gradient.addColorStop(0, 'rgba(128, 0, 0, 0.4)');
                        gradient.addColorStop(1, 'rgba(128, 0, 0, 0)');
                        return gradient;
                    },
                    fill: true,
                    tension: 0.4,
                    borderWidth: 3,
                    pointRadius: 4,
                    pointBackgroundColor: '#fff',
                    pointBorderColor: '#800000',
                    pointBorderWidth: 2
                }, {
                    label: 'Strategic Target',
                    data: <?php echo json_encode(array_column($trend_data, 'target')); ?>,
                    borderColor: '#059669',
                    borderDash: [5, 5],
                    borderWidth: 2,
                    fill: false,
                    pointRadius: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        grid: { color: '#F3F4F6' },
                        ticks: { font: { size: 10 }, color: '#9CA3AF' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { font: { size: 10 }, color: '#9CA3AF' }
                    }
                }
            }
        });

        // Bottleneck Chart
        const bnCtx = document.getElementById('bottleneckChart').getContext('2d');
        new Chart(bnCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($bottleneck_data, 'name')); ?>,
                datasets: [{
                    data: <?php echo json_encode(array_column($bottleneck_data, 'value')); ?>,
                    backgroundColor: '#EF4444',
                    borderRadius: 4,
                    barThickness: 20
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { display: false }
                    },
                    y: {
                        grid: { display: false },
                        ticks: { font: { size: 11, weight: 'bold' }, color: '#374151' }
                    }
                }
            }
        });
        // Profile Dropdown Toggle
        const profileBtn = document.getElementById('profile-btn');
        const profileDropdown = document.getElementById('profile-dropdown');
        
        profileBtn.addEventListener('click', function() {
            profileDropdown.classList.toggle('active');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            if (!event.target.closest('#profile-btn') && !event.target.closest('#profile-dropdown')) {
                profileDropdown.classList.remove('active');
            }
        });
    </script>
    <script>
        document.getElementById('generateAI').addEventListener('click', async function() {
            const btn = this;
            const btnText = document.getElementById('btnText');
            const aiOutput = document.getElementById('aiOutput');
            const year = '<?php echo $selected_year; ?>';
            const semester = '<?php echo $selected_semester; ?>';

            // Disable button and show loading state
            btn.disabled = true;
            btn.classList.add('opacity-50', 'cursor-not-allowed');
            btnText.innerText = 'Generating...';
            aiOutput.innerHTML = '<div class="flex items-center justify-center py-4"><i class="fas fa-spinner fa-spin text-indigo-600 mr-2"></i> Analyzing data...</div>';

            try {
                const response = await fetch(`../../api/ai_analysis_api.php?action=generate_analysis&year=${encodeURIComponent(year)}&semester=${encodeURIComponent(semester)}`);
                const data = await response.json();

                if (data.success) {
                    // Use marked.js to render markdown if available, otherwise fallback to plain text
                    if (typeof marked !== 'undefined') {
                        aiOutput.innerHTML = '<div class="text-left text-sm text-gray-700 prose prose-sm max-w-none">' + marked.parse(data.analysis) + '</div>';
                    } else {
                        aiOutput.innerHTML = '<div class="text-left text-sm text-gray-700 whitespace-pre-wrap">' + data.analysis + '</div>';
                    }
                    aiOutput.classList.remove('text-center');
                    aiOutput.classList.add('border-solid', 'bg-white');
                    btnText.innerText = 'Regenerate Analysis';
                } else {
                    aiOutput.innerHTML = `<p class="text-sm text-red-500 font-medium"><i class="fas fa-exclamation-circle mr-1"></i> ${data.message}</p>`;
                    btnText.innerText = 'Generate Analysis';
                }
            } catch (error) {
                console.error('AI Analysis Error:', error);
                aiOutput.innerHTML = '<p class="text-sm text-red-500 font-medium"><i class="fas fa-exclamation-circle mr-1"></i> Failed to connect to AI service.</p>';
                btnText.innerText = 'Generate Analysis';
            } finally {
                btn.disabled = false;
                btn.classList.remove('opacity-50', 'cursor-not-allowed');
            }
        });
    </script>
</body>
</html>
