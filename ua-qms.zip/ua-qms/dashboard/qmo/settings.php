<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'QMO Admin'){ 
    header("Location: ../../index.php"); 
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UA QMS | System Settings & Control Tower</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Configure Custom Brand Colors for Tailwind -->
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#8b0000',
                        'primary-light': '#a52a2a', /* FIXED: Changed to kebab-case for correct hover parsing */
                    }
                }
            }
        }
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="../../assets/js/messaging.js" defer></script>
    <script src="../../assets/js/notifications.js" defer></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #F9FAFB; }
        .bg-ua-maroon { background-color: #800000; }
        .text-ua-maroon { color: #800000; }
        .glass-card { background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(10px); border: 1px solid rgba(229, 231, 235, 0.5); }
        .chart-container { position: relative; height: 300px; width: 100%; }
    </style>
</head>
<body class="bg-gray-50 font-sans text-gray-800 flex h-screen overflow-hidden">

    <?php include "../../includes/sidebar_qmo.php"; ?>

    <!-- Main Content -->
    <main class="flex-1 flex flex-col overflow-hidden">
        <!-- Topbar -->
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 flex-shrink-0">
            <h1 class="text-xl font-bold text-gray-800">UA QMS</h1>
            <div class="flex items-center gap-4">
                <div class="flex items-center gap-2">
                    <!-- Message Inbox -->
                        <button id="inbox-btn" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-envelope text-lg"></i>
                            <span id="message-badge" class="absolute top-1 right-1 w-4 h-4 bg-ua-maroon text-white text-[10px] flex items-center justify-center rounded-full hidden">0</span>
                        </button>
                    <!-- Notifications -->
                        <button id="notification-bell" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-bell text-lg"></i>
                            <span id="notification-badge" class="absolute top-1 right-1 min-w-[16px] h-4 px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center hidden">0</span>
                        </button>
                    <!-- Profile Dropdown -->
                        <div class="relative">
                            <button id="profile-btn" class="w-10 h-10 rounded-full bg-primary-light flex items-center justify-center text-white font-bold cursor-pointer hover:opacity-80 transition">
                                <?php echo isset($_SESSION['full_name']) ? substr($_SESSION['full_name'], 0, 1) : 'U'; ?>
                            </button>
                            <div id="profile-dropdown" class="profile-dropdown">
                                <div class="profile-dropdown-header">
                                    <p><?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></p>
                                    <span><?php echo htmlspecialchars($_SESSION['role'] ?? 'Role'); ?></span>
                                </div>
                                <a href="../../logout.php" class="profile-dropdown-item logout">
                                    <i class="fas fa-sign-out-alt"></i> Sign Out
                                </a>
                            </div>
                        </div>
                </div>
            </div>
        </header>

        <!-- Page Content -->
        <div class="flex-1 overflow-auto p-8">
            <div class="max-w-6xl mx-auto space-y-6">
                
                <!-- Header Area -->
                <div class="flex justify-between items-end mb-6">
                    <div>
                        <h1 class="text-3xl font-bold text-gray-800">System Settings</h1>
                        <p class="text-gray-500 mt-1">QMO Control Tower & Global Configuration</p>
                    </div>
                    <div class="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm border border-gray-200">
                        <span class="relative flex h-3 w-3">
                            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                            <span class="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                        </span>
                        <span class="font-semibold text-green-600 text-sm">System Live</span>
                    </div>
                </div>

                <!-- Settings Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    <!-- Academic Lifecycle (Card 1) -->
                    <div class="bg-gradient-to-br from-primary to-[#4a0000] text-white rounded-xl p-6 shadow-sm border border-gray-200">
                        <h2 class="text-xl font-bold mb-5 flex items-center gap-2">📅 Academic Lifecycle</h2>
                        <form id="academic-form" class="space-y-4">
                            <div>
                                <label class="block text-sm font-semibold mb-1 text-white/80">Active Academic Year</label>
                                <select name="active_academic_year" class="w-full p-2.5 rounded-md text-sm outline-none bg-white/10 text-white border border-white/20 focus:ring-2 focus:ring-white/50">
                                    <option value="2024-2025" class="text-gray-800">2024-2025</option>
                                    <option value="2025-2026" class="text-gray-800" selected>2025-2026</option>
                                    <option value="2026-2027" class="text-gray-800">2026-2027</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold mb-1 text-white/80">Active Semester</label>
                                <select name="active_semester" class="w-full p-2.5 rounded-md text-sm outline-none bg-white/10 text-white border border-white/20 focus:ring-2 focus:ring-white/50">
                                    <option value="1st Semester" class="text-gray-800">1st Semester</option>
                                    <option value="2nd Semester" class="text-gray-800">2nd Semester</option>
                                    <option value="Summer" class="text-gray-800">Summer</option>
                                </select>
                            </div>
                            <!-- FIXED HOVER: hover:bg-gray-100 handles the hover state here nicely -->
                            <button type="submit" class="w-full bg-white text-primary px-5 py-2.5 rounded-md font-semibold hover:bg-gray-100 transition-colors duration-200 shadow-sm hover:shadow">
                                Update Global Period
                            </button>
                        </form>

                        <div class="flex items-center justify-between bg-orange-50/10 p-4 rounded-lg border border-orange-100/20 mt-6">
                            <div>
                                <strong class="text-orange-300 block">Maintenance Mode</strong>
                                <p class="text-xs text-orange-200">Lock all submissions for auditing</p>
                            </div>
                            <!-- Tailwind Toggle Switch -->
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" id="maintenance-toggle" class="sr-only peer">
                                <div class="w-11 h-6 bg-white/30 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-500"></div>
                            </label>
                        </div>
                    </div>

                    <!-- AI Governance (Card 2) -->
                    <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                        <h2 class="text-xl font-bold mb-5 flex items-center gap-2 text-gray-700">🤖 AI Governance & Configuration</h2>
                        <form id="ai-form" class="space-y-4">
                            <div>
                                <label class="block text-sm font-semibold mb-1 text-gray-700">Google Gemini API Key</label>
                                <input type="password" class="w-full p-2.5 border border-gray-200 rounded-md text-sm focus:ring-2 focus:ring-primary outline-none" placeholder="Enter API Key" id="gemini-key">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold mb-1 text-gray-700 flex items-center gap-2">
                                    Model Specification
                                </label>
                                <select class="w-full p-2.5 border border-gray-200 rounded-md text-sm focus:ring-2 focus:ring-primary outline-none" id="gemini-model">
                                    <option value="gemini-1.5-flash">Gemini 1.5 Flash (Recommended)</option>
                                    <option value="gemini-2.0-flash">Gemini 2.0 Flash (Latest)</option>
                                </select>
                            </div>
                            <div class="flex gap-3 pt-2">
                                <button type="button" id="test-ai-btn" class="flex-1 px-5 py-2.5 rounded-md font-semibold border border-gray-200 text-gray-700 hover:bg-gray-100 transition-colors duration-200">Test Connection</button>
                                <!-- FIXED HOVER: Changed to hover:bg-primary-light -->
                                <button type="submit" class="flex-1 px-5 py-2.5 rounded-md font-semibold bg-primary text-white hover:bg-primary-light transition-colors duration-200 shadow-sm hover:shadow">Save Config</button>
                            </div>
                            <div id="ai-status" class="mt-3 text-sm hidden font-medium"></div>
                        </form>
                    </div>

    <!-- MAIN JAVASCRIPT LOGIC -->
    <script>
        async function loadDeadlines() {
            try {
                const res = await fetch('../../api/settings_api.php?action=get_deadlines');
                const data = await res.json();
                const tbody = document.getElementById('deadline-body');
                let html = '';
                
                data.deadlines.forEach(d => {
                    const deadlineDate = new Date(d.deadline);
                    const today = new Date();
                    const diffDays = Math.ceil((deadlineDate - today) / (1000 * 60 * 60 * 24));
                    
                    let statusClass = 'bg-green-100 text-green-800';
                    let statusText = 'On Track';
                    if (diffDays < 0) {
                        statusClass = 'bg-red-100 text-red-800';
                        statusText = 'Overdue';
                    } else if (diffDays < 7) {
                        statusClass = 'bg-yellow-100 text-yellow-800';
                        statusText = 'Due Soon';
                    }

                    const safeCode = d.doc_code.replace(/</g, "&lt;").replace(/>/g, "&gt;");
                    const safeDesc = d.description.replace(/</g, "&lt;").replace(/>/g, "&gt;");

                    html += `
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="py-3 px-4 font-bold text-gray-800">${safeCode}</td>
                            <td class="py-3 px-4 text-gray-600">${safeDesc}</td>
                            <td class="py-3 px-4">
                                <input type="date" class="border border-gray-200 rounded p-1 text-sm outline-none focus:ring-1 focus:ring-primary" 
                                value="${d.deadline}" onchange="updateDeadline(${d.target_id}, this.value)">
                            </td>
                            <td class="py-3 px-4">
                                <span class="px-2 py-1 rounded-full text-[11px] font-bold uppercase ${statusClass}">${statusText}</span>
                            </td>
                            <td class="py-3 px-4">
                                <button onclick="notifyUnit(${d.target_id})" class="px-3 py-1.5 border border-gray-200 text-gray-700 text-xs font-semibold rounded hover:bg-gray-100 transition-colors">Notify Unit</button>
                            </td>
                        </tr>
                    `;
                });
                tbody.innerHTML = html;
            } catch (err) {
                console.error("Failed to load deadlines", err);
            }
        }

        async function updateDeadline(id, date) {
            await fetch('../../api/settings_api.php?action=update_deadline', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ target_id: id, deadline: date })
            });
            loadDeadlines();
            loadLogs();
        }

        async function loadLogs() {
            try {
                const res = await fetch('../../api/settings_api.php?action=get_logs');
                const data = await res.json();
                const container = document.getElementById('audit-trail');
                let htmlString = '';
                
                data.logs.forEach(log => {
                    const safeAction = log.action.replace(/</g, "&lt;").replace(/>/g, "&gt;");
                    const safeDetails = log.details.replace(/</g, "&lt;").replace(/>/g, "&gt;");
                    
                    htmlString += `
                        <div class="flex gap-4 p-4 rounded-lg bg-gray-50 border border-gray-100 hover:bg-gray-100 transition-colors">
                            <div class="w-10 h-10 bg-white border border-gray-200 rounded-full flex items-center justify-center shrink-0 shadow-sm">
                                ⚙️
                            </div>
                            <div class="flex-1">
                                <div class="text-xs text-gray-400 mb-0.5">${new Date(log.created_at).toLocaleString()}</div>
                                <div class="font-semibold text-sm text-gray-800">${safeAction}</div>
                                <div class="text-[13px] text-gray-500 mt-1">By ${log.full_name}: ${safeDetails}</div>
                            </div>
                        </div>
                    `;
                });
                container.innerHTML = htmlString || '<div class="text-gray-500">No logs found.</div>';
            } catch (err) {
                console.error("Failed to load logs", err);
            }
        }

        document.getElementById('blast-btn').addEventListener('click', () => {
            document.getElementById('announcement-modal').classList.remove('hidden');
        });

        document.getElementById('confirm-blast').addEventListener('click', async function() {
            const title = document.getElementById('blast-title').value;
            const message = document.getElementById('blast-message').value;
            
            if(!title || !message) return alert("Fill in all fields!");

            this.disabled = true;
            this.innerText = "Sending...";
            
            try {
                const res = await fetch('../../api/settings_api.php?action=blast_announcement', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ title, message })
                });
                const data = await res.json();
                
                if(data.success) {
                    alert('Announcement blasted to all Unit heads!');
                    document.getElementById('announcement-modal').classList.add('hidden');
                    document.getElementById('blast-title').value = '';
                    document.getElementById('blast-message').value = '';
                    loadLogs();
                }
            } catch (err) {
                alert("Failed to send announcement.");
            } finally {
                this.disabled = false;
                this.innerText = "Blast to All Units";
            }
        });

        document.getElementById('academic-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const year = e.target.active_academic_year.value;
            const semester = e.target.active_semester.value;
            
            const res = await fetch('../../api/settings_api.php?action=update_period', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ year, semester })
            });
            const data = await res.json();
            if(data.success) {
                alert('Academic Lifecycle Period Updated!');
                loadLogs();
            }
        });

        document.getElementById('maintenance-toggle').addEventListener('change', async (e) => {
            const isEnabled = e.target.checked;
            const res = await fetch('../../api/settings_api.php?action=toggle_maintenance', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: isEnabled })
            });
            const data = await res.json();
            if(data.success) loadLogs();
        });

        document.getElementById('ai-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const apiKey = document.getElementById('gemini-key').value;
            const model = document.getElementById('gemini-model').value;
            const statusDiv = document.getElementById('ai-status');
            
            if (!apiKey) {
                statusDiv.classList.remove('hidden', 'text-green-600');
                statusDiv.classList.add('block', 'text-red-600');
                statusDiv.innerHTML = '❌ API Key cannot be empty';
                return;
            }
            
            statusDiv.classList.remove('hidden', 'text-red-600');
            statusDiv.classList.add('block', 'text-gray-600');
            statusDiv.innerHTML = 'Saving configuration...';

            try {
                const res = await fetch('../../api/settings_api.php?action=save_ai_config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ api_key: apiKey, model: model })
                });
                const data = await res.json();
                if(data.success) {
                    statusDiv.innerHTML = '✅ AI Configuration saved successfully!';
                    statusDiv.classList.replace('text-gray-600', 'text-green-600');
                    loadLogs();
                    setTimeout(() => statusDiv.classList.add('hidden'), 3000);
                } else {
                    statusDiv.innerHTML = `❌ Error: ${data.error || 'Failed to save'}`;
                    statusDiv.classList.replace('text-gray-600', 'text-red-600');
                }
            } catch (err) {
                statusDiv.innerHTML = `❌ Error: ${err.message}`;
                statusDiv.classList.replace('text-gray-600', 'text-red-600');
            }
        });

        document.getElementById('test-ai-btn').addEventListener('click', async () => {
            const apiKey = document.getElementById('gemini-key').value;
            const statusDiv = document.getElementById('ai-status');
            
            if (!apiKey) {
                statusDiv.classList.remove('hidden', 'text-green-600');
                statusDiv.classList.add('block', 'text-red-600');
                statusDiv.innerHTML = '❌ Please enter an API key first';
                return;
            }
            
            statusDiv.classList.remove('hidden', 'text-green-600', 'text-red-600');
            statusDiv.classList.add('block', 'text-gray-600');
            statusDiv.innerHTML = 'Testing connection...';
            
            try {
                const res = await fetch('../../api/settings_api.php?action=test_gemini');
                const data = await res.json();
                
                if (data.success) {
                    statusDiv.innerHTML = `✅ ${data.message}`;
                    statusDiv.classList.replace('text-gray-600', 'text-green-600');
                } else {
                    statusDiv.innerHTML = `❌ ${data.message}`;
                    statusDiv.classList.replace('text-gray-600', 'text-red-600');
                }
            } catch (err) {
                statusDiv.innerHTML = `❌ Connection failed: ${err.message}`;
                statusDiv.classList.replace('text-gray-600', 'text-red-600');
            }
        });

        async function notifyUnit(targetId) {
            const res = await fetch('../../api/settings_api.php?action=notify_unit', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ target_id: targetId })
            });
            const data = await res.json();
            if(data.success) {
                alert("Notification sent to the unit responsible.");
                loadLogs();
            }
        }

        loadDeadlines();
        loadLogs();
    

                // Profile Dropdown Toggle
        const profileBtn = document.getElementById('profile-btn');
        const profileDropdown = document.getElementById('profile-dropdown');
        
        if (profileBtn && profileDropdown) {
            profileBtn.addEventListener('click', function() {
                profileDropdown.classList.toggle('active');
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(event) {
                if (!event.target.closest('#profile-btn') && !event.target.closest('#profile-dropdown')) {
                    profileDropdown.classList.remove('active');
                }
            });
        }
    </script>
</body>
</html>