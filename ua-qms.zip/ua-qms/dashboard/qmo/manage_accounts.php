<?php
session_start();
require_once __DIR__ . "/../../config/db.php";

// Check authentication
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'QMO Admin') {
    header("Location: ../../index.php");
    exit();
}

// Define Units Constant
$ALL_UNITS = [
    "Administration and Finance Office",
    "Alumni Unit",
    "Admission/Registrarship Unit",
    "Accounting Unit",
    "Business Operations Unit",
    "Budget Unit",
    "College of Business and Management",
    "College of Computer Studies",
    "Campus Director/Administration",
    "Continuing Education Unit",
    "Career and Job Placement Unit",
    "College of Fisheries",
    "Civil Security Services Unit",
    "College of Teacher Education",
    "Cash Unit",
    "Cultural Unit",
    "Academic Affairs Office",
    "External Affairs Unit",
    "Extension Unit",
    "Gender and Development Unit",
    "Guidance Unit",
    "Human Resource Unit",
    "Health Unit",
    "International Affairs Unit",
    "Information and Communications Technology Unit",
    "Innovation Promotion Unit",
    "Information Unit",
    "Laboratory High School",
    "National Service Training Program Unit",
    "Planning Unit",
    "Project Management Unit",
    "Procurement Unit",
    "Quality Management Office",
    "Quality Assurance Unit",
    "Records Unit",
    "Research Unit",
    "Student Affairs Services Division",
    "Students Discipline Unit",
    "Supply and Property Management Unit",
    "Sports Unit",
    "Library",
    "Research Extension and Innovation"
];

// Handle API Actions
if (isset($_GET['action']) || isset($_POST['action'])) {
    header("Content-Type: application/json");
    $action = $_POST["action"] ?? $_GET["action"] ?? null;

    function response($success, $message, $data = null) {
        echo json_encode(["success" => $success, "message" => $message, "data" => $data]);
        exit;
    }

    function tempPassword($length = 8) {
        return substr(str_shuffle("ABCDEFGHJKLMNPQRSTUVWXYZ23456789"), 0, $length);
    }

    if ($action === "fetch") {
        $result = $conn->query("
            SELECT user_id as id, full_name as name, email, role, 
            (SELECT office_name FROM offices WHERE offices.office_id = users.office_id) as unit, 
            status, created_at, 
            COALESCE(last_active, created_at) as last_active 
            FROM users 
            ORDER BY created_at DESC
        ");
        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        response(true, "Users loaded", $users);
    }

    if ($action === "approve") {
        $ids = $_POST["ids"] ?? [];
        if (empty($ids)) response(false, "No users selected");
        $idList = implode(",", array_map("intval", $ids));
        $conn->query("UPDATE users SET status='Active' WHERE user_id IN ($idList)");
        response(true, "Users approved");
    }

    if ($action === "delete") {
        $ids = $_POST["ids"] ?? [];
        if (empty($ids)) response(false, "No users selected");
        $idList = implode(",", array_map("intval", $ids));
        $conn->query("DELETE FROM users WHERE user_id IN ($idList)");
        response(true, "Users deleted");
    }

    if ($action === "toggleStatus") {
        $id = (int)$_POST["id"];
        $conn->query("UPDATE users SET status = IF(status='Active','Suspended','Active') WHERE user_id = $id");
        response(true, "Status updated");
    }

    if ($action === "resetPassword") {
        $id = (int)$_POST["id"];
        $temp = tempPassword();
        $hash = password_hash($temp, PASSWORD_DEFAULT);
        $conn->query("UPDATE users SET password='$hash' WHERE user_id=$id");
        response(true, "Password reset", ["temporaryPassword" => $temp]);
    }

    if ($action === "add") {
        $name  = $conn->real_escape_string($_POST["name"]);
        $email = $conn->real_escape_string($_POST["email"]);
        $role  = $conn->real_escape_string($_POST["role"]);
        $unit_name = $conn->real_escape_string($_POST["unit"]);

        // Find or create office
        $office_res = $conn->query("SELECT office_id FROM offices WHERE office_name = '$unit_name'");
        if ($office_res->num_rows > 0) {
            $office_id = $office_res->fetch_assoc()['office_id'];
        } else {
            $conn->query("INSERT INTO offices (office_name) VALUES ('$unit_name')");
            $office_id = $conn->insert_id;
        }

        $temp = tempPassword();
        $hash = password_hash($temp, PASSWORD_DEFAULT);
        $conn->query("INSERT INTO users (full_name, email, role, office_id, password, status) VALUES ('$name','$email','$role',$office_id,'$hash','Active')");
        response(true, "Account created", ["temporaryPassword" => $temp]);
    }

    response(false, "Invalid action");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Accounts | UA QMS</title>
    <link rel="stylesheet" href="../../assets/css/dashboard.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="../../assets/js/messaging.js" defer></script>
    <script src="../../assets/js/notifications.js" defer></script>
    <style>
        :root {
            --ua-maroon: #800000;
            --ua-gold: #FFD700;
            --ua-green: #006400;
        }
        .bg-ua-maroon { background-color: var(--ua-maroon); }
        .text-ua-maroon { color: var(--ua-maroon); }
        .border-ua-maroon { border-color: var(--ua-maroon); }
        .bg-ua-gold { background-color: var(--ua-gold); }
        .bg-ua-green { background-color: var(--ua-green); }
        
        .glass {
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }
        
        .sticky-header th {
            position: sticky;
            top: 0;
            background: white;
            z-index: 10;
            box-shadow: 0 1px 0 rgba(0,0,0,0.1);
        }

        .floating-toolbar {
            transform: translateY(100px);
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .floating-toolbar.active {
            transform: translateY(0);
        }

        .group:hover .group-hover-visible {
            opacity: 1;
        }
        .group-hover-visible {
            opacity: 0;
            transition: opacity 0.2s;
        }
    </style>
</head>
<body class="bg-gray-50 font-sans" data-user-role="<?php echo htmlspecialchars($_SESSION['role']); ?>">
    <script>localStorage.setItem('userRole', '<?php echo htmlspecialchars($_SESSION['role']); ?>');</script>
    <div class="flex h-screen overflow-hidden">
        <?php include "../../includes/sidebar_qmo.php"; ?>

        <!-- Main Content -->
        <main class="flex-1 flex flex-col overflow-hidden">
            <!-- Topbar -->
            <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 flex-shrink-0">
                <h1 class="text-xl font-bold text-gray-800">Account Management</h1>
                <div class="flex items-center gap-4">
                    <div class="flex items-center gap-2">
                        <!-- Message Inbox -->
                        <button id="inbox-btn" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-envelope text-lg"></i>
                            <span id="message-badge" class="absolute top-1 right-1 w-4 h-4 bg-ua-maroon text-white text-[10px] flex items-center justify-center rounded-full hidden">0</span>
                        </button>
                        <!-- Notifications -->
                        <button id="notification-bell" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-bell text-lg"></i>
                            <span id="notification-badge" class="absolute top-1 right-1 min-w-[16px] h-4 px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center hidden">0</span>
                        </button>
                    </div>
                    <button onclick="openModal('addAccountModal')" class="bg-ua-maroon text-white px-4 py-2 rounded-lg hover:bg-red-900 transition flex items-center gap-2 shadow-sm">
                        <i class="fas fa-plus"></i> Add Account
                    </button>
                    <!-- Profile Dropdown -->
                        <div class="relative">
                            <button id="profile-btn" class="w-10 h-10 rounded-full bg-ua-maroon flex items-center justify-center text-white font-bold cursor-pointer hover:opacity-80 transition">
                                <?php echo isset($_SESSION['full_name']) ? substr($_SESSION['full_name'], 0, 1) : 'U'; ?>
                            </button>
                            <div id="profile-dropdown" class="profile-dropdown">
                                <div class="profile-dropdown-header">
                                    <p><?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></p>
                                    <span><?php echo htmlspecialchars($_SESSION['role'] ?? 'Role'); ?></span>
                                </div>
                                <a href="../../logout.php" class="profile-dropdown-item logout">
                                    <i class="fas fa-sign-out-alt"></i> Sign Out
                                </a>
                            </div>
                        </div>
                </div>
                
            </header>

            <!-- Table Content -->
            <div class="flex-1 overflow-auto p-8">
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden flex flex-col h-full">
                    <div class="overflow-auto flex-1">
                        <table class="w-full text-left border-collapse">
                            <thead class="sticky-header">
                                <tr class="bg-gray-50">
                                    <th class="p-4 w-12">
                                        <input type="checkbox" id="selectAll" class="rounded border-gray-300 text-ua-maroon focus:ring-ua-maroon">
                                    </th>
                                    <th class="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">User</th>
                                    <th class="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Role & Unit</th>
                                    <th class="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                                    <th class="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Activity</th>
                                    <th class="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="userTableBody" class="divide-y divide-gray-100">
                                <!-- Users will be loaded here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>

    <!-- Add Account Modal -->
    <div id="addAccountModal" class="fixed inset-0 bg-black/50 hidden items-center justify-center z-[60] backdrop-blur-sm">
        <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200">
            <div class="p-6 border-b border-gray-100 flex justify-between items-center">
                <h3 class="text-xl font-bold text-gray-800">Create New Account</h3>
                <button onclick="closeModal('addAccountModal')" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times"></i></button>
            </div>
            <form id="addAccountForm" class="p-6 space-y-4">
                <input type="hidden" name="action" value="add">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                    <input type="text" name="name" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ua-maroon focus:border-ua-maroon outline-none transition">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                    <input type="email" name="email" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ua-maroon focus:border-ua-maroon outline-none transition">
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Role</label>
                        <select name="role" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ua-maroon focus:border-ua-maroon outline-none transition">
                            <option value="Office">Unit User</option>
                            <option value="QMO Admin">QMO Admin</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Unit</label>
                        <select name="unit" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ua-maroon focus:border-ua-maroon outline-none transition">
                            <?php foreach($ALL_UNITS as $unit): ?>
                                <option value="<?php echo $unit; ?>"><?php echo $unit; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="pt-4">
                    <button type="submit" class="w-full bg-ua-maroon text-white py-3 rounded-xl font-bold hover:bg-red-900 transition shadow-lg">
                        Create Account
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Password Reset Modal -->
    <div id="passwordModal" class="fixed inset-0 bg-black/50 hidden items-center justify-center z-[70] backdrop-blur-sm">
        <div class="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden p-8 text-center">
            <div class="w-16 h-16 bg-ua-gold/20 text-ua-gold rounded-full flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-key text-2xl"></i>
            </div>
            <h3 class="text-xl font-bold text-gray-800 mb-2">Temporary Password</h3>
            <p class="text-gray-500 text-sm mb-6">Please share this temporary password with the user. They should change it after logging in.</p>
            <div class="bg-gray-100 p-4 rounded-xl font-mono text-2xl font-bold tracking-widest text-ua-maroon mb-6" id="tempPasswordDisplay">
                --------
            </div>
            <button onclick="closeModal('passwordModal')" class="w-full bg-gray-800 text-white py-3 rounded-xl font-bold hover:bg-black transition">
                Got it
            </button>
        </div>
    </div>

    <script>
        let users = [];
        const selectedIds = new Set();

        async function fetchUsers() {
            const res = await fetch('manage_accounts.php?action=fetch');
            const data = await res.json();
            if (data.success) {
                users = data.data;
                renderTable();
            }
        }

        function renderTable() {
            const tbody = document.getElementById('userTableBody');
            tbody.innerHTML = users.map(user => `
                <tr class="group hover:bg-gray-50 transition-colors">
                    <td class="p-4">
                        <input type="checkbox" class="user-checkbox rounded border-gray-300 text-ua-maroon focus:ring-ua-maroon" 
                               value="${user.id}" ${selectedIds.has(user.id.toString()) ? 'checked' : ''} 
                               onchange="toggleSelect('${user.id}')">
                    </td>
                    <td class="p-4">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 font-bold">
                                ${user.name.charAt(0)}
                            </div>
                            <div>
                                <p class="font-medium text-gray-900">${user.name}</p>
                                <p class="text-xs text-gray-500">${user.email}</p>
                            </div>
                        </div>
                    </td>
                    <td class="p-4">
                        <p class="text-sm font-medium text-gray-700">${user.role}</p>
                        <p class="text-xs text-gray-500">${user.unit || 'N/A'}</p>
                    </td>
                    <td class="p-4">
                        <span class="px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            user.status === 'Active' ? 'bg-green-100 text-green-800' : 
                            user.status === 'Suspended' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                        }">
                            ${user.status}
                        </span>
                    </td>
                    <td class="p-4">
                        <p class="text-xs text-gray-500">Created: ${new Date(user.created_at).toLocaleDateString()}</p>
                        <p class="text-xs font-medium text-gray-700">Last Active: ${user.last_active ? new Date(user.last_active).toLocaleString() : 'Never'}</p>
                    </td>
                    <td class="p-4 text-right">
                        <div class="flex justify-end gap-2 group-hover-visible">
                            <button onclick="toggleStatus(${user.id})" title="${user.status === 'Active' ? 'Suspend' : 'Activate'}" class="p-2 text-gray-400 hover:text-ua-maroon transition">
                                <i class="fas ${user.status === 'Active' ? 'fa-lock' : 'fa-lock-open'}"></i>
                            </button>
                            <button onclick="resetPassword(${user.id})" title="Reset Password" class="p-2 text-gray-400 hover:text-ua-gold transition">
                                <i class="fas fa-key"></i>
                            </button>
                            <button onclick="deleteUser(${user.id})" title="Delete Account" class="p-2 text-gray-400 hover:text-red-600 transition">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `).join('');
            updateToolbar();
        }

        function toggleSelect(id) {
            if (selectedIds.has(id)) selectedIds.delete(id);
            else selectedIds.add(id);
            updateToolbar();
        }

        document.getElementById('selectAll').onchange = (e) => {
            const checkboxes = document.querySelectorAll('.user-checkbox');
            checkboxes.forEach(cb => {
                cb.checked = e.target.checked;
                if (e.target.checked) selectedIds.add(cb.value);
                else selectedIds.delete(cb.value);
            });
            updateToolbar();
        };

        function updateToolbar() {
            const toolbar = document.getElementById('floatingToolbar');
            const count = document.getElementById('selectedCount');
            count.innerText = selectedIds.size;
            if (selectedIds.size > 0) toolbar.classList.add('active');
            else toolbar.classList.remove('active');
        }

        function clearSelection() {
            selectedIds.clear();
            document.getElementById('selectAll').checked = false;
            renderTable();
        }

        async function bulkAction(action) {
            if (!confirm(`Are you sure you want to ${action} the selected users?`)) return;
            const formData = new FormData();
            formData.append('action', action);
            selectedIds.forEach(id => formData.append('ids[]', id));
            
            const res = await fetch('manage_accounts.php', { method: 'POST', body: formData });
            const data = await res.json();
            if (data.success) {
                selectedIds.clear();
                fetchUsers();
            }
        }

        async function toggleStatus(id) {
            const formData = new FormData();
            formData.append('action', 'toggleStatus');
            formData.append('id', id);
            const res = await fetch('manage_accounts.php', { method: 'POST', body: formData });
            const data = await res.json();
            if (data.success) fetchUsers();
        }

        async function resetPassword(id) {
            if (!confirm('Reset password for this user?')) return;
            const formData = new FormData();
            formData.append('action', 'resetPassword');
            formData.append('id', id);
            const res = await fetch('manage_accounts.php', { method: 'POST', body: formData });
            const data = await res.json();
            if (data.success) {
                document.getElementById('tempPasswordDisplay').innerText = data.data.temporaryPassword;
                openModal('passwordModal');
            }
        }

        async function deleteUser(id) {
            if (!confirm('Permanently delete this account?')) return;
            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('ids[]', id);
            const res = await fetch('manage_accounts.php', { method: 'POST', body: formData });
            const data = await res.json();
            if (data.success) fetchUsers();
        }

        document.getElementById('addAccountForm').onsubmit = async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const res = await fetch('manage_accounts.php', { method: 'POST', body: formData });
            const data = await res.json();
            if (data.success) {
                closeModal('addAccountModal');
                e.target.reset();
                document.getElementById('tempPasswordDisplay').innerText = data.data.temporaryPassword;
                openModal('passwordModal');
                fetchUsers();
            }
        };

        function openModal(id) {
            document.getElementById(id).classList.remove('hidden');
            document.getElementById(id).classList.add('flex');
        }

        function closeModal(id) {
            document.getElementById(id).classList.add('hidden');
            document.getElementById(id).classList.remove('flex');
        }

        // Initial Load
        fetchUsers();
    

                // Profile Dropdown Toggle
        const profileBtn = document.getElementById('profile-btn');
        const profileDropdown = document.getElementById('profile-dropdown');
        
        if (profileBtn && profileDropdown) {
            profileBtn.addEventListener('click', function() {
                profileDropdown.classList.toggle('active');
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(event) {
                if (!event.target.closest('#profile-btn') && !event.target.closest('#profile-dropdown')) {
                    profileDropdown.classList.remove('active');
                }
            });
        }
    </script>
</body>
</html>
