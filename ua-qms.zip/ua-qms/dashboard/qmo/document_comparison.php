<?php
/**
 * Document Comparison View
 * Feature 2: Admin can see previous and new documents and automatically view paired documents
 */

session_start();
include "../../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'QMO Admin') {
    header('Location: ../../index.php');
    exit();
}

$comparison_id = $_GET['comparison_id'] ?? null;
$office_id = $_GET['office_id'] ?? null;

// Fetch comparison details if comparison_id is provided
$comparison = null;
$previous_doc = null;
$current_doc = null;

if ($comparison_id) {
    $sql = "SELECT dc.*, 
                   prev_d.file_name as prev_file_name, prev_d.file_path as prev_file_path, prev_d.submitted_at as prev_submitted_at, prev_d.status as prev_status,
                   curr_d.file_name as curr_file_name, curr_d.file_path as curr_file_path, curr_d.submitted_at as curr_submitted_at, curr_d.status as curr_status,
                   o.office_name, o.office_code
            FROM document_comparisons dc
            JOIN documents prev_d ON dc.previous_document_id = prev_d.document_id
            JOIN documents curr_d ON dc.current_document_id = curr_d.document_id
            JOIN offices o ON curr_d.office_id = o.office_id
            WHERE dc.comparison_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $comparison_id);
    $stmt->execute();
    $comparison = $stmt->get_result()->fetch_assoc();
}

// Fetch all comparisons for an office or all offices
$comparisons = [];
if ($office_id) {
    $sql_list = "SELECT dc.*, 
                        prev_d.file_name as prev_file_name, prev_d.status as prev_status,
                        curr_d.file_name as curr_file_name, curr_d.status as curr_status,
                        o.office_name, o.office_code
                 FROM document_comparisons dc
                 JOIN documents prev_d ON dc.previous_document_id = prev_d.document_id
                 JOIN documents curr_d ON dc.current_document_id = curr_d.document_id
                 JOIN offices o ON curr_d.office_id = o.office_id
                 WHERE curr_d.office_id = ?
                 ORDER BY dc.comparison_date DESC";
    
    $stmt_list = $conn->prepare($sql_list);
    $stmt_list->bind_param("i", $office_id);
    $stmt_list->execute();
    $result_list = $stmt_list->get_result();
    while ($row = $result_list->fetch_assoc()) {
        $comparisons[] = $row;
    }
} else {
    $sql_list = "SELECT dc.*, 
                        prev_d.file_name as prev_file_name, prev_d.status as prev_status,
                        curr_d.file_name as curr_file_name, curr_d.status as curr_status,
                        o.office_name, o.office_code
                 FROM document_comparisons dc
                 JOIN documents prev_d ON dc.previous_document_id = prev_d.document_id
                 JOIN documents curr_d ON dc.current_document_id = curr_d.document_id
                 JOIN offices o ON curr_d.office_id = o.office_id
                 ORDER BY dc.comparison_date DESC
                 LIMIT 50";
    
    $stmt_list = $conn->prepare($sql_list);
    $stmt_list->execute();
    $result_list = $stmt_list->get_result();
    while ($row = $result_list->fetch_assoc()) {
        $comparisons[] = $row;
    }
}

// Fetch all offices for filter
$offices = [];
$sql_offices = "SELECT office_id, office_name, office_code FROM offices WHERE status = 'Active' ORDER BY office_name";
$result_offices = $conn->query($sql_offices);
while ($row = $result_offices->fetch_assoc()) {
    $offices[] = $row;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document Comparison | UA QMS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="../../assets/js/messaging.js" defer></script>
    <script src="../../assets/js/notifications.js" defer></script>
    <link rel="stylesheet" href="../../assets/css/file-viewer.css">
    <script src="../../assets/js/file-viewer.js" defer></script>
    <style>
        :root {
            --ua-maroon: #800000;
            --ua-gold: #FFD700;
            --ua-green: #006400;
        }
        .bg-ua-maroon { background-color: var(--ua-maroon); }
        .text-ua-maroon { color: var(--ua-maroon); }
        .border-ua-maroon { border-color: var(--ua-maroon); }
    </style>
</head>
<body class="bg-gray-50 font-sans" data-user-role="<?php echo htmlspecialchars($_SESSION['role']); ?>">
    <script>localStorage.setItem('userRole', '<?php echo htmlspecialchars($_SESSION['role']); ?>');</script>
    <div class="flex h-screen overflow-hidden">
        <?php include "../../includes/sidebar_qmo.php"; ?>

        <!-- Main Content -->
        <main class="flex-1 flex flex-col overflow-hidden">
            <!-- Topbar -->
            <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 flex-shrink-0">
                <h1 class="text-xl font-bold text-gray-800">Document Comparison</h1>
                <div class="flex items-center gap-6">
                    <div class="flex items-center gap-2">
                        <!-- Message Inbox -->
                        <button id="inbox-btn" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-envelope text-lg"></i>
                            <span id="message-badge" class="absolute top-1 right-1 w-4 h-4 bg-ua-maroon text-white text-[10px] flex items-center justify-center rounded-full hidden">0</span>
                        </button>
                        <!-- Notifications -->
                        <button id="notification-bell" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-bell text-lg"></i>
                            <span id="notification-badge" class="absolute top-1 right-1 min-w-[16px] h-4 px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center hidden">0</span>
                        </button>
                        <!-- Profile Dropdown -->
                        <div class="relative">
                            <button id="profile-btn" class="w-10 h-10 rounded-full bg-ua-maroon flex items-center justify-center text-white font-bold cursor-pointer hover:opacity-80 transition">
                                <?php echo isset($_SESSION['full_name']) ? substr($_SESSION['full_name'], 0, 1) : 'U'; ?>
                            </button>
                            <div id="profile-dropdown" class="profile-dropdown">
                                <div class="profile-dropdown-header">
                                    <p><?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></p>
                                    <span><?php echo htmlspecialchars($_SESSION['role'] ?? 'Role'); ?></span>
                                </div>
                                <a href="../../logout.php" class="profile-dropdown-item logout">
                                    <i class="fas fa-sign-out-alt"></i> Sign Out
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Page Content -->
            <div class="flex-1 overflow-auto p-8">
                <?php if ($comparison): ?>
                    <!-- Detailed Comparison View -->
                    <div class="mb-6">
                        <a href="document_comparison.php" class="text-ua-maroon hover:underline flex items-center gap-2">
                            <i class="fas fa-arrow-left"></i> Back to Comparisons
                        </a>
                    </div>

                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
                        <div class="mb-8">
                            <h2 class="text-2xl font-bold text-gray-900 mb-2">
                                <?php echo htmlspecialchars($comparison['office_name']); ?>
                            </h2>
                            <p class="text-gray-600">
                                <i class="fas fa-calendar mr-2"></i>
                                Compared on <?php echo date('M d, Y H:i', strtotime($comparison['comparison_date'])); ?>
                            </p>
                        </div>

                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <!-- Previous Document -->
                            <div class="border-2 border-gray-300 rounded-lg p-6">
                                <div class="bg-gray-100 px-4 py-3 rounded-lg mb-4 flex items-center gap-2">
                                    <i class="fas fa-history text-gray-600"></i>
                                    <h3 class="font-bold text-gray-800">Previous Version</h3>
                                </div>
                                <div class="space-y-4">
                                    <div>
                                        <p class="text-sm text-gray-600 mb-1">File Name</p>
                                        <p class="font-semibold text-gray-900"><?php echo htmlspecialchars($comparison['prev_file_name']); ?></p>
                                    </div>
                                    <div>
                                        <p class="text-sm text-gray-600 mb-1">Submitted</p>
                                        <p class="font-semibold text-gray-900"><?php echo date('M d, Y H:i', strtotime($comparison['prev_submitted_at'])); ?></p>
                                    </div>
                                    <div>
                                        <p class="text-sm text-gray-600 mb-1">Status</p>
                                        <span class="inline-block px-3 py-1 rounded-full text-sm font-semibold bg-gray-100 text-gray-800">
                                            <?php echo htmlspecialchars($comparison['prev_status']); ?>
                                        </span>
                                    </div>
                                    <div class="flex gap-2">
                                        <button onclick="openFileViewer('<?php echo htmlspecialchars($comparison['prev_file_path']); ?>', '<?php echo htmlspecialchars($comparison['prev_file_name']); ?>')" class="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                                            <i class="fas fa-eye"></i> Preview
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Current Document -->
                            <div class="border-2 border-ua-maroon rounded-lg p-6">
                                <div class="bg-ua-maroon px-4 py-3 rounded-lg mb-4 flex items-center gap-2 text-white">
                                    <i class="fas fa-file-check"></i>
                                    <h3 class="font-bold">Current Version (Revised)</h3>
                                </div>
                                <div class="space-y-4">
                                    <div>
                                        <p class="text-sm text-gray-600 mb-1">File Name</p>
                                        <p class="font-semibold text-gray-900"><?php echo htmlspecialchars($comparison['curr_file_name']); ?></p>
                                    </div>
                                    <div>
                                        <p class="text-sm text-gray-600 mb-1">Submitted</p>
                                        <p class="font-semibold text-gray-900"><?php echo date('M d, Y H:i', strtotime($comparison['curr_submitted_at'])); ?></p>
                                    </div>
                                    <div>
                                        <p class="text-sm text-gray-600 mb-1">Status</p>
                                        <span class="inline-block px-3 py-1 rounded-full text-sm font-semibold bg-green-100 text-green-800">
                                            <?php echo htmlspecialchars($comparison['curr_status']); ?>
                                        </span>
                                    </div>
                                    <div class="flex gap-2">
                                        <button onclick="openFileViewer('<?php echo htmlspecialchars($comparison['curr_file_path']); ?>', '<?php echo htmlspecialchars($comparison['curr_file_name']); ?>')" class="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                                            <i class="fas fa-eye"></i> Preview
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php if (!empty($comparison['admin_notes'])): ?>
                            <div class="mt-8 p-6 bg-blue-50 border border-blue-200 rounded-lg">
                                <h4 class="font-bold text-blue-900 mb-2">
                                    <i class="fas fa-sticky-note mr-2"></i> Admin Notes
                                </h4>
                                <p class="text-blue-800"><?php echo htmlspecialchars($comparison['admin_notes']); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>

                <?php else: ?>
                    <!-- Comparisons List View -->
                    <div class="mb-6 flex gap-4 items-end">
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Filter by Office</label>
                            <select onchange="filterByOffice(this.value)" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ua-maroon outline-none">
                                <option value="">All Offices</option>
                                <?php foreach ($offices as $off): ?>
                                    <option value="<?php echo $off['office_id']; ?>" <?php echo ($office_id == $off['office_id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($off['office_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                        <div class="p-6 border-b border-gray-200">
                            <h2 class="text-lg font-bold text-gray-800">Document Comparisons</h2>
                            <p class="text-sm text-gray-600 mt-1">View paired documents showing previous and revised versions</p>
                        </div>

                        <?php if (empty($comparisons)): ?>
                            <div class="p-12 text-center">
                                <i class="fas fa-inbox text-gray-400 text-4xl mb-4 block"></i>
                                <p class="text-gray-600 font-semibold">No document comparisons found.</p>
                                <p class="text-gray-500 text-sm mt-1">Document comparisons will appear here when revisions are submitted.</p>
                            </div>
                        <?php else: ?>
                            <div class="overflow-x-auto">
                                <table class="w-full">
                                    <thead>
                                        <tr class="bg-gray-50 border-b border-gray-200">
                                            <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Office</th>
                                            <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Previous Document</th>
                                            <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Current Document</th>
                                            <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Compared Date</th>
                                            <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Status</th>
                                            <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-gray-200">
                                        <?php foreach ($comparisons as $comp): ?>
                                            <tr class="hover:bg-gray-50 transition">
                                                <td class="px-6 py-4">
                                                    <div class="font-semibold text-gray-900"><?php echo htmlspecialchars($comp['office_name']); ?></div>
                                                    <div class="text-sm text-gray-600"><?php echo htmlspecialchars($comp['office_code']); ?></div>
                                                </td>
                                                <td class="px-6 py-4">
                                                    <div class="text-sm text-gray-900"><?php echo htmlspecialchars(substr($comp['prev_file_name'], 0, 30)); ?></div>
                                                    <div class="text-xs text-gray-500">v1</div>
                                                </td>
                                                <td class="px-6 py-4">
                                                    <div class="text-sm text-gray-900"><?php echo htmlspecialchars(substr($comp['curr_file_name'], 0, 30)); ?></div>
                                                    <div class="text-xs text-gray-500">v2+</div>
                                                </td>
                                                <td class="px-6 py-4">
                                                    <div class="text-sm text-gray-900"><?php echo date('M d, Y', strtotime($comp['comparison_date'])); ?></div>
                                                </td>
                                                <td class="px-6 py-4">
                                                    <span class="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
                                                        <i class="fas fa-code-branch"></i> Paired
                                                    </span>
                                                </td>
                                                <td class="px-6 py-4">
                                                    <a href="document_comparison.php?comparison_id=<?php echo $comp['comparison_id']; ?>" class="inline-flex items-center gap-2 px-3 py-1 bg-ua-maroon text-white rounded hover:bg-opacity-90 transition text-sm">
                                                        <i class="fas fa-eye"></i> View
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script>
        function filterByOffice(officeId) {
            if (officeId) {
                window.location.href = 'document_comparison.php?office_id=' + officeId;
            } else {
                window.location.href = 'document_comparison.php';
            }
        }
    

                // Profile Dropdown Toggle
        const profileBtn = document.getElementById('profile-btn');
        const profileDropdown = document.getElementById('profile-dropdown');
        
        if (profileBtn && profileDropdown) {
            profileBtn.addEventListener('click', function() {
                profileDropdown.classList.toggle('active');
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(event) {
                if (!event.target.closest('#profile-btn') && !event.target.closest('#profile-dropdown')) {
                    profileDropdown.classList.remove('active');
                }
            });
        }
    </script>
</body>
</html>
