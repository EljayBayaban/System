<?php
/**
 * Analytics and Compliance Dashboard
 * Feature 6: Content determined by system with analytics
 * Feature 7: Officer compliance tracking and reporting
 */

session_start();
include "../../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'QMO Admin') {
    header('Location: ../../index.php');
    exit();
}

$year = $_GET['year'] ?? date('Y');
$quarter = $_GET['quarter'] ?? '1st Quarter';

// Get submission statistics
$sql_submissions = "SELECT COUNT(*) as total_submissions,
                          SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) as approved,
                          SUM(CASE WHEN status = 'Awaiting Review' THEN 1 ELSE 0 END) as pending,
                          SUM(CASE WHEN status = 'Revision' THEN 1 ELSE 0 END) as revision,
                          SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END) as rejected
                   FROM documents
                   WHERE YEAR(submitted_at) = ?";
$stmt_submissions = $conn->prepare($sql_submissions);
$stmt_submissions->bind_param("s", $year);
$stmt_submissions->execute();
$submissions_stats = $stmt_submissions->get_result()->fetch_assoc();

// Get average review time
$sql_review_time = "SELECT AVG(DATEDIFF(review_date, submission_date)) as avg_review_days,
                           MIN(DATEDIFF(review_date, submission_date)) as min_review_days,
                           MAX(DATEDIFF(review_date, submission_date)) as max_review_days
                    FROM document_analytics
                    WHERE review_date IS NOT NULL AND YEAR(submission_date) = ?";
$stmt_review_time = $conn->prepare($sql_review_time);
$stmt_review_time->bind_param("s", $year);
$stmt_review_time->execute();
$review_time = $stmt_review_time->get_result()->fetch_assoc();

// Get document type distribution
$sql_doc_types = "SELECT dt.doc_code, dt.description, COUNT(d.document_id) as count,
                         SUM(CASE WHEN d.status = 'Approved' THEN 1 ELSE 0 END) as approved_count
                  FROM document_types dt
                  LEFT JOIN documents d ON dt.doc_type_id = d.doc_type_id AND YEAR(d.submitted_at) = ?
                  GROUP BY dt.doc_type_id, dt.doc_code, dt.description
                  ORDER BY count DESC";
$stmt_doc_types = $conn->prepare($sql_doc_types);
$stmt_doc_types->bind_param("s", $year);
$stmt_doc_types->execute();
$doc_types_result = $stmt_doc_types->get_result();

$doc_types = [];
while ($row = $doc_types_result->fetch_assoc()) {
    $doc_types[] = $row;
}

// Get office compliance ranking
$sql_offices = "SELECT o.office_id, o.office_name, o.office_code,
                       COUNT(d.document_id) as total_docs,
                       SUM(CASE WHEN d.status = 'Approved' THEN 1 ELSE 0 END) as approved_docs
                FROM offices o
                LEFT JOIN documents d ON o.office_id = d.office_id AND YEAR(d.submitted_at) = ?
                WHERE o.status = 'Active'
                GROUP BY o.office_id, o.office_name, o.office_code
                ORDER BY approved_docs DESC
                LIMIT 10";
$stmt_offices = $conn->prepare($sql_offices);
$stmt_offices->bind_param("s", $year);
$stmt_offices->execute();
$offices_result = $stmt_offices->get_result();

$offices = [];
while ($row = $offices_result->fetch_assoc()) {
    $compliance_rate = $row['total_docs'] > 0 ? round(($row['approved_docs'] / $row['total_docs']) * 100) : 0;
    $row['compliance_rate'] = $compliance_rate;
    $offices[] = $row;
}

// Get content recommendations based on analytics
$sql_analysis = "SELECT dt.doc_code, dt.description,
                        COUNT(d.document_id) as submission_count,
                        SUM(CASE WHEN d.status = 'Approved' THEN 1 ELSE 0 END) as approval_count,
                        SUM(CASE WHEN d.status = 'Revision' THEN 1 ELSE 0 END) as revision_count
                 FROM document_types dt
                 LEFT JOIN documents d ON dt.doc_type_id = d.doc_type_id
                 GROUP BY dt.doc_type_id, dt.doc_code, dt.description
                 ORDER BY revision_count DESC";

$stmt_analysis = $conn->prepare($sql_analysis);
$stmt_analysis->execute();
$result_analysis = $stmt_analysis->get_result();

$recommendations = [];
while ($row = $result_analysis->fetch_assoc()) {
    $approval_rate = $row['submission_count'] > 0 ? round(($row['approval_count'] / $row['submission_count']) * 100) : 0;
    
    $recommendation = '';
    $priority = 'low';

    if ($approval_rate < 70) {
        $recommendation = 'High revision rate. Consider providing clearer guidelines or templates.';
        $priority = 'high';
    } elseif ($approval_rate < 85) {
        $recommendation = 'Moderate revision rate. Review feedback patterns to improve document quality.';
        $priority = 'medium';
    } else {
        $recommendation = 'Good approval rate. Continue current guidelines.';
        $priority = 'low';
    }

    $recommendations[] = [
        'doc_code' => $row['doc_code'],
        'description' => $row['description'],
        'submission_count' => $row['submission_count'],
        'approval_rate' => $approval_rate,
        'revision_count' => $row['revision_count'],
        'recommendation' => $recommendation,
        'priority' => $priority
    ];
}

// Get officer compliance summary
$sql_officers = "SELECT o.office_id, o.office_name, o.office_code,
                        COUNT(DISTINCT u.user_id) as total_officers,
                        SUM(CASE WHEN oc.is_complied = 1 THEN 1 ELSE 0 END) as complied_officers
                 FROM offices o
                 LEFT JOIN users u ON o.office_id = u.office_id AND u.role IN ('Dean', 'Office')
                 LEFT JOIN officer_compliance oc ON u.user_id = oc.user_id 
                                                  AND oc.office_id = o.office_id
                                                  AND oc.quarter = ?
                                                  AND oc.year = ?
                 WHERE o.status = 'Active'
                 GROUP BY o.office_id, o.office_name, o.office_code
                 ORDER BY complied_officers DESC";

$stmt_officers = $conn->prepare($sql_officers);
$stmt_officers->bind_param("ss", $quarter, $year);
$stmt_officers->execute();
$result_officers = $stmt_officers->get_result();

$compliance_summary = [];
$total_all_officers = 0;
$total_complied = 0;

while ($row = $result_officers->fetch_assoc()) {
    $total_officers = $row['total_officers'] ?? 0;
    $complied = $row['complied_officers'] ?? 0;
    $compliance_rate = $total_officers > 0 ? round(($complied / $total_officers) * 100) : 0;

    $total_all_officers += $total_officers;
    $total_complied += $complied;

    $compliance_summary[] = [
        'office_id' => $row['office_id'],
        'office_name' => $row['office_name'],
        'office_code' => $row['office_code'],
        'total_officers' => $total_officers,
        'complied_officers' => $complied,
        'non_complied_officers' => $total_officers - $complied,
        'compliance_rate' => $compliance_rate
    ];
}

$overall_compliance = $total_all_officers > 0 ? round(($total_complied / $total_all_officers) * 100) : 0;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics & Compliance | UA QMS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="../../assets/js/messaging.js" defer></script>
    <script src="../../assets/js/notifications.js" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --ua-maroon: #800000;
            --ua-gold: #FFD700;
            --ua-green: #006400;
        }
        .bg-ua-maroon { background-color: var(--ua-maroon); }
        .text-ua-maroon { color: var(--ua-maroon); }
        .border-ua-maroon { border-color: var(--ua-maroon); }
    </style>
</head>
<body class="bg-gray-50 font-sans" data-user-role="<?php echo htmlspecialchars($_SESSION['role']); ?>">
    <script>localStorage.setItem('userRole', '<?php echo htmlspecialchars($_SESSION['role']); ?>');</script>
    <div class="flex h-screen overflow-hidden">
        <?php include "../../includes/sidebar_qmo.php"; ?>

        <!-- Main Content -->
        <main class="flex-1 flex flex-col overflow-hidden">
            <!-- Topbar -->
            <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 flex-shrink-0">
                <h1 class="text-xl font-bold text-gray-800">Analytics & Compliance</h1>
                <div class="flex items-center gap-6">
                    <div class="flex items-center gap-2">
                        <!-- Message Inbox -->
                        <button id="inbox-btn" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-envelope text-lg"></i>
                            <span id="message-badge" class="absolute top-1 right-1 w-4 h-4 bg-ua-maroon text-white text-[10px] flex items-center justify-center rounded-full hidden">0</span>
                        </button>
                        <!-- Notifications -->
                        <button id="notification-bell" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-bell text-lg"></i>
                            <span id="notification-badge" class="absolute top-1 right-1 min-w-[16px] h-4 px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center hidden">0</span>
                        </button>
                        <!-- Profile Dropdown -->
                        <div class="relative">
                            <button id="profile-btn" class="w-10 h-10 rounded-full bg-ua-maroon flex items-center justify-center text-white font-bold cursor-pointer hover:opacity-80 transition">
                                <?php echo isset($_SESSION['full_name']) ? substr($_SESSION['full_name'], 0, 1) : 'U'; ?>
                            </button>
                            <div id="profile-dropdown" class="profile-dropdown">
                                <div class="profile-dropdown-header">
                                    <p><?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></p>
                                    <span><?php echo htmlspecialchars($_SESSION['role'] ?? 'Role'); ?></span>
                                </div>
                                <a href="../../logout.php" class="profile-dropdown-item logout">
                                    <i class="fas fa-sign-out-alt"></i> Sign Out
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Page Content -->
            <div class="flex-1 overflow-auto p-8">
                <!-- Year Filter -->
                <div class="mb-6 flex gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Year</label>
                        <select onchange="changeYear(this.value)" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ua-maroon outline-none">
                            <?php for ($y = date('Y'); $y >= 2020; $y--): ?>
                                <option value="<?php echo $y; ?>" <?php echo $year == $y ? 'selected' : ''; ?>><?php echo $y; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>

                <!-- Key Metrics -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <p class="text-sm text-gray-600 mb-1">Total Submissions</p>
                        <h3 class="text-3xl font-bold text-gray-900"><?php echo $submissions_stats['total_submissions'] ?? 0; ?></h3>
                    </div>
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <p class="text-sm text-gray-600 mb-1">Approved</p>
                        <h3 class="text-3xl font-bold text-green-600"><?php echo $submissions_stats['approved'] ?? 0; ?></h3>
                    </div>
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <p class="text-sm text-gray-600 mb-1">Pending Review</p>
                        <h3 class="text-3xl font-bold text-orange-600"><?php echo $submissions_stats['pending'] ?? 0; ?></h3>
                    </div>
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <p class="text-sm text-gray-600 mb-1">Needs Revision</p>
                        <h3 class="text-3xl font-bold text-red-600"><?php echo $submissions_stats['revision'] ?? 0; ?></h3>
                    </div>
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <p class="text-sm text-gray-600 mb-1">Officer Compliance</p>
                        <h3 class="text-3xl font-bold text-ua-maroon"><?php echo $overall_compliance; ?>%</h3>
                    </div>
                </div>

                <!-- Charts Row -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                    <!-- Document Type Distribution -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h2 class="text-lg font-bold text-gray-800 mb-4">Document Type Distribution</h2>
                        <canvas id="docTypeChart"></canvas>
                    </div>

                    <!-- Submission Status -->
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h2 class="text-lg font-bold text-gray-800 mb-4">Submission Status</h2>
                        <canvas id="statusChart"></canvas>
                    </div>
                </div>

                <!-- Content Recommendations -->
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
                    <h2 class="text-lg font-bold text-gray-800 mb-6">Content Recommendations (System Analytics)</h2>
                    <div class="space-y-4">
                        <?php foreach ($recommendations as $rec): ?>
                            <div class="p-4 border-l-4 <?php echo $rec['priority'] === 'high' ? 'border-red-500 bg-red-50' : ($rec['priority'] === 'medium' ? 'border-orange-500 bg-orange-50' : 'border-green-500 bg-green-50'); ?> rounded">
                                <div class="flex justify-between items-start mb-2">
                                    <div>
                                        <h4 class="font-bold text-gray-900"><?php echo htmlspecialchars($rec['doc_code']); ?> - <?php echo htmlspecialchars($rec['description']); ?></h4>
                                        <p class="text-sm text-gray-600 mt-1">Approval Rate: <span class="font-semibold"><?php echo $rec['approval_rate']; ?>%</span> | Revisions: <span class="font-semibold"><?php echo $rec['revision_count']; ?></span></p>
                                    </div>
                                    <span class="px-3 py-1 rounded-full text-xs font-bold <?php echo $rec['priority'] === 'high' ? 'bg-red-200 text-red-800' : ($rec['priority'] === 'medium' ? 'bg-orange-200 text-orange-800' : 'bg-green-200 text-green-800'); ?>">
                                        <?php echo strtoupper($rec['priority']); ?>
                                    </span>
                                </div>
                                <p class="text-sm text-gray-700"><?php echo $rec['recommendation']; ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Top Performing Offices -->
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
                    <h2 class="text-lg font-bold text-gray-800 mb-6">Top Performing Offices</h2>
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead>
                                <tr class="bg-gray-50 border-b border-gray-200">
                                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Office</th>
                                    <th class="px-6 py-3 text-center text-sm font-semibold text-gray-700">Total Docs</th>
                                    <th class="px-6 py-3 text-center text-sm font-semibold text-gray-700">Approved</th>
                                    <th class="px-6 py-3 text-center text-sm font-semibold text-gray-700">Compliance Rate</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                <?php foreach ($offices as $office): ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="px-6 py-4">
                                            <div class="font-semibold text-gray-900"><?php echo htmlspecialchars($office['office_name']); ?></div>
                                            <div class="text-sm text-gray-600"><?php echo htmlspecialchars($office['office_code']); ?></div>
                                        </td>
                                        <td class="px-6 py-4 text-center">
                                            <span class="font-semibold text-gray-900"><?php echo $office['total_docs']; ?></span>
                                        </td>
                                        <td class="px-6 py-4 text-center">
                                            <span class="font-semibold text-green-600"><?php echo $office['approved_docs']; ?></span>
                                        </td>
                                        <td class="px-6 py-4 text-center">
                                            <span class="text-lg font-bold <?php echo $office['compliance_rate'] >= 80 ? 'text-green-600' : 'text-orange-600'; ?>">
                                                <?php echo $office['compliance_rate']; ?>%
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Officer Compliance Summary -->
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h2 class="text-lg font-bold text-gray-800 mb-6">Officer Compliance by Office (<?php echo htmlspecialchars($quarter); ?> <?php echo $year; ?>)</h2>
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead>
                                <tr class="bg-gray-50 border-b border-gray-200">
                                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">Office</th>
                                    <th class="px-6 py-3 text-center text-sm font-semibold text-gray-700">Total Officers</th>
                                    <th class="px-6 py-3 text-center text-sm font-semibold text-gray-700">Complied</th>
                                    <th class="px-6 py-3 text-center text-sm font-semibold text-gray-700">Non-Complied</th>
                                    <th class="px-6 py-3 text-center text-sm font-semibold text-gray-700">Compliance Rate</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                <?php foreach ($compliance_summary as $comp): ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="px-6 py-4">
                                            <div class="font-semibold text-gray-900"><?php echo htmlspecialchars($comp['office_name']); ?></div>
                                            <div class="text-sm text-gray-600"><?php echo htmlspecialchars($comp['office_code']); ?></div>
                                        </td>
                                        <td class="px-6 py-4 text-center">
                                            <span class="font-semibold text-gray-900"><?php echo $comp['total_officers']; ?></span>
                                        </td>
                                        <td class="px-6 py-4 text-center">
                                            <span class="font-semibold text-green-600"><?php echo $comp['complied_officers']; ?></span>
                                        </td>
                                        <td class="px-6 py-4 text-center">
                                            <span class="font-semibold text-red-600"><?php echo $comp['non_complied_officers']; ?></span>
                                        </td>
                                        <td class="px-6 py-4 text-center">
                                            <span class="text-lg font-bold <?php echo $comp['compliance_rate'] >= 80 ? 'text-green-600' : 'text-orange-600'; ?>">
                                                <?php echo $comp['compliance_rate']; ?>%
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        function changeYear(year) {
            window.location.href = 'analytics_dashboard.php?year=' + year;
        }

        // Document Type Chart
        const docTypeCtx = document.getElementById('docTypeChart').getContext('2d');
        new Chart(docTypeCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($doc_types, 'doc_code')); ?>,
                datasets: [{
                    label: 'Total Submissions',
                    data: <?php echo json_encode(array_column($doc_types, 'count')); ?>,
                    backgroundColor: '#800000',
                    borderColor: '#600000',
                    borderWidth: 1
                }, {
                    label: 'Approved',
                    data: <?php echo json_encode(array_column($doc_types, 'approved_count')); ?>,
                    backgroundColor: '#006400',
                    borderColor: '#004d00',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Status Chart
        const statusCtx = document.getElementById('statusChart').getContext('2d');
        new Chart(statusCtx, {
            type: 'doughnut',
            data: {
                labels: ['Approved', 'Pending', 'Revision', 'Rejected'],
                datasets: [{
                    data: [
                        <?php echo $submissions_stats['approved'] ?? 0; ?>,
                        <?php echo $submissions_stats['pending'] ?? 0; ?>,
                        <?php echo $submissions_stats['revision'] ?? 0; ?>,
                        <?php echo $submissions_stats['rejected'] ?? 0; ?>
                    ],
                    backgroundColor: ['#006400', '#FFA500', '#FF6347', '#DC143C'],
                    borderColor: ['#004d00', '#FF8C00', '#FF4500', '#8B0000'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    }
                }
            }
        });
    

                // Profile Dropdown Toggle
        const profileBtn = document.getElementById('profile-btn');
        const profileDropdown = document.getElementById('profile-dropdown');
        
        if (profileBtn && profileDropdown) {
            profileBtn.addEventListener('click', function() {
                profileDropdown.classList.toggle('active');
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(event) {
                if (!event.target.closest('#profile-btn') && !event.target.closest('#profile-dropdown')) {
                    profileDropdown.classList.remove('active');
                }
            });
        }
    </script>
</body>
</html>
