<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'QMO Admin'){ 
    header("Location: ../../index.php"); 
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UA QMS | Document Repository</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="../../assets/js/messaging.js" defer></script>
    <script src="../../assets/js/notifications.js" defer></script>
    <script src="../../assets/js/universal-file-viewer.js" defer></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');
        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background-color: #F9FAFB;
        }
        .bg-ua-maroon { background-color: #800000; }
        .text-ua-maroon { color: #800000; }
        
        .status-badge {
            font-size: 10px;
            font-weight: 700;
            padding: 4px 8px;
            border-radius: 9999px;
            text-transform: uppercase;
        }
        .status-approved { background-color: #f0fdf4; color: #16a34a; }
        .status-pending { background-color: #fff7ed; color: #ea580c; }
        .status-revision { background-color: #fefce8; color: #ca8a04; }
        
        .loading-spinner {
            border: 3px solid #f3f4f6;
            border-top: 3px solid #800000;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <?php include "../../includes/sidebar_qmo.php"; ?>

        <!-- Main Content -->
        <main class="flex-1 flex flex-col overflow-hidden">
            <!-- Topbar -->
            <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 flex-shrink-0 no-print">
                <h1 class="text-xl font-bold text-gray-800">Repository</h1>
                <div class="flex items-center gap-6">
                    <div class="flex items-center gap-2">
                        <!-- Message Inbox -->
                        <button id="inbox-btn" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-envelope text-lg"></i>
                            <span id="message-badge" class="absolute top-1 right-1 w-4 h-4 bg-[#800000] text-white text-[10px] flex items-center justify-center rounded-full hidden">0</span>
                        </button>
                        <!-- Notifications -->
                        <button id="notification-bell" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-bell text-lg"></i>
                            <span id="notification-badge" class="absolute top-1 right-1 min-w-[16px] h-4 px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center hidden">0</span>
                        </button>
                        <!-- Profile Dropdown -->
                        <div class="relative">
                            <button id="profile-btn" class="w-10 h-10 rounded-full bg-[#800000] flex items-center justify-center text-white font-bold cursor-pointer hover:opacity-80 transition">
                                <?php echo isset($_SESSION['full_name']) ? substr($_SESSION['full_name'], 0, 1) : 'U'; ?>
                            </button>
                            <div id="profile-dropdown" class="profile-dropdown">
                                <div class="profile-dropdown-header">
                                    <p><?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></p>
                                    <span><?php echo htmlspecialchars($_SESSION['role'] ?? 'Role'); ?></span>
                                </div>
                                <a href="../../logout.php" class="profile-dropdown-item logout">
                                    <i class="fas fa-sign-out-alt"></i> Sign Out
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Page Content -->
            <div class="flex-1 overflow-auto p-8">
                <div class="max-w-7xl mx-auto">
                    <!-- Header -->
                    <header class="mb-10 flex justify-between items-end no-print">
                        <div>
                            <h1 class="text-3xl font-bold text-gray-900">Document Repository</h1>
                            <p class="text-gray-500 mt-1">Centralized storage for all approved university quality documents</p>
                        </div>
                    </header>

                    <!-- Statistics Cards -->
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                            <p class="text-sm text-gray-500 font-medium mb-1">Total Documents</p>
                            <h3 id="stat-total" class="text-2xl font-bold text-gray-900">0</h3>
                            <div class="mt-2 text-xs text-gray-400 font-medium">In repository</div>
                        </div>
                        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                            <p class="text-sm text-gray-500 font-medium mb-1">Recent (7 Days)</p>
                            <h3 id="stat-recent" class="text-2xl font-bold text-green-600">0</h3>
                            <div class="mt-2 text-xs text-gray-400 font-medium">New uploads</div>
                        </div>
                        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                            <p class="text-sm text-gray-500 font-medium mb-1">Document Types</p>
                            <h3 id="stat-types" class="text-2xl font-bold text-blue-600">0</h3>
                            <div class="mt-2 text-xs text-gray-400 font-medium">Categories</div>
                        </div>
                        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                            <p class="text-sm text-gray-500 font-medium mb-1">Contributing Offices</p>
                            <h3 id="stat-offices" class="text-2xl font-bold text-purple-600">0</h3>
                            <div class="mt-2 text-xs text-gray-400 font-medium">Units</div>
                        </div>
                    </div>

                    <!-- Search and Filters -->
                    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6 no-print">
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                            <!-- Search Input -->
                            <div class="md:col-span-2">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Search Documents</label>
                                <div class="relative">
                                    <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"></i>
                                    <input type="text" id="search-input" placeholder="Search by file name, type, or office..." class="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#800000] focus:border-transparent outline-none text-sm">
                                </div>
                            </div>

                            <!-- Document Type Filter -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Document Type</label>
                                <select id="doc-type-filter" class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#800000] focus:border-transparent outline-none text-sm">
                                    <option value="">All Types</option>
                                </select>
                            </div>

                            <!-- Office Filter -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Office</label>
                                <select id="office-filter" class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#800000] focus:border-transparent outline-none text-sm">
                                    <option value="">All Offices</option>
                                </select>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="flex gap-3 justify-end">
                            <button id="reset-filters-btn" class="px-4 py-2 border border-gray-200 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 transition">
                                <i class="fas fa-times mr-2"></i> Reset
                            </button>
                            <button id="apply-filters-btn" class="px-4 py-2 bg-[#800000] text-white rounded-lg text-sm font-medium hover:bg-[#600000] transition">
                                <i class="fas fa-filter mr-2"></i> Apply Filters
                            </button>
                            <button onclick="window.print()" class="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition">
                                <i class="fas fa-print mr-2"></i> Print
                            </button>
                        </div>
                    </div>

                    <!-- Documents Table -->
                    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                        <div class="p-6 border-b border-gray-100">
                            <h3 class="font-bold text-gray-900">Approved Documents</h3>
                        </div>

                        <!-- Loading State -->
                        <div id="loading-state" class="p-12 text-center hidden">
                            <div class="flex justify-center mb-4">
                                <div class="loading-spinner"></div>
                            </div>
                            <p class="text-gray-500">Loading documents...</p>
                        </div>

                        <!-- Empty State -->
                        <div id="empty-state" class="p-12 text-center hidden">
                            <i class="fas fa-inbox text-4xl text-gray-300 mb-4"></i>
                            <p class="text-gray-500">No documents found matching your criteria</p>
                        </div>

                        <!-- Documents Table -->
                        <div class="overflow-x-auto">
                            <table class="w-full text-left" id="documents-table">
                                <thead>
                                    <tr class="bg-gray-50 text-gray-400 text-[10px] uppercase tracking-wider font-bold border-b border-gray-100">
                                        <th class="px-6 py-4">Document Name</th>
                                        <th class="px-6 py-4">Type</th>
                                        <th class="px-6 py-4">Office</th>
                                        <th class="px-6 py-4">Submitted</th>
                                        <th class="px-6 py-4 text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="documents-container" class="divide-y divide-gray-100">
                                    <!-- Documents will be loaded here -->
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <div id="pagination-container" class="p-6 border-t border-gray-100 flex items-center justify-between hidden">
                            <div class="text-sm text-gray-600">
                                Page <span id="current-page">1</span> of <span id="total-pages">1</span>
                            </div>
                            <div class="flex gap-2">
                                <button id="prev-page-btn" class="px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium hover:bg-gray-50 transition">Previous</button>
                                <button id="next-page-btn" class="px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium hover:bg-gray-50 transition">Next</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Profile Dropdown Styles -->
    <style>
        .profile-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            z-index: 50;
            min-width: 220px;
            margin-top: 8px;
        }
        .profile-dropdown.active {
            display: block;
        }
        .profile-dropdown-header {
            padding: 12px 16px;
            border-bottom: 1px solid #e5e7eb;
        }
        .profile-dropdown-header p {
            margin: 0;
            font-weight: 600;
            color: #111827;
            font-size: 14px;
        }
        .profile-dropdown-header span {
            display: block;
            font-size: 12px;
            color: #6b7280;
            margin-top: 2px;
        }
        .profile-dropdown-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            color: #374151;
            text-decoration: none;
            transition: background-color 0.2s;
            border: none;
            background: none;
            width: 100%;
            text-align: left;
            cursor: pointer;
            font-size: 14px;
        }
        .profile-dropdown-item:hover {
            background-color: #f3f4f6;
        }
        .profile-dropdown-item.logout {
            color: #dc2626;
            border-top: 1px solid #e5e7eb;
        }
        .profile-dropdown-item.logout:hover {
            background-color: #fee2e2;
        }
        .profile-dropdown-item i {
            margin-right: 12px;
            width: 16px;
            text-align: center;
        }
    </style>

    <script>
        let currentPage = 1;
        let currentFilters = {
            search: '',
            doc_type: '',
            office: '',
            status: 'Approved'
        };

        // Initialize repository
        async function initializeRepository() {
            await loadCategories();
            await loadStatistics();
            await loadDocuments();
        }

        // Load filter categories
        async function loadCategories() {
            try {
                const response = await fetch('../../api/repository_api.php?action=get_categories&type=all');
                const data = await response.json();

                if (data.success) {
                    // Populate document type filter
                    const docTypeSelect = document.getElementById('doc-type-filter');
                    data.doc_types.forEach(type => {
                        const option = document.createElement('option');
                        option.value = type.doc_code;
                        option.textContent = `${type.doc_code} - ${type.description}`;
                        docTypeSelect.appendChild(option);
                    });

                    // Populate office filter
                    const officeSelect = document.getElementById('office-filter');
                    data.offices.forEach(office => {
                        const option = document.createElement('option');
                        option.value = office.office_id;
                        option.textContent = `${office.office_code} - ${office.office_name}`;
                        officeSelect.appendChild(option);
                    });
                }
            } catch (error) {
                console.error('Error loading categories:', error);
            }
        }

        // Load repository statistics
        async function loadStatistics() {
            try {
                const response = await fetch('../../api/repository_api.php?action=get_repository_stats');
                const data = await response.json();

                if (data.success) {
                    document.getElementById('stat-total').textContent = data.total_documents;
                    document.getElementById('stat-recent').textContent = data.recent_uploads_7days;
                    document.getElementById('stat-types').textContent = data.by_type.length;
                    document.getElementById('stat-offices').textContent = data.by_office.length;
                }
            } catch (error) {
                console.error('Error loading statistics:', error);
            }
        }

        // Load documents with filters
        async function loadDocuments(page = 1) {
            currentPage = page;
            const params = new URLSearchParams({
                action: 'get_repository_documents',
                search: currentFilters.search,
                doc_type: currentFilters.doc_type,
                office: currentFilters.office,
                status: currentFilters.status,
                page: page,
                limit: 20
            });

            document.getElementById('loading-state').classList.remove('hidden');
            document.getElementById('documents-container').innerHTML = '';
            document.getElementById('empty-state').classList.add('hidden');
            document.getElementById('pagination-container').classList.add('hidden');

            try {
                const response = await fetch(`../../api/repository_api.php?${params}`);
                const data = await response.json();

                document.getElementById('loading-state').classList.add('hidden');

                if (data.success && data.documents.length > 0) {
                    renderDocuments(data.documents);
                    renderPagination(data.pagination);
                } else {
                    document.getElementById('empty-state').classList.remove('hidden');
                }
            } catch (error) {
                console.error('Error loading documents:', error);
                document.getElementById('loading-state').classList.add('hidden');
                document.getElementById('empty-state').classList.remove('hidden');
            }
        }

        // Render documents list
        function renderDocuments(documents) {
            const container = document.getElementById('documents-container');
            container.innerHTML = '';

            documents.forEach(doc => {
                const row = document.createElement('tr');
                row.className = 'hover:bg-gray-50 transition-colors';
                row.innerHTML = `
                    <td class="px-6 py-4">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-file text-gray-400"></i>
                            <div>
                                <div class="text-sm font-medium text-gray-900">${escapeHtml(doc.file_name)}</div>
                                <div class="text-xs text-gray-500">${formatDate(doc.submitted_at)}</div>
                            </div>
                        </div>
                    </td>
                    <td class="px-6 py-4">
                        <span class="text-sm font-medium text-gray-900">${doc.doc_code}</span>
                        <div class="text-xs text-gray-500">${doc.description}</div>
                    </td>
                    <td class="px-6 py-4">
                        <div class="text-sm font-medium text-gray-900">${doc.office_code}</div>
                        <div class="text-xs text-gray-500">${doc.office_name}</div>
                    </td>
                    <td class="px-6 py-4">
                        <div class="text-sm text-gray-600">${formatDate(doc.submitted_at)}</div>
                    </td>
                                        <td class="px-6 py-4 text-right">
                        <div class="flex justify-end gap-2">
                            <button onclick="openUniversalFileViewer(
                                `../../${doc.file_path.replace(/\\/g, '/')}`,
                                `../../${doc.preview_path ? doc.preview_path.replace(/\\/g, '/') : ''}`,
                                `${escapeHtml(doc.file_name)}`
                            )"
                                class="p-2 text-gray-400 hover:text-blue-600 transition" title="Preview">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </td>
                `;
                container.appendChild(row);
            });
        }

        // Render pagination controls
        function renderPagination(pagination) {
            if (pagination.total_pages > 1) {
                document.getElementById('pagination-container').classList.remove('hidden');
                document.getElementById('current-page').textContent = pagination.current_page;
                document.getElementById('total-pages').textContent = pagination.total_pages;

                document.getElementById('prev-page-btn').disabled = pagination.current_page === 1;
                document.getElementById('next-page-btn').disabled = pagination.current_page === pagination.total_pages;
            }
        }

        // Event listeners
        document.getElementById('apply-filters-btn').addEventListener('click', () => {
            currentFilters.search = document.getElementById('search-input').value;
            currentFilters.doc_type = document.getElementById('doc-type-filter').value;
            currentFilters.office = document.getElementById('office-filter').value;
            loadDocuments(1);
        });

        document.getElementById('reset-filters-btn').addEventListener('click', () => {
            document.getElementById('search-input').value = '';
            document.getElementById('doc-type-filter').value = '';
            document.getElementById('office-filter').value = '';
            currentFilters = { search: '', doc_type: '', office: '', status: 'Approved' };
            loadDocuments(1);
        });

        document.getElementById('prev-page-btn').addEventListener('click', () => {
            if (currentPage > 1) loadDocuments(currentPage - 1);
        });

        document.getElementById('next-page-btn').addEventListener('click', () => {
            loadDocuments(currentPage + 1);
        });

        // Enter key to search
        document.getElementById('search-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                document.getElementById('apply-filters-btn').click();
            }
        });

        // Helper functions
        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
        }

        function escapeHtml(text) {
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, m => map[m]);
        }





        // Profile Dropdown Toggle
        const profileBtn = document.getElementById('profile-btn');
        const profileDropdown = document.getElementById('profile-dropdown');
        
        if (profileBtn && profileDropdown) {
            profileBtn.addEventListener('click', function() {
                profileDropdown.classList.toggle('active');
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(event) {
                if (!event.target.closest('#profile-btn') && !event.target.closest('#profile-dropdown')) {
                    profileDropdown.classList.remove('active');
                }
            });
        }

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', initializeRepository);
    </script>
    <!-- Universal File Viewer Modal will be injected here by universal-file-viewer.js -->
</body>
</html>
