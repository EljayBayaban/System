<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'QMO Admin'){ 
    header("Location: ../../index.php"); 
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UA QMS | Real-time Monitoring</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="../../assets/js/messaging.js" defer></script>
    <script src="../../assets/js/notifications.js" defer></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body { font-family: 'Inter', sans-serif; }
        .status-badge {
            font-size: 10px;
            font-weight: 700;
            padding: 4px 8px;
            border-radius: 9999px;
            text-transform: uppercase;
        }
        .status-pending { background-color: #fff7ed; color: #ea580c; }
        .status-approved { background-color: #f0fdf4; color: #16a34a; }
        .status-revision { background-color: #fefce8; color: #ca8a04; }
        .status-rejected { background-color: #fef2f2; color: #dc2626; }
        .status-not-submitted { background-color: #f9fafb; color: #4b5563; }

        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #F9FAFB; }
        .bg-ua-maroon { background-color: #800000; }
        .text-ua-maroon { color: #800000; }
        .glass-card { background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(10px); border: 1px solid rgba(229, 231, 235, 0.5); }
        .chart-container { position: relative; height: 300px; width: 100%; }

    </style>
</head>
<body class="bg-gray-50">
    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <?php include "../../includes/sidebar_qmo.php"; ?>

        <!-- Main Content -->
        <main class="flex-1 flex flex-col overflow-hidden">
            <!-- Topbar -->
            <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 flex-shrink-0">
                <h1 class="text-xl font-bold text-gray-800">Monitoring</h1>
                <div class="flex items-center gap-6">
                    <div class="flex items-center gap-2">
                        <!-- Message Inbox -->
                        <button id="inbox-btn" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-envelope text-lg"></i>
                            <span id="message-badge" class="absolute top-1 right-1 w-4 h-4 bg-[#800000] text-white text-[10px] flex items-center justify-center rounded-full hidden">0</span>
                        </button>
                        <!-- Notifications -->
                        <button id="notification-bell" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-bell text-lg"></i>
                            <span id="notification-badge" class="absolute top-1 right-1 min-w-[16px] h-4 px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center hidden">0</span>
                        </button>
                        <!-- Profile Dropdown -->
                        <div class="relative">
                            <button id="profile-btn" class="w-10 h-10 rounded-full rounded-full bg-[#800000] flex items-center justify-center text-white font-bold cursor-pointer hover:opacity-80 transition">
                                <?php echo isset($_SESSION['full_name']) ? substr($_SESSION['full_name'], 0, 1) : 'U'; ?>
                            </button>
                            <div id="profile-dropdown" class="profile-dropdown">
                                <div class="profile-dropdown-header">
                                    <p><?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></p>
                                    <span><?php echo htmlspecialchars($_SESSION['role'] ?? 'Role'); ?></span>
                                </div>
                                <a href="../../logout.php" class="profile-dropdown-item logout">
                                    <i class="fas fa-sign-out-alt"></i> Sign Out
                                </a>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </header>

            <!-- Page Content -->
            <div class="flex-1 overflow-auto p-8">
                <div class="max-w-7xl mx-auto">
                    <header class="mb-10 flex justify-between items-end">
                        <div>
                            <h1 class="text-3xl font-bold text-gray-900">Real-time Monitoring</h1>
                            <p class="text-gray-500">Live tracking of document submissions across all university units.</p>
                        </div>
                        <div class="flex flex-col items-end gap-2">
                            <div class="flex items-center gap-2 text-sm font-medium text-green-600 bg-green-50 px-4 py-2 rounded-full border border-green-100">
                                <span class="relative flex h-3 w-3">
                                    <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                                    <span class="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                                </span>
                                Live System Status
                            </div>
                            <span id="last-updated" class="text-[10px] text-gray-400 font-medium uppercase tracking-wider">Last updated: --:--:--</span>
                        </div>
                    </header>

                    <!-- Stats Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">
                        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                            <p class="text-sm text-gray-500 font-medium mb-1">Total Submissions</p>
                            <h3 id="stat-total" class="text-2xl font-bold text-gray-900">0</h3>
                            <div class="mt-2 text-xs text-gray-400 font-medium">All time</div>
                        </div>
                        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                            <p class="text-sm text-gray-500 font-medium mb-1">Awaiting Review</p>
                            <h3 id="stat-pending" class="text-2xl font-bold text-orange-600">0</h3>
                            <div class="mt-2 text-xs text-gray-400 font-medium">Requires action</div>
                        </div>
                        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                            <p class="text-sm text-gray-500 font-medium mb-1">Approved Docs</p>
                            <h3 id="stat-approved" class="text-2xl font-bold text-green-600">0</h3>
                            <div class="mt-2 text-xs text-gray-400 font-medium">Compliance success</div>
                        </div>
                        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                            <p class="text-sm text-gray-500 font-medium mb-1">Overdue Files</p>
                            <h3 id="stat-overdue" class="text-2xl font-bold text-red-600">0</h3>
                            <div class="mt-2 text-xs text-red-600 font-bold">Critical alerts</div>
                        </div>
                    </div>

                    <!-- Recent Activity Table -->
                    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                        <div class="p-6 border-b border-gray-100 flex justify-between items-center">
                            <h3 class="font-bold text-gray-900">Recent Submission Activity</h3>
                            <div class="flex items-center gap-2">
                                <span class="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                                <span class="text-[10px] text-gray-400 font-bold uppercase">Monitoring Live</span>
                            </div>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left">
                                <thead>
                                    <tr class="bg-gray-50 text-gray-400 text-[10px] uppercase tracking-wider font-bold">
                                        <th class="px-8 py-4">Unit</th>
                                        <th class="px-8 py-4">Document</th>
                                        <th class="px-8 py-4">Time</th>
                                        <th class="px-8 py-4">Status</th>
                                        <th class="px-8 py-4 text-right">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="activity-table-body" class="divide-y divide-gray-100">
                                    <!-- Data will be loaded here -->
                                    <tr>
                                        <td colspan="5" class="px-8 py-10 text-center text-gray-400 italic">
                                            Loading real-time data...
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        lucide.createIcons();

        function fetchMonitoringData() {
            fetch('../../api/monitoring_api.php?action=get_monitoring_data')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update Stats
                        document.getElementById('stat-total').textContent = data.stats.total || 0;
                        document.getElementById('stat-pending').textContent = data.stats.pending || 0;
                        document.getElementById('stat-approved').textContent = data.stats.approved || 0;
                        document.getElementById('stat-overdue').textContent = data.stats.overdue || 0;
                        
                        // Update Last Updated
                        document.getElementById('last-updated').textContent = 'Last updated: ' + data.timestamp;

                        // Update Activity Table
                        const tbody = document.getElementById('activity-table-body');
                        if (data.activity.length === 0) {
                            tbody.innerHTML = '<tr><td colspan="5" class="px-8 py-10 text-center text-gray-400 italic">No recent activity found.</td></tr>';
                        } else {
                            let html = '';
                            data.activity.forEach(item => {
                                let statusClass = 'status-pending';
                                if (item.status === 'Approved') statusClass = 'status-approved';
                                if (item.status === 'Revision') statusClass = 'status-revision';
                                if (item.status === 'Rejected') statusClass = 'status-rejected';
                                if (item.status === 'Not Submitted') statusClass = 'status-not-submitted';

                                html += `
                                    <tr class="hover:bg-gray-50 transition-colors">
                                        <td class="px-8 py-4">
                                            <div class="font-bold text-gray-900 text-sm">${item.unit}</div>
                                            <div class="text-[10px] text-gray-400">${item.office_code}</div>
                                        </td>
                                        <td class="px-8 py-4">
                                            <div class="text-sm font-medium text-gray-700">${item.doc_name}</div>
                                            <div class="text-[10px] text-blue-600 font-bold">${item.doc_code}</div>
                                        </td>
                                        <td class="px-8 py-4 text-xs text-gray-500">${item.time_ago}</td>
                                        <td class="px-8 py-4">
                                            <span class="status-badge ${statusClass}">${item.status}</span>
                                        </td>
                                        <td class="px-8 py-4 text-right">
                                            <a href="review_submissions.php?id=${item.document_id}" class="p-2 text-gray-400 hover:text-[#800000]"><i data-lucide="eye" class="w-4 h-4"></i></a>
                                        </td>
                                    </tr>
                                `;
                            });
                            tbody.innerHTML = html;
                            lucide.createIcons();
                        }
                    }
                })
                .catch(error => {
                    console.error('Error fetching monitoring data:', error);
                });
        }

        // Initial fetch
        fetchMonitoringData();

        // Poll every 5 seconds
        setInterval(fetchMonitoringData, 5000);
    

                // Profile Dropdown Toggle
        const profileBtn = document.getElementById('profile-btn');
        const profileDropdown = document.getElementById('profile-dropdown');
        
        if (profileBtn && profileDropdown) {
            profileBtn.addEventListener('click', function() {
                profileDropdown.classList.toggle('active');
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(event) {
                if (!event.target.closest('#profile-btn') && !event.target.closest('#profile-dropdown')) {
                    profileDropdown.classList.remove('active');
                }
            });
        }
    </script>
</body>
</html>
