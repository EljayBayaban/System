<?php
session_start();
include "../../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'QMO Admin') {
    header("Location: ../../index.php");
    exit();
}

$conn->set_charset("utf8mb4");

/* =============================================================================
   SETTINGS
============================================================================= */

$sql_settings = "
SELECT setting_key, setting_value
FROM system_settings
WHERE setting_key IN ('active_academic_year','active_semester')
";

$result_settings = $conn->query($sql_settings);

$settings = [];

while ($row = $result_settings->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

$active_year = $settings['active_academic_year'] ?? date('Y') . '-' . (date('Y') + 1);
$active_semester = $settings['active_semester'] ?? '1st Semester';

$selected_year = htmlspecialchars($_GET['year'] ?? $active_year);
$selected_semester = htmlspecialchars($_GET['semester'] ?? $active_semester);

/* =============================================================================
   OVERVIEW STATS
============================================================================= */

$sql_stats = "
SELECT
COUNT(*) as total,
COUNT(CASE WHEN status='Awaiting Review' THEN 1 END) as pending,
COUNT(CASE WHEN status='Approved' THEN 1 END) as approved,
COUNT(CASE WHEN status='Revision' THEN 1 END) as revision,
COUNT(CASE WHEN status='Rejected' THEN 1 END) as rejected
FROM documents
";

$stats = $conn->query($sql_stats)->fetch_assoc();

/* =============================================================================
   OVERALL COMPLIANCE
============================================================================= */

$overall_sql = "
SELECT ROUND(AVG(compliance_rate)) as avg_comp
FROM (

SELECT
o.office_id,

(
COUNT(DISTINCT CASE WHEN d.status='Approved' THEN d.document_id END)
/
NULLIF(COUNT(DISTINCT dt.doc_type_id),0)
) * 100 as compliance_rate

FROM offices o

CROSS JOIN document_types dt

LEFT JOIN documents d
ON d.office_id = o.office_id
AND d.doc_type_id = dt.doc_type_id

WHERE o.status='Active'

GROUP BY o.office_id

) as compliance_table
";

$overall_comp = $conn->query($overall_sql)->fetch_assoc()['avg_comp'] ?? 0;

/* =============================================================================
   REVIEW TIME
============================================================================= */

$review_sql = "
SELECT
ROUND(AVG(DATEDIFF(review_date, submission_date)),1) as avg_review_days
FROM document_analytics
WHERE review_date IS NOT NULL
";

$review_data = $conn->query($review_sql)->fetch_assoc();

$avg_review_days = $review_data['avg_review_days'] ?? 0;

/* =============================================================================
   ACTIVE OFFICES
============================================================================= */

$active_offices_sql = "
SELECT COUNT(*) as total
FROM offices
WHERE status='Active'
";

$active_offices = $conn->query($active_offices_sql)->fetch_assoc()['total'] ?? 0;

/* =============================================================================
   RECENT ACTIVITY
============================================================================= */

$sql_activity = "
SELECT
o.office_name,
dt.doc_code,
d.status,
d.submitted_at

FROM documents d

JOIN offices o
ON d.office_id = o.office_id

JOIN document_types dt
ON d.doc_type_id = dt.doc_type_id

ORDER BY d.submitted_at DESC

LIMIT 10
";

$result_activity = $conn->query($sql_activity);

$activity = [];

while ($row = $result_activity->fetch_assoc()) {
    $activity[] = $row;
}

/* =============================================================================
   TREND CHART
============================================================================= */

$trend_sql = "
SELECT
year,
ROUND(AVG((total_submitted / NULLIF(total_required,0)) * 100)) as rate

FROM compliance_tracking

GROUP BY year

ORDER BY year ASC
";

$trend_res = $conn->query($trend_sql);

$trend_labels = [];
$trend_values = [];

while ($row = $trend_res->fetch_assoc()) {

    $trend_labels[] = $row['year'];
    $trend_values[] = $row['rate'];
}

/* =============================================================================
   BOTTLENECKS
============================================================================= */

$bn_sql = "
SELECT
dt.doc_code,
COUNT(d.document_id) as issues

FROM document_types dt

LEFT JOIN documents d
ON dt.doc_type_id = d.doc_type_id

WHERE d.status IN ('Awaiting Review','Revision','Rejected')

GROUP BY dt.doc_type_id

ORDER BY issues DESC

LIMIT 8
";

$bn_res = $conn->query($bn_sql);

$bottleneck_labels = [];
$bottleneck_values = [];

while ($row = $bn_res->fetch_assoc()) {

    $bottleneck_labels[] = $row['doc_code'];
    $bottleneck_values[] = $row['issues'];
}

/* =============================================================================
   TOP PERFORMING OFFICES
============================================================================= */

$units_sql = "
SELECT

o.office_name,

(
COUNT(DISTINCT CASE WHEN d.status='Approved' THEN d.document_id END)
/
NULLIF(COUNT(DISTINCT dt.doc_type_id),0)
) * 100 as rate

FROM offices o

CROSS JOIN document_types dt

LEFT JOIN documents d
ON o.office_id = d.office_id
AND dt.doc_type_id = d.doc_type_id

WHERE o.status='Active'

GROUP BY o.office_id

ORDER BY rate DESC

LIMIT 8
";

$units_res = $conn->query($units_sql);

$units = [];

while ($row = $units_res->fetch_assoc()) {

    $units[] = [
        'office' => $row['office_name'],
        'rate' => round($row['rate'])
    ];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Advanced QMO Dashboard</title>

<script src="https://cdn.tailwindcss.com"></script>
    <script>
        window.CURRENT_USER_ID = <?php echo json_encode($_SESSION['user_id']); ?>;
        window.CURRENT_USER_ROLE = <?php echo json_encode($_SESSION['role']); ?>;
    </script>
    <script src="../../assets/js/messaging.js" defer></script>
<script src="../../assets/js/notifications.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/countup.js@2.6.2/dist/countUp.umd.js"></script>
<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

:root {
    --ua-maroon: #800000;
    --ua-gold: #FFD700;
    --ua-green: #006400;
}

.bg-ua-maroon {
    background-color: var(--ua-maroon);
}

.text-ua-maroon {
    color: var(--ua-maroon);
}

.border-ua-maroon {
    border-color: var(--ua-maroon);
}

.metric-card{
    background:white;
    border-radius:24px;
    padding:24px;
    transition:0.3s;
    border:1px solid #e5e7eb;
}

.metric-card:hover{
    transform:translateY(-4px);
    box-shadow:0 15px 40px rgba(0,0,0,0.08);
}

.chart-card{
    background:white;
    border-radius:24px;
    padding:24px;
    border:1px solid #e5e7eb;
}

.chart-container{
    position:relative;
    height:350px;
}

.status-badge{
    padding:5px 12px;
    border-radius:999px;
    font-size:11px;
    font-weight:700;
}

.status-approved{
    background:#dcfce7;
    color:#166534;
}

.status-pending{
    background:#ffedd5;
    color:#c2410c;
}

.status-revision{
    background:#fef9c3;
    color:#a16207;
}

.status-rejected{
    background:#fee2e2;
    color:#b91c1c;
}

/* PROFILE DROPDOWN */

.profile-dropdown{
    position:absolute;
    right:0;
    top:55px;
    width:220px;
    background:white;
    border-radius:16px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    overflow:hidden;
    display:none;
    z-index:100;
}

.profile-dropdown.active{
    display:block;
}

.profile-dropdown-header{
    padding:16px;
    border-bottom:1px solid #eee;
}

.profile-dropdown-item{
    display:flex;
    gap:10px;
    padding:14px 16px;
    text-decoration:none;
    color:#333;
}

.profile-dropdown-item:hover{
    background:#f5f5f5;
}

</style>

</head>

<body class="bg-gray-100">

<div class="flex h-screen overflow-hidden">

<?php include "../../includes/sidebar_qmo.php"; ?>

<main class="flex-1 overflow-auto">

<!-- HEADER -->

<header class="bg-white border-b border-gray-200 px-8 py-5 flex justify-between items-center">

<div>

<h1 class="text-3xl font-bold text-gray-800">
QMO Analytics Dashboard
</h1>

<p class="text-gray-500 mt-1">
Enterprise Compliance Monitoring System
</p>

</div>

<div class="flex items-center gap-4">

<!-- CLOCK -->

<div id="clock"
class="text-sm text-gray-500 font-medium"></div>

<!-- MESSAGE -->

<button id="inbox-btn"
class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">

<i class="fas fa-envelope text-lg"></i>

<span id="message-badge"
class="absolute top-1 right-1 w-4 h-4 bg-ua-maroon text-white text-[10px] flex items-center justify-center rounded-full hidden">
0
</span>

</button>

<!-- NOTIFICATION -->

<button id="notification-bell"
class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">

<i class="fas fa-bell text-lg"></i>

<span id="notification-badge"
class="absolute top-1 right-1 min-w-[16px] h-4 px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center hidden">
0
</span>

</button>

<!-- PROFILE -->

<div class="relative">

<button id="profile-btn"
class="w-10 h-10 rounded-full bg-ua-maroon flex items-center justify-center text-white font-bold cursor-pointer hover:opacity-80 transition">

<?php echo isset($_SESSION['full_name']) ? substr($_SESSION['full_name'], 0, 1) : 'U'; ?>

</button>

<div id="profile-dropdown" class="profile-dropdown">

<div class="profile-dropdown-header">

<p class="font-semibold">
<?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?>
</p>

<span class="text-sm text-gray-500">
<?php echo htmlspecialchars($_SESSION['role'] ?? 'Role'); ?>
</span>

</div>

<a href="../../logout.php"
class="profile-dropdown-item">

<i class="fas fa-sign-out-alt"></i>

Sign Out

</a>

</div>

</div>

</div>

</header>

<!-- CONTENT -->

<div class="p-8 space-y-8">

<!-- FILTERS -->

<div class="bg-white rounded-2xl p-5 border border-gray-200">

<form method="GET" class="flex flex-wrap gap-4 items-center">

<!-- YEAR DROPDOWN -->

<select
name="year"
class="border border-gray-300 rounded-xl px-4 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-red-200">

<?php

$currentYear = date('Y');

for($i = $currentYear - 3; $i <= $currentYear + 3; $i++) {

    $yearOption = $i . '-' . ($i + 1);

?>

<option
value="<?= $yearOption ?>"
<?= $selected_year == $yearOption ? 'selected' : '' ?>>

<?= $yearOption ?>

</option>

<?php } ?>

</select>

<!-- SEMESTER DROPDOWN -->

<select
name="semester"
class="border border-gray-300 rounded-xl px-4 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-red-200">

<option
value="1st Semester"
<?= $selected_semester == '1st Semester' ? 'selected' : '' ?>>

1st Semester

</option>

<option
value="2nd Semester"
<?= $selected_semester == '2nd Semester' ? 'selected' : '' ?>>

2nd Semester

</option>

<option
value="Summer"
<?= $selected_semester == 'Summer' ? 'selected' : '' ?>>

Summer

</option>

</select>

<!-- APPLY BUTTON -->

<button
type="submit"
class="bg-[#800000] text-white px-6 py-2 rounded-xl hover:bg-red-900 transition duration-300 shadow-sm">

<i class="fas fa-filter mr-2"></i>
Apply Filters

</button>

<!-- RESET BUTTON -->

<a href="index.php"
class="bg-gray-200 text-gray-700 px-6 py-2 rounded-xl hover:bg-gray-300 transition duration-300 shadow-sm">

<i class="fas fa-rotate-left mr-2"></i>
Reset

</a>

</form>

</div>

</button>

</form>

</div>

<!-- EXECUTIVE SUMMARY -->

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

<div class="bg-green-50 border border-green-200 rounded-2xl p-6">

<div class="text-green-700 font-semibold">
Compliance Health
</div>

<div class="text-4xl font-bold text-green-900 mt-3">
<?= $overall_comp ?>%
</div>

<p class="text-green-700 mt-3 text-sm">
System-wide compliance performance
</p>

</div>

<div class="bg-yellow-50 border border-yellow-200 rounded-2xl p-6">

<div class="text-yellow-700 font-semibold">
Pending Reviews
</div>

<div class="text-4xl font-bold text-yellow-900 mt-3">
<?= $stats['pending'] ?>
</div>

<p class="text-yellow-700 mt-3 text-sm">
Documents awaiting validation
</p>

</div>

<div class="bg-red-50 border border-red-200 rounded-2xl p-6">

<div class="text-red-700 font-semibold">
Rejected Documents
</div>

<div class="text-4xl font-bold text-red-900 mt-3">
<?= $stats['rejected'] ?>
</div>

<p class="text-red-700 mt-3 text-sm">
Requires immediate attention
</p>

</div>

</div>

<!-- KPI -->

<div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">

<div class="metric-card">

<div class="flex justify-between">

<div>

<div class="text-gray-500 text-sm">
Total Submissions
</div>

<div id="totalCount"
class="text-4xl font-bold mt-3">
0
</div>

<div class="text-green-600 text-sm mt-3">
<i class="fas fa-arrow-up"></i>
12% increase
</div>

</div>

<div class="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center">

<i class="fas fa-file-upload text-2xl text-[#800000]"></i>

</div>

</div>

</div>

<div class="metric-card">

<div class="flex justify-between">

<div>

<div class="text-gray-500 text-sm">
Approved
</div>

<div id="approvedCount"
class="text-4xl font-bold mt-3 text-green-600">
0
</div>

<div class="text-green-600 text-sm mt-3">
High approval efficiency
</div>

</div>

<div class="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center">

<i class="fas fa-circle-check text-2xl text-green-600"></i>

</div>

</div>

</div>

<div class="metric-card">

<div class="flex justify-between">

<div>

<div class="text-gray-500 text-sm">
Avg Review Time
</div>

<div class="text-4xl font-bold mt-3 text-blue-600">
<?= $avg_review_days ?>d
</div>

<div class="text-blue-600 text-sm mt-3">
Processing efficiency
</div>

</div>

<div class="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center">

<i class="fas fa-clock text-2xl text-blue-600"></i>

</div>

</div>

</div>

<div class="metric-card">

<div class="flex justify-between">

<div>

<div class="text-gray-500 text-sm">
Active Offices
</div>

<div class="text-4xl font-bold mt-3 text-purple-600">
<?= $active_offices ?>
</div>

<div class="text-purple-600 text-sm mt-3">
Currently monitored
</div>

</div>

<div class="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center">

<i class="fas fa-building text-2xl text-purple-600"></i>

</div>

</div>

</div>

</div>

<!-- CHARTS -->

<div class="grid grid-cols-1 xl:grid-cols-2 gap-8">

<!-- TREND -->

<div class="chart-card">

<div class="flex justify-between items-center mb-6">

<h3 class="text-xl font-bold">
Compliance Trend
</h3>

<span class="text-sm text-gray-500">
5-Year Analysis
</span>

</div>

<div class="chart-container">
<canvas id="trendChart"></canvas>
</div>

</div>

<!-- BOTTLENECK -->

<div class="chart-card">

<div class="flex justify-between items-center mb-6">

<h3 class="text-xl font-bold">
Document Bottlenecks
</h3>

<span class="text-sm text-gray-500">
Problem Areas
</span>

</div>

<div class="chart-container">
<canvas id="bottleneckChart"></canvas>
</div>

</div>

</div>

<!-- LOWER GRID -->

<div class="grid grid-cols-1 xl:grid-cols-2 gap-8">

<!-- LIVE MONITORING -->

<div class="bg-white rounded-2xl border border-gray-200 overflow-hidden">

<div class="p-6 border-b flex justify-between items-center">

<h3 class="font-bold text-xl">
Live Submission Monitoring
</h3>

<div class="flex items-center gap-2">

<div class="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>

<span class="text-xs text-gray-500">
LIVE
</span>

</div>

</div>

<!-- SEARCH -->

<div class="px-6 pt-4">

<input type="text"
id="searchTable"
placeholder="Search office or document..."
class="w-full border border-gray-200 rounded-xl px-4 py-3">

</div>

<div class="overflow-x-auto">

<table class="w-full">

<thead class="bg-gray-50">

<tr class="text-gray-500 text-xs uppercase">

<th class="px-6 py-4 text-left">Office</th>
<th class="px-6 py-4 text-left">Document</th>
<th class="px-6 py-4 text-left">Status</th>
<th class="px-6 py-4 text-left">Date</th>

</tr>

</thead>

<tbody class="divide-y divide-gray-100">

<?php if(empty($activity)): ?>

<tr>

<td colspan="4"
class="text-center py-10 text-gray-400">

No recent activity found

</td>

</tr>

<?php endif; ?>

<?php foreach($activity as $item): ?>

<?php

$class = 'status-pending';

if($item['status'] == 'Approved'){
    $class = 'status-approved';
}

if($item['status'] == 'Revision'){
    $class = 'status-revision';
}

if($item['status'] == 'Rejected'){
    $class = 'status-rejected';
}

?>

<tr class="hover:bg-gray-50">

<td class="px-6 py-4 font-medium">
<?= htmlspecialchars($item['office_name']) ?>
</td>

<td class="px-6 py-4">
<?= htmlspecialchars($item['doc_code']) ?>
</td>

<td class="px-6 py-4">

<span class="status-badge <?= $class ?>">
<?= htmlspecialchars($item['status']) ?>
</span>

</td>

<td class="px-6 py-4 text-sm text-gray-500">
<?= date('M d, Y', strtotime($item['submitted_at'])) ?>
</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</div>

<!-- TOP OFFICES -->

<div class="bg-white rounded-2xl border border-gray-200 p-6">

<h3 class="text-xl font-bold mb-6">
Top Performing Offices
</h3>

<div class="space-y-5">

<?php foreach($units as $unit): ?>

<div>

<div class="flex justify-between mb-2">

<div class="font-semibold">
<?= htmlspecialchars($unit['office']) ?>
</div>

<div class="font-bold text-[#800000]">
<?= $unit['rate'] ?>%
</div>

</div>

<div class="w-full h-3 bg-gray-200 rounded-full overflow-hidden">

<div class="h-full bg-[#800000] rounded-full"
style="width:<?= $unit['rate'] ?>%">
</div>

</div>

</div>

<?php endforeach; ?>

</div>

</div>

</div>

</div>

</main>

</div>

<script>

/* =============================================================================
COUNTUP
============================================================================= */

window.addEventListener('DOMContentLoaded', () => {

new countUp.CountUp(
'totalCount',
<?= $stats['total'] ?>
).start();

new countUp.CountUp(
'approvedCount',
<?= $stats['approved'] ?>
).start();

});

/* =============================================================================
CLOCK
============================================================================= */

setInterval(() => {

document.getElementById('clock').innerText =
new Date().toLocaleString();

},1000);

/* =============================================================================
PROFILE DROPDOWN
============================================================================= */

const profileBtn = document.getElementById('profile-btn');
const profileDropdown = document.getElementById('profile-dropdown');

if(profileBtn && profileDropdown){

    profileBtn.addEventListener('click', function(e){

        e.stopPropagation();

        profileDropdown.classList.toggle('active');

    });

    document.addEventListener('click', function(e){

        if(
            !e.target.closest('#profile-btn') &&
            !e.target.closest('#profile-dropdown')
        ){
            profileDropdown.classList.remove('active');
        }

    });

}

/* =============================================================================
SEARCH TABLE
============================================================================= */

document.getElementById('searchTable')
.addEventListener('keyup', function(){

let value = this.value.toLowerCase();

document.querySelectorAll('tbody tr')
.forEach(row => {

row.style.display =
row.innerText.toLowerCase().includes(value)
? ''
: 'none';

});

});

/* =============================================================================
TREND CHART
============================================================================= */

const trendCtx = document.getElementById('trendChart');

const trendGradient = trendCtx
.getContext('2d')
.createLinearGradient(0,0,0,400);

trendGradient.addColorStop(0,'rgba(128,0,0,0.4)');
trendGradient.addColorStop(1,'rgba(128,0,0,0)');

new Chart(trendCtx, {

type:'line',

data:{

labels: <?= json_encode($trend_labels) ?>,

datasets:[

{
label:'Compliance Rate',
data: <?= json_encode($trend_values) ?>,
borderColor:'#800000',
backgroundColor:trendGradient,
fill:true,
tension:0.4,
pointRadius:5,
pointHoverRadius:7
},

{
label:'Target',
data:[85,85,85,85,85],
borderColor:'#f59e0b',
borderDash:[6,6]
}

]

},

options:{
responsive:true,
maintainAspectRatio:false,

plugins:{
legend:{
position:'top'
},
tooltip:{
enabled:true
}
},

animation:{
duration:1500
}

}

});

/* =============================================================================
BOTTLENECK CHART
============================================================================= */

const bottleneckCtx = document.getElementById('bottleneckChart');

new Chart(bottleneckCtx, {

type:'bar',

data:{

labels: <?= json_encode($bottleneck_labels) ?>,

datasets:[{

label:'Issues',
data: <?= json_encode($bottleneck_values) ?>,
backgroundColor:'#800000',
borderRadius:8

}]

},

options:{
responsive:true,
maintainAspectRatio:false,

plugins:{
legend:{
display:false
},
tooltip:{
enabled:true
}
},

animation:{
duration:1500
}

}

});

/* =============================================================================
REALTIME REFRESH
============================================================================= */

async function refreshDashboard(){

try{

const response =
await fetch('dashboard_data.php');

const data = await response.json();

document.getElementById('totalCount')
.innerText = data.total;

document.getElementById('approvedCount')
.innerText = data.approved;

}catch(error){

console.error(error);

}

}

setInterval(refreshDashboard,30000);

</script>

</body>
</html>