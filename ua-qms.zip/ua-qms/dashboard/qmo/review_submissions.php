<?php
session_start();
include "../../config/db.php";

/**
 * Helper function to trigger a notification
 */
function triggerNotification($user_id, $title, $message, $type = 'System', $conn) {
    $sql_notif = "INSERT INTO notifications (title, message, type) VALUES (?, ?, ?)";
    $stmt_notif = $conn->prepare($sql_notif);
    $stmt_notif->bind_param("sss", $title, $message, $type);
    
    if ($stmt_notif->execute()) {
        $notification_id = $conn->insert_id;
        $sql_user_notif = "INSERT INTO user_notifications (user_id, notification_id) VALUES (?, ?)";
        $stmt_user_notif = $conn->prepare($sql_user_notif);
        $stmt_user_notif->bind_param("ii", $user_id, $notification_id);
        return $stmt_user_notif->execute();
    }
    return false;
}

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'QMO Admin'){ 
    header("Location: ../../index.php"); 
    exit();
}

// Handle Approval or Rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $doc_id = $_POST['document_id'] ?? null;
    $action = $_POST['action'];
    $remarks = $_POST['remarks'] ?? '';
    
    if (!$doc_id) {
        $message = "Error: No document selected for review.";
    } else {
        $status = ($action === 'approve') ? 'Approved' : 'Revision';
        
        // Update document status
        $sql_update = "UPDATE documents SET status = ? WHERE document_id = ?";
        $stmt_upd = $conn->prepare($sql_update);
        $stmt_upd->bind_param("si", $status, $doc_id);
        
        if ($stmt_upd->execute()) {
            // Record review
            $sql_review = "INSERT INTO document_reviews (document_id, reviewed_by, remarks, review_status) VALUES (?, 'RMO', ?, ?)";
            $stmt_rev = $conn->prepare($sql_review);
            $stmt_rev->bind_param("iss", $doc_id, $remarks, $status);
            $stmt_rev->execute();
            
            $message = "Success: Document " . ($status === 'Approved' ? 'approved' : 'sent for revision') . " successfully.";
            
            // Get document details for notification
            $sql_doc_info = "SELECT d.office_id, dt.doc_code 
                             FROM documents d 
                             JOIN document_types dt ON d.doc_type_id = dt.doc_type_id 
                             WHERE d.document_id = ?";
            $stmt_doc = $conn->prepare($sql_doc_info);
            $stmt_doc->bind_param("i", $doc_id);
            $stmt_doc->execute();
            $doc_info = $stmt_doc->get_result()->fetch_assoc();
            $doc_code = $doc_info['doc_code'] ?? 'Document';
            $target_office_id = $doc_info['office_id'];

            // Trigger Notification for the Submitter (Dean)
            $notif_title = ($status === 'Approved') ? "Document Approved" : "Revision Required";
            $notif_msg = ($status === 'Approved') 
                ? "Your submission for " . $doc_code . " has been approved by QMO."
                : "Your submission for " . $doc_code . " requires revision. Remarks: " . $remarks;

            // Find the Unit/Office Head (Dean or Office role) of that office
            $sql_heads = "SELECT user_id FROM users WHERE office_id = ? AND role IN ('Dean', 'Office') AND status = 'Active'";
            $stmt_heads = $conn->prepare($sql_heads);
            $stmt_heads->bind_param("i", $target_office_id);
            $stmt_heads->execute();
            $heads_res = $stmt_heads->get_result();
            
            while ($head = $heads_res->fetch_assoc()) {
                // Create notification with routing metadata
                $sql_notif = "INSERT INTO notifications (title, message, type, target_url, target_type, related_document_id) VALUES (?, ?, ?, ?, ?, ?)";
                $stmt_notif = $conn->prepare($sql_notif);
                $target_url = "dashboard/dean/my_submissions.php";
                $target_type = ($status === 'Approved') ? "approval" : "revision";
                $notif_type = "System";
                $stmt_notif->bind_param("sssssi", $notif_title, $notif_msg, $notif_type, $target_url, $target_type, $doc_id);
                
                if ($stmt_notif->execute()) {
                    $notification_id = $conn->insert_id;
                    $sql_user_notif = "INSERT INTO user_notifications (user_id, notification_id) VALUES (?, ?)";
                    $stmt_user_notif = $conn->prepare($sql_user_notif);
                    $stmt_user_notif->bind_param("ii", $head['user_id'], $notification_id);
                    $stmt_user_notif->execute();
                }
            }
        } else {
            $message = "Error: Failed to update document status.";
        }
    }
}

// Get selected document ID from GET parameter (from monitoring page)
$selected_id = $_GET['id'] ?? null;
$selected_doc = null;

if ($selected_id) {
    $sql_selected = "SELECT d.*, dt.doc_code, dt.description as doc_type_desc, o.office_name, u.full_name as submitter_name 
                     FROM documents d 
                     JOIN document_types dt ON d.doc_type_id = dt.doc_type_id 
                     JOIN offices o ON d.office_id = o.office_id
                     LEFT JOIN users u ON o.office_id = u.office_id AND u.role = 'Dean'
                     WHERE d.document_id = ?";
    $stmt_sel = $conn->prepare($sql_selected);
    $stmt_sel->bind_param("i", $selected_id);
    $stmt_sel->execute();
    $selected_doc = $stmt_sel->get_result()->fetch_assoc();
}

// Fetch documents awaiting review
$sql_queue = "SELECT d.*, dt.doc_code, o.office_name, u.full_name as submitter_name 
              FROM documents d 
              JOIN document_types dt ON d.doc_type_id = dt.doc_type_id 
              JOIN offices o ON d.office_id = o.office_id
              LEFT JOIN users u ON o.office_id = u.office_id AND u.role = 'Dean'
              WHERE d.status = 'Awaiting Review'
              AND d.document_id IN (
                  SELECT MAX(document_id) 
                  FROM documents 
                  WHERE status = 'Awaiting Review' 
                  GROUP BY office_id, doc_type_id
              )
              ORDER BY d.submitted_at ASC";
$result_queue = $conn->query($sql_queue);
$queue_count = $result_queue->num_rows;

// If no document selected via GET, but there are items in queue, pick the first one
if (!$selected_doc && $queue_count > 0) {
    $result_queue->data_seek(0);
    $selected_doc = $result_queue->fetch_assoc();
    $result_queue->data_seek(0); // Reset for the while loop below
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UA QMS | Review Submissions</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="../../assets/js/messaging.js" defer></script>
    <script src="../../assets/js/notifications.js" defer></script>
    <link rel="stylesheet" href="../../assets/css/file-viewer.css">
    <script src="../../assets/js/file-viewer.js" defer></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body { font-family: 'Inter', sans-serif; }
        @media print {
            .no-print { display: none; }
            .print-only { display: block !important; }
        }
        .print-only { display: none; }
        .bg-ua-maroon { background-color: #800000; }
        .hover-bg-ua-maroon:hover { background-color: #600000; }
        /* File Viewer Modal Styles */
        #file-viewer-modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            align-items: center;
            justify-content: center;
        }
        #file-viewer-modal.active {
            display: flex;
        }
        .file-viewer-container {
            background-color: #fff;
            border-radius: 0.75rem;
            width: 95%;
            height: 95vh;
            max-width: 1200px;
            display: flex;
            flex-direction: column;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }
        .file-viewer-header {
            padding: 1rem;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #f9fafb;
        }
        .file-viewer-header h3 {
            font-weight: bold;
            color: #1f2937;
            margin: 0;
            word-break: break-word;
        }
        .file-viewer-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #6b7280;
            transition: color 0.3s;
        }
        .file-viewer-close:hover {
            color: #1f2937;
        }
        .file-viewer-content {
            flex: 1;
            overflow: auto;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f3f4f6;
        }
        .file-viewer-content iframe,
        .file-viewer-content img {
            max-width: 100%;
            max-height: 100%;
            width: auto;
            height: auto;
        }
        .file-viewer-error {
            color: #dc2626;
            font-weight: 500;
            text-align: center;
            padding: 2rem;
        }

        @media print {
            .no-print { display: none !important; }
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <?php include "../../includes/sidebar_qmo.php"; ?>

        <!-- Main Content -->
        <main class="flex-1 flex flex-col overflow-hidden">
            <!-- Topbar -->
            <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 flex-shrink-0 no-print">
                <h1 class="text-xl font-bold text-gray-800">Review Submissions</h1>
                <div class="flex items-center gap-6">
                    <div class="flex items-center gap-2">
                        <!-- Message Inbox -->
                        <button id="inbox-btn" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-envelope text-lg"></i>
                            <span id="message-badge" class="absolute top-1 right-1 w-4 h-4 bg-[#800000] text-white text-[10px] flex items-center justify-center rounded-full hidden">0</span>
                        </button>
                        <!-- Notifications -->
                        <button id="notification-bell" class="relative p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                            <i class="fas fa-bell text-lg"></i>
                            <span id="notification-badge" class="absolute top-1 right-1 min-w-[16px] h-4 px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center hidden">0</span>
                        </button>
                        <!-- Profile Dropdown -->
                        <div class="relative">
                            <button id="profile-btn" class="w-10 h-10 rounded-full bg-ua-maroon flex items-center justify-center text-white font-bold cursor-pointer hover:opacity-80 transition">
                                <?php echo isset($_SESSION['full_name']) ? substr($_SESSION['full_name'], 0, 1) : 'U'; ?>
                            </button>
                            <div id="profile-dropdown" class="profile-dropdown">
                                <div class="profile-dropdown-content">
                                    <p class="text-sm font-bold text-gray-800 px-4 py-2"><?php echo $_SESSION['full_name'] ?? 'User'; ?></p>
                                    <p class="text-xs text-gray-500 px-4 py-1"><?php echo $_SESSION['role'] ?? 'Role'; ?></p>
                                    <hr class="my-2">
                                    <a href="../../logout.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition">Logout</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <?php if (isset($message)): ?>
                <div class="px-8 py-4 <?php echo strpos($message, 'Error') !== false ? 'bg-red-50 border-red-200 text-red-800' : 'bg-blue-50 border-blue-200 text-blue-800'; ?> border-b text-sm font-medium">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <!-- Queue and Details Container -->
            <div class="flex-1 overflow-hidden flex gap-6 p-8">
                <!-- Queue Panel -->
                <div class="w-80 bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col overflow-hidden">
                    <div class="p-4 border-b border-gray-200 bg-gray-50">
                        <h2 class="font-bold text-lg text-gray-900 flex items-center gap-2">
                            <i data-lucide="inbox" class="w-5 h-5 text-[#800000]"></i>
                            Review Queue
                            <span class="ml-auto bg-[#800000] text-white text-xs px-2 py-1 rounded-full font-bold">
                                <?php echo $queue_count; ?>
                            </span>
                        </h2>
                    </div>
                    
                    <div class="flex-1 overflow-y-auto">
                        <?php if ($queue_count === 0): ?>
                            <div class="p-8 text-center text-gray-500">
                                <i data-lucide="check-circle" class="w-12 h-12 mx-auto mb-2 text-green-500"></i>
                                <p class="text-sm font-medium">All caught up!</p>
                                <p class="text-xs">No documents awaiting review.</p>
                            </div>
                        <?php else: ?>
                            <?php while ($row = $result_queue->fetch_assoc()): ?>
                                <a href="review_submissions.php?id=<?php echo $row['document_id']; ?>" 
                                   class="block p-4 border-b border-gray-100 hover:bg-gray-50 transition cursor-pointer <?php echo ($selected_doc && $selected_doc['document_id'] == $row['document_id']) ? 'bg-blue-50 border-l-4 border-l-[#800000]' : ''; ?>">
                                    <div class="mb-2">
                                        <p class="text-xs font-bold text-gray-500 uppercase"><?php echo htmlspecialchars($row['doc_code']); ?></p>
                                        <p class="text-sm font-bold text-gray-900"><?php echo htmlspecialchars($row['office_name']); ?></p>
                                    </div>
                                    <p class="text-xs text-gray-500">Submitted: <?php echo date('M d, Y', strtotime($row['submitted_at'])); ?></p>
                                </a>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Details Panel -->
                <div class="flex-1 bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col overflow-hidden">
                    <div class="p-6 border-b border-gray-200 bg-gray-50">
                        <h2 class="text-xl font-bold text-gray-900">Document Details</h2>
                        <p class="text-sm text-gray-500 mt-1">Review and approve or request revisions</p>
                    </div>
                    
                    <div class="flex-1 overflow-y-auto p-6">
                        <?php if ($selected_doc): ?>
                            <div class="space-y-8">
                                <!-- Document Info Card -->
                                <div class="bg-gray-50 rounded-xl p-6 border border-gray-200">
                                    <div class="flex justify-between items-start mb-6">
                                        <div>
                                            <span class="px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-full uppercase tracking-wider mb-2 inline-block">
                                                <?php echo htmlspecialchars($selected_doc['doc_code']); ?>
                                            </span>
                                            <h3 class="text-2xl font-bold text-gray-900"><?php echo htmlspecialchars($selected_doc['office_name']); ?></h3>
                                            <p class="text-gray-500 mt-1"><?php echo htmlspecialchars($selected_doc['doc_type_desc'] ?? 'Quality Document'); ?></p>
                                        </div>
                                        <div class="text-right">
                                            <p class="text-xs font-bold text-gray-400 uppercase">Submitted By</p>
                                            <p class="font-bold text-gray-900"><?php echo htmlspecialchars($selected_doc['submitter_name'] ?? 'Unit Head'); ?></p>
                                            <p class="text-xs text-gray-500"><?php echo date('F d, Y h:i A', strtotime($selected_doc['submitted_at'])); ?></p>
                                        </div>
                                    </div>

                                    <div class="flex items-center gap-4 p-4 bg-white rounded-lg border border-gray-200 group hover:border-[#800000] transition-colors">
                                        <div class="w-12 h-12 bg-red-50 rounded-lg flex items-center justify-center text-red-600">
                                            <i data-lucide="file-text" class="w-6 h-6"></i>
                                        </div>
                                        <div class="flex-1 min-w-0">
                                            <p class="text-sm font-bold text-gray-900 truncate"><?php echo htmlspecialchars($selected_doc['file_name']); ?></p>
                                            <p class="text-xs text-gray-500">Click to preview document</p>
                                        </div>
                                        <button onclick="openFileViewer('<?php echo htmlspecialchars($selected_doc['file_path']); ?>', '<?php echo htmlspecialchars($selected_doc['file_name']); ?>')" 
                                                class="px-4 py-2 bg-gray-100 text-gray-700 text-xs font-bold rounded-lg hover:bg-[#800000] hover:text-white transition-all">
                                            PREVIEW
                                        </button>
                                    </div>
                                </div>

                                <!-- Review Form -->
                                <div>
                                    <label class="block text-xs font-bold text-gray-600 uppercase mb-3">Review Remarks (Optional)</label>
                                    <form method="POST" id="review-form" class="space-y-4">
                                        <input type="hidden" name="document_id" value="<?php echo $selected_doc['document_id']; ?>">
                                        <textarea name="remarks" class="w-full p-4 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#800000] focus:border-transparent outline-none transition-all" 
                                                  placeholder="Add remarks for the submitter regarding approval or required revisions..." rows="5"></textarea>
                                        
                                        <div class="flex gap-4 pt-2">
                                            <button type="submit" name="action" value="revision" class="flex-1 px-6 py-4 border-2 border-amber-500 text-amber-600 font-bold rounded-xl hover:bg-amber-50 transition-all flex items-center justify-center gap-2">
                                                <i data-lucide="refresh-cw" class="w-5 h-5"></i>
                                                Request Revision
                                            </button>
                                            <button type="submit" name="action" value="approve" class="flex-1 px-6 py-4 bg-green-600 text-white font-bold rounded-xl hover:bg-green-700 transition-all shadow-lg flex items-center justify-center gap-2">
                                                <i data-lucide="check-circle" class="w-5 h-5"></i>
                                                Approve Document
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="h-full flex flex-col items-center justify-center text-gray-400">
                                <div class="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-4">
                                    <i data-lucide="mouse-pointer-2" class="w-10 h-10"></i>
                                </div>
                                <h3 class="text-lg font-bold text-gray-900">No Document Selected</h3>
                                <p class="text-sm">Select a document from the queue to begin review.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        lucide.createIcons();

        // Profile Dropdown Toggle
        const profileBtn = document.getElementById('profile-btn');
        const profileDropdown = document.getElementById('profile-dropdown');
        
        if (profileBtn && profileDropdown) {
            profileBtn.addEventListener('click', function() {
                profileDropdown.classList.toggle('active');
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(event) {
                if (!event.target.closest('#profile-btn') && !event.target.closest('#profile-dropdown')) {
                    profileDropdown.classList.remove('active');
                }
            });
        }
    </script>
</body>
</html>
