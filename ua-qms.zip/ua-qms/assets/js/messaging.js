/**
 * UA QMS Messaging System
 * Handles conversations, composing, and viewing messages in a Messenger-like interface.
 */

const Messaging = {
    unreadCount: 0,
    apiPath: '../../api/messages_api.php',
    currentConversationId: null,

    init: function() {
        this.updateUnreadCount();
        this.createMessagingModal();
        this.bindEvents();
        this.checkAdminPrivileges();
        
        // Check for unread messages and update conversations every 10 seconds
        setInterval(() => {
            this.updateUnreadCount();
            if (document.getElementById('conversations-list')) {
                this.loadConversations();
            }
            if (this.currentConversationId) {
                this.viewConversation(this.currentConversationId, false); // Reload current conversation without marking read again
            }
        }, 10000);
    },

    updateUnreadCount: function() {
        fetch(`${this.apiPath}?action=get_unread_count`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.unreadCount = data.unread_count;
                    const badge = document.getElementById('message-badge');
                    if (badge) {
                        if (this.unreadCount > 0) {
                            badge.textContent = this.unreadCount;
                            badge.classList.remove('hidden');
                        } else {
                            badge.classList.add('hidden');
                        }
                    }
                }
            });
    },

    createMessagingModal: function() {
        if (document.getElementById('messaging-modal')) return;

        const modalHtml = `
            <div id="messaging-modal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center">
                <div class="bg-white rounded-xl shadow-2xl w-full max-w-4xl h-[600px] flex flex-col overflow-hidden">
                    <!-- Modal Header -->
                    <div class="px-6 py-4 border-b border-gray-200 flex justify-between items-center bg-[#800000] text-white">
                        <h2 class="text-xl font-bold flex items-center gap-2">
                            <i class="fas fa-comments"></i> Messenger
                        </h2>
                        <button onclick="Messaging.toggleModal()" class="text-white hover:text-gray-200 transition">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>

                    <div class="flex flex-1 overflow-hidden">
                        <!-- Sidebar - Conversations List -->
                        <div class="w-80 border-r border-gray-200 bg-gray-50 flex flex-col">
                            <div class="p-4 border-b border-gray-200 space-y-2">
                                <button onclick="Messaging.showCompose()" class="w-full bg-[#800000] text-white py-2 rounded-lg font-bold shadow hover:opacity-90 transition flex items-center justify-center gap-2">
                                    <i class="fas fa-plus"></i> New Message
                                </button>
                                <div id="bulk-msg-btn-container" class="hidden">
                                    <button onclick="Messaging.showBulkCompose()" class="w-full bg-blue-600 text-white py-2 rounded-lg font-bold shadow hover:opacity-90 transition flex items-center justify-center gap-2">
                                        <i class="fas fa-bullhorn"></i> Bulk Message
                                    </button>
                                </div>
                            </div>
                            <div id="conversations-list" class="flex-1 overflow-y-auto">
                                <!-- Conversations will be loaded here -->
                                <div class="p-4 text-center text-gray-500">Loading conversations...</div>
                            </div>
                        </div>

                        <!-- Content Area - Chat Thread / Compose -->
                        <div id="messaging-content" class="flex-1 flex flex-col bg-white overflow-y-auto">
                            <div class="flex flex-col items-center justify-center h-full text-gray-400">
                                <i class="fas fa-comments text-6xl mb-4"></i>
                                <p>Select a conversation or start a new one</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    },

    toggleModal: function() {
        const modal = document.getElementById('messaging-modal');
        if (modal.classList.contains('hidden')) {
            modal.classList.remove('hidden');
            this.loadConversations();
        } else {
            modal.classList.add('hidden');
            this.currentConversationId = null; // Reset current conversation when closing modal
        }
    },

    bindEvents: function() {
        const inboxBtn = document.getElementById('inbox-btn');
        if (inboxBtn) {
            inboxBtn.onclick = (e) => {
                e.preventDefault();
                this.toggleModal();
            };
        }
    },

    loadConversations: function() {
        const conversationsList = document.getElementById('conversations-list');
        conversationsList.innerHTML = '<div class="p-4 text-center text-gray-500">Loading conversations...</div>';

        fetch(`${this.apiPath}?action=get_conversations`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if (data.conversations.length === 0) {
                        conversationsList.innerHTML = '<div class="p-4 text-center text-gray-500">No conversations yet.</div>';
                        return;
                    }

                    let html = '';
                    data.conversations.forEach(conv => {
                        const unreadClass = conv.unread_count > 0 ? 'font-bold bg-red-50 border-l-4 border-ua-maroon' : 'bg-gray-50';
                        html += `
                            <div onclick="Messaging.viewConversation(${conv.conversation_id}, true)" class="p-4 border-b border-gray-200 cursor-pointer hover:bg-gray-100 ${unreadClass}">
                                <div class="flex justify-between items-center mb-1">
                                    <span class="text-gray-900">${conv.last_message_sender_name}</span>
                                    <span class="text-xs text-gray-500">${new Date(conv.last_message_at).toLocaleString()}</span>
                                </div>
                                <p class="text-sm text-gray-600 truncate">${conv.last_message_text}</p>
                                ${conv.unread_count > 0 ? `<span class="text-xs text-white bg-ua-maroon px-2 py-0.5 rounded-full">${conv.unread_count} New</span>` : ''}
                            </div>
                        `;
                    });
                    conversationsList.innerHTML = html;
                }
            });
    },

    viewConversation: function(conversationId, markAsRead = true) {
        this.currentConversationId = conversationId;
        const content = document.getElementById('messaging-content');
        content.innerHTML = '<div class="flex justify-center py-10"><i class="fas fa-spinner fa-spin text-3xl text-ua-maroon"></i></div>';

        fetch(`${this.apiPath}?action=get_messages&conversation_id=${conversationId}`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let messagesHtml = '';
                    let lastMessageId = 0;
                    data.messages.forEach(msg => {
                        const isSender = msg.sender_id == this.getUserId(); // Assuming getUserId() exists or is implemented
                        const messageClass = isSender ? 'bg-ua-maroon text-white self-end' : 'bg-gray-200 text-gray-800 self-start';
                        const senderName = isSender ? 'You' : msg.sender_name;
                        messagesHtml += `
                            <div class="flex ${isSender ? 'justify-end' : 'justify-start'} mb-4">
                                <div class="max-w-xs lg:max-w-md px-4 py-2 rounded-lg shadow ${messageClass}">
                                    <p class="font-bold text-sm mb-1">${senderName}</p>
                                    <p class="text-sm">${msg.message_text}</p>
                                    <p class="text-xs text-right opacity-75 mt-1">${new Date(msg.created_at).toLocaleTimeString()} ${msg.status === 'sent' ? '<i class="fas fa-check"></i>' : '<i class="fas fa-check-double"></i>'}</p>
                                </div>
                            </div>
                        `;
                        lastMessageId = msg.message_id;
                    });

                    content.innerHTML = `
                        <div class="flex flex-col h-full">
                            <div class="flex-1 overflow-y-auto p-6 space-y-4" id="chat-thread">
                                ${messagesHtml}
                            </div>
                            <div class="p-4 border-t border-gray-200 bg-white">
                                <form id="chat-form" class="flex gap-2">
                                    <input type="hidden" name="conversation_id" value="${conversationId}">
                                    <textarea name="message_text" rows="1" class="flex-1 border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-ua-maroon focus:border-ua-maroon resize-none" placeholder="Type your message..."></textarea>
                                    <button type="submit" class="px-4 py-2 bg-ua-maroon text-white rounded-lg font-bold hover:opacity-90"><i class="fas fa-paper-plane"></i> Send</button>
                                </form>
                            </div>
                        </div>
                    `;
                    // Scroll to bottom
                    const chatThread = document.getElementById('chat-thread');
                    chatThread.scrollTop = chatThread.scrollHeight;

                    if (markAsRead && lastMessageId > 0) {
                        this.markAsRead(conversationId, lastMessageId);
                    }

                    document.getElementById('chat-form').onsubmit = (e) => {
                        e.preventDefault();
                        const formData = new FormData(e.target);
                        formData.append('action', 'send_message');
                        this.sendMessage(formData);
                        e.target.reset(); // Clear the input field
                    };
                }
            });
    },

    showCompose: function(replyToUserId = null) {
        this.currentConversationId = null; // No current conversation when composing new
        const content = document.getElementById('messaging-content');
        content.innerHTML = '<div class="flex justify-center py-10"><i class="fas fa-spinner fa-spin text-3xl text-ua-maroon"></i></div>';

        fetch(`${this.apiPath}?action=get_recipients`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let options = data.recipients.map(r => 
                        `<option value="${r.user_id}" ${replyToUserId == r.user_id ? 'selected' : ''}>${r.full_name}</option>`
                    ).join('');

                    content.innerHTML = `
                        <h3 class="text-lg font-bold mb-4 text-gray-800 p-6">New Message</h3>
                        <form id="compose-form" class="space-y-4 p-6">
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-1">Recipient</label>
                                <select name="receiver_id" class="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-ua-maroon focus:border-ua-maroon" required>
                                    <option value="">Select Recipient...</option>
                                    ${options}
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-1">Message</label>
                                <textarea name="message_text" rows="8" class="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-ua-maroon focus:border-ua-maroon" required placeholder="Type your message here..."></textarea>
                            </div>
                            <div class="flex justify-end gap-3">
                                <button type="button" onclick="Messaging.loadConversations()" class="px-6 py-2 border border-gray-300 rounded-lg font-bold hover:bg-gray-50">Cancel</button>
                                <button type="submit" class="px-6 py-2 bg-ua-maroon text-white rounded-lg font-bold hover:opacity-90">Send Message</button>
                            </div>
                        </form>
                    `;

                    document.getElementById('compose-form').onsubmit = (e) => {
                        e.preventDefault();
                        const formData = new FormData(e.target);
                        formData.append('action', 'send_message');
                        this.sendMessage(formData, true); // Pass true to indicate new conversation
                        e.target.reset();
                    };
                }
            });
    },

    sendMessage: function(formData, isNewConversation = false) {
        fetch(this.apiPath, {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                // alert('Message sent!'); // Remove alert for smoother UX
                if (isNewConversation) {
                    this.loadConversations();
                    this.viewConversation(data.conversation_id, true); // Open the new conversation
                } else {
                    this.viewConversation(formData.get('conversation_id'), false); // Reload current conversation
                }
                this.updateUnreadCount();
            } else {
                alert('Error: ' + data.message);
            }
        });
    },

    markAsRead: function(conversationId, lastMessageId) {
        const formData = new FormData();
        formData.append('action', 'mark_as_read');
        formData.append('conversation_id', conversationId);
        formData.append('last_message_id', lastMessageId);

        fetch(this.apiPath, {
            method: 'POST',
            body: formData
        }).then(() => this.updateUnreadCount());
    },

    checkAdminPrivileges: function() {
        // Check if the current user is QMO Admin to show Bulk Message button
        // We can check this by fetching the current user's role or checking a global variable
        if (window.CURRENT_USER_ROLE === 'QMO Admin') {
            const btn = document.getElementById('bulk-msg-btn-container');
            if (btn) btn.classList.remove('hidden');
        }
    },

    showBulkCompose: function() {
        this.currentConversationId = null;
        const content = document.getElementById('messaging-content');
        content.innerHTML = '<div class="flex justify-center py-10"><i class="fas fa-spinner fa-spin text-3xl text-ua-maroon"></i></div>';

        fetch(`${this.apiPath}?action=get_recipients`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let checkboxes = data.recipients.map(r => `
                        <label class="flex items-center gap-2 p-2 hover:bg-gray-50 rounded cursor-pointer border border-gray-100">
                            <input type="checkbox" name="receiver_ids[]" value="${r.user_id}" class="w-4 h-4 text-blue-600 rounded focus:ring-blue-500">
                            <span class="text-sm text-gray-700">${r.full_name} <span class="text-xs text-gray-400">(${r.role})</span></span>
                        </label>
                    `).join('');

                    content.innerHTML = `
                        <div class="flex flex-col h-full">
                            <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                                <h3 class="text-lg font-bold text-gray-800">Broadcast / Bulk Message</h3>
                                <p class="text-xs text-gray-500">Send a single message to multiple offices simultaneously.</p>
                            </div>
                            <form id="bulk-compose-form" class="flex-1 flex flex-col overflow-hidden">
                                <div class="p-6 flex-1 overflow-y-auto space-y-4">
                                    <div>
                                        <div class="flex justify-between items-center mb-2">
                                            <label class="block text-sm font-bold text-gray-700">Select Recipients</label>
                                            <div class="space-x-2">
                                                <button type="button" onclick="Messaging.selectAllRecipients(true)" class="text-xs text-blue-600 hover:underline">Select All</button>
                                                <button type="button" onclick="Messaging.selectAllRecipients(false)" class="text-xs text-gray-500 hover:underline">Clear All</button>
                                            </div>
                                        </div>
                                        <div class="grid grid-cols-1 md:grid-cols-2 gap-2 border border-gray-200 rounded-lg p-3 bg-white max-h-48 overflow-y-auto">
                                            ${checkboxes}
                                        </div>
                                    </div>
                                    <div class="flex-1 flex flex-col">
                                        <label class="block text-sm font-bold text-gray-700 mb-2">Message</label>
                                        <textarea name="message_text" class="flex-1 w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none min-h-[150px]" required placeholder="Type your broadcast message here..."></textarea>
                                    </div>
                                </div>
                                <div class="p-6 border-t border-gray-200 bg-gray-50 flex justify-end gap-3">
                                    <button type="button" onclick="Messaging.loadConversations()" class="px-6 py-2 border border-gray-300 rounded-lg font-bold hover:bg-gray-100">Cancel</button>
                                    <button type="submit" class="px-8 py-2 bg-blue-600 text-white rounded-lg font-bold shadow-lg hover:bg-blue-700 transition">
                                        <i class="fas fa-paper-plane mr-2"></i> Send Broadcast
                                    </button>
                                </div>
                            </form>
                        </div>
                    `;

                    document.getElementById('bulk-compose-form').onsubmit = (e) => {
                        e.preventDefault();
                        const formData = new FormData(e.target);
                        formData.append('action', 'send_bulk_message');
                        
                        // Check if at least one recipient is selected
                        const selected = e.target.querySelectorAll('input[name="receiver_ids[]"]:checked');
                        if (selected.length === 0) {
                            alert('Please select at least one recipient.');
                            return;
                        }

                        this.sendBulkMessage(formData);
                    };
                }
            });
    },

    selectAllRecipients: function(select) {
        const checkboxes = document.querySelectorAll('input[name="receiver_ids[]"]');
        checkboxes.forEach(cb => cb.checked = select);
    },

    sendBulkMessage: function(formData) {
        const submitBtn = document.querySelector('#bulk-compose-form button[type="submit"]');
        const originalContent = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Sending...';

        fetch(this.apiPath, {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert(data.message);
                this.loadConversations();
                const content = document.getElementById('messaging-content');
                content.innerHTML = `
                    <div class="flex flex-col items-center justify-center h-full text-green-500">
                        <i class="fas fa-check-circle text-6xl mb-4"></i>
                        <p class="text-lg font-bold">Broadcast Sent Successfully!</p>
                        <button onclick="Messaging.loadConversations()" class="mt-4 text-blue-600 hover:underline">Back to Conversations</button>
                    </div>
                `;
                this.updateUnreadCount();
            } else {
                alert('Error: ' + data.message);
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalContent;
            }
        })
        .catch(err => {
            alert('An error occurred. Please try again.');
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalContent;
        });
    },

    // Helper to get current user ID (assuming it's available globally or via a meta tag)
    getUserId: function() {
        // This needs to be dynamically set based on the logged-in user.
        // For now, returning a placeholder. In a real app, this would come from PHP session or a global JS var.
        // Example: return window.CURRENT_USER_ID; or similar.
        // For testing purposes, you might hardcode it or retrieve from a hidden input.
        // For this context, we'll assume the backend handles sender_id based on session.
        // However, for frontend display logic (isSender), we need the current user's ID.
        // Let's assume a global variable `CURRENT_USER_ID` is set by PHP.
        return window.CURRENT_USER_ID; 
    }
};

// Auto-initialize when the script loads
document.addEventListener('DOMContentLoaded', () => {
    Messaging.init();
});
