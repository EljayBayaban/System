/**
 * UA QMS Notification System
 * Handles notification bell, polling, dropdown, and click-through navigation.
 */

const Notifications = {
    unreadCount: 0,
    apiPath: '../../api/notifications_api.php',
    dropdownOpen: false,
    lastViewedCount: parseInt(localStorage.getItem('notifications_last_viewed_count') || '0'),

    init: function() {
        this.updateUnreadCount();
        this.createDropdown();
        this.bindEvents();
        
        // Check for new notifications every 30 seconds
        setInterval(() => this.updateUnreadCount(), 30000);
    },

    updateUnreadCount: function() {
        fetch(`${this.apiPath}?action=get_unread_count`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.unreadCount = data.unread_count;
                    const badge = document.getElementById('notification-badge');
                    if (badge) {
                        // Badge reset logic: only show count if it's more than what we last "viewed"
                        // or if the dropdown is currently closed and we have unread items.
                        const displayCount = Math.max(0, this.unreadCount - this.lastViewedCount);
                        
                        if (displayCount > 0 && !this.dropdownOpen) {
                            badge.textContent = displayCount;
                            badge.classList.remove('hidden');
                        } else {
                            badge.classList.add('hidden');
                        }
                    }
                }
            })
            .catch(err => console.error('Error fetching unread count:', err));
    },

    createDropdown: function() {
        if (document.getElementById('notification-dropdown')) return;

        const dropdownHtml = `
            <div id="notification-dropdown" class="fixed top-16 right-20 w-80 bg-white rounded-xl shadow-2xl z-50 hidden border border-gray-200 overflow-hidden">
                <div class="px-4 py-3 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
                    <h3 class="font-bold text-gray-800">Notifications</h3>
                    <button onclick="Notifications.markAllAsRead()" class="text-xs text-ua-maroon hover:underline">Mark all as read</button>
                </div>
                <div id="notification-list" class="max-h-96 overflow-y-auto">
                    <!-- Notifications will be injected here -->
                    <div class="p-4 text-center text-gray-400">
                        <i class="fas fa-bell-slash text-2xl mb-2 block"></i>
                        <p class="text-sm">No notifications</p>
                    </div>
                </div>
                <div class="p-2 border-t border-gray-100 text-center">
                    <button onclick="Notifications.navigateToActivityPage()" class="text-xs text-gray-500 hover:text-ua-maroon transition">View all activity</button>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', dropdownHtml);
    },

    bindEvents: function() {
        const bellBtn = document.getElementById('notification-bell');
        if (bellBtn) {
            bellBtn.onclick = (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.toggleDropdown();
            };
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            const dropdown = document.getElementById('notification-dropdown');
            const bellBtn = document.getElementById('notification-bell');
            if (dropdown && !dropdown.contains(e.target) && !bellBtn.contains(e.target)) {
                if (this.dropdownOpen) {
                    dropdown.classList.add('hidden');
                    this.dropdownOpen = false;
                }
            }
        });
    },

    toggleDropdown: function() {
        const dropdown = document.getElementById('notification-dropdown');
        if (this.dropdownOpen) {
            dropdown.classList.add('hidden');
            this.dropdownOpen = false;
        } else {
            dropdown.classList.remove('hidden');
            this.dropdownOpen = true;
            
            // Badge reset: when viewing, set lastViewedCount to current unreadCount
            this.lastViewedCount = this.unreadCount;
            localStorage.setItem('notifications_last_viewed_count', this.lastViewedCount);
            
            // Hide badge immediately
            const badge = document.getElementById('notification-badge');
            if (badge) badge.classList.add('hidden');
            
            this.loadNotifications();
        }
    },

    loadNotifications: function() {
        const list = document.getElementById('notification-list');
        list.innerHTML = '<div class="flex justify-center py-6"><i class="fas fa-spinner fa-spin text-xl text-ua-maroon"></i></div>';

        fetch(`${this.apiPath}?action=get_notifications`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    // Auto-clear: only show unread notifications
                    const unreadNotifications = data.notifications.filter(n => n.is_read == 0);
                    
                    if (unreadNotifications.length === 0) {
                        list.innerHTML = `
                            <div class="p-8 text-center text-gray-400">
                                <i class="fas fa-bell-slash text-3xl mb-2 block"></i>
                                <p class="text-sm">No new notifications</p>
                            </div>
                        `;
                        return;
                    }

                    let html = '';
                    unreadNotifications.forEach(notif => {
                        const iconClass = this.getIconForType(notif.type);
                        const targetUrl = notif.target_url || '';
                        
                        html += `
                            <div id="notif-item-${notif.user_notification_id}" class="p-4 border-b border-gray-50 hover:bg-gray-50 transition cursor-pointer bg-red-50" onclick="Notifications.handleNotificationClick(${notif.user_notification_id}, '${this.escapeQuotes(targetUrl)}')">
                                <div class="flex gap-3">
                                    <div class="flex-shrink-0 w-8 h-8 rounded-full bg-white flex items-center justify-center text-ua-maroon shadow-sm">
                                        <i class="${iconClass}"></i>
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-bold text-gray-900 truncate">${notif.title}</p>
                                        <p class="text-xs text-gray-600 line-clamp-2">${notif.message}</p>
                                        <p class="text-[10px] text-gray-400 mt-1">${this.formatTime(notif.notification_time)}</p>
                                    </div>
                                </div>
                            </div>
                        `;
                    });
                    list.innerHTML = html;
                }
            })
            .catch(err => {
                console.error('Error loading notifications:', err);
                list.innerHTML = '<div class="p-4 text-center text-red-500 text-sm">Failed to load notifications</div>';
            });
    },

    escapeQuotes: function(str) {
        return str.replace(/'/g, "\\'").replace(/"/g, '\\"');
    },

    getIconForType: function(type) {
        switch (type) {
            case 'Deadline': return 'fas fa-clock';
            case 'Announcement': return 'fas fa-bullhorn';
            case 'System': return 'fas fa-cog';
            default: return 'fas fa-bell';
        }
    },

    formatTime: function(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diff = Math.floor((now - date) / 1000);

        if (diff < 60) return 'Just now';
        if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
        if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
        return date.toLocaleDateString();
    },

    /**
     * Handle notification click: mark as read and navigate to target URL
     */
    handleNotificationClick: function(id, targetUrl) {
        // Mark as read
        this.markAsRead(id);
        
        // Navigate to target URL after a brief delay
        if (targetUrl && targetUrl.trim()) {
            setTimeout(() => {
                const absoluteUrl = this.resolveUrl(targetUrl);
                window.location.href = absoluteUrl;
            }, 300);
        }
    },

    /**
     * Resolve relative URLs to absolute paths
     */
    resolveUrl: function(relativeUrl) {
        // Handle different URL formats
        if (relativeUrl.startsWith('http')) {
            return relativeUrl; // Absolute URL
        }
        
        // Get the base path from current location
        const currentPath = window.location.pathname;
        const pathParts = currentPath.split('/');
        
        // Determine how many levels to go up based on current page
        let baseLevel = 0;
        if (currentPath.includes('/dashboard/qmo/')) {
            baseLevel = 2; // Go up 2 levels from /dashboard/qmo/
        } else if (currentPath.includes('/dashboard/dean/')) {
            baseLevel = 2; // Go up 2 levels from /dashboard/dean/
        } else {
            baseLevel = 1; // Default: go up 1 level
        }
        
        // Build the base path
        const basePath = pathParts.slice(0, pathParts.length - baseLevel).join('/');
        
        // Combine base path with relative URL
        return basePath + '/' + relativeUrl;
    },

    markAsRead: function(id) {
        const formData = new FormData();
        formData.append('user_notification_id', id);
        formData.append('action', 'mark_as_read');

        // Optimistic UI: remove immediately
        const item = document.getElementById(`notif-item-${id}`);
        if (item) {
            item.style.opacity = '0.5';
            item.style.pointerEvents = 'none';
        }

        fetch(this.apiPath, {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                // Update counts
                this.unreadCount--;
                this.lastViewedCount = Math.max(0, this.lastViewedCount - 1);
                localStorage.setItem('notifications_last_viewed_count', this.lastViewedCount);
                
                // Refresh list to show "No notifications" if empty
                this.loadNotifications();
                this.updateUnreadCount();
            }
        });
    },

    markAllAsRead: function() {
        const formData = new FormData();
        formData.append('action', 'mark_all_as_read');

        fetch(this.apiPath, {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                this.unreadCount = 0;
                this.lastViewedCount = 0;
                localStorage.setItem('notifications_last_viewed_count', '0');
                this.updateUnreadCount();
                this.loadNotifications();
            }
        });
    },

    /**
     * Navigate to the appropriate activity page based on user role
     */
    navigateToActivityPage: function() {
        // Get current page path to determine role context
        const currentPath = window.location.pathname;
        let targetUrl = '';
        
        if (currentPath.includes('/dashboard/qmo/')) {
            targetUrl = '../qmo/monitoring.php';
        } else if (currentPath.includes('/dashboard/dean/')) {
            targetUrl = '../dean/my_submissions.php';
        }
        
        if (targetUrl) {
            const absoluteUrl = this.resolveUrl(targetUrl);
            window.location.href = absoluteUrl;
        }
    }
};

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    Notifications.init();
});
