/**
 * UA QMS Universal File Viewer Component
 * Fixed Preview Transparency Issue
 */

class UniversalFileViewer {
    constructor() {
        this.modal = null;
        this.contentArea = null;
        this.titleArea = null;
        this.downloadBtn = null;
        this.initModal();
    }

    initModal() {
        let modal = document.getElementById("universal-file-viewer-modal");

        if (!modal) {
            const modalHtml = `
                <div id="universal-file-viewer-modal"
                     class="fixed inset-0 bg-black/70 z-[9999] hidden flex items-center justify-center p-4">

                    <div id="viewer-container"
                         class="bg-white rounded-2xl shadow-2xl w-full max-w-6xl h-[95vh] overflow-hidden flex flex-col">

                        <!-- Header -->
                        <div class="flex items-center justify-between px-6 py-4 border-b bg-gray-100">

                            <h3 id="universal-file-viewer-title"
                                class="font-bold text-gray-800 truncate">
                                Document Preview
                            </h3>

                            <div class="flex items-center gap-2">

                                <a id="universal-file-viewer-download"
                                   href="#"
                                   class="px-3 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition">
                                    <i class="fas fa-download"></i>
                                </a>

                                <button id="universal-file-viewer-close"
                                        class="px-3 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 transition">
                                    <i class="fas fa-times"></i>
                                </button>

                            </div>
                        </div>

                        <!-- Content -->
                        <div id="universal-file-viewer-content"
                             class="flex-1 bg-gray-200 overflow-auto flex items-center justify-center">

                            <div class="text-center">
                                <i class="fas fa-spinner fa-spin text-4xl text-gray-600 mb-3"></i>
                                <p class="text-gray-700">Loading preview...</p>
                            </div>

                        </div>
                    </div>
                </div>
            `;

            document.body.insertAdjacentHTML("beforeend", modalHtml);
            modal = document.getElementById("universal-file-viewer-modal");
        }

        this.modal = modal;
        this.contentArea = document.getElementById("universal-file-viewer-content");
        this.titleArea = document.getElementById("universal-file-viewer-title");
        this.downloadBtn = document.getElementById("universal-file-viewer-download");

        document
            .getElementById("universal-file-viewer-close")
            .addEventListener("click", () => this.closeViewer());

        this.modal.addEventListener("click", (e) => {
            if (e.target === this.modal) {
                this.closeViewer();
            }
        });

        document.addEventListener("keydown", (e) => {
            if (e.key === "Escape") {
                this.closeViewer();
            }
        });
    }

    openViewer(originalFilePath, previewFilePath, fileName) {

        if (!originalFilePath || originalFilePath === "undefined") {
            this.showError("File path is missing.");
            return;
        }

        this.modal.classList.remove("hidden");

        this.titleArea.textContent = fileName;

        this.downloadBtn.href = originalFilePath;
        this.downloadBtn.setAttribute("download", fileName);

        let previewPath = previewFilePath || originalFilePath;

        let extension = previewPath.split('.').pop().toLowerCase();

        if (extension === "pdf") {
            this.renderPdf(previewPath);

        } else if (["jpg","jpeg","png","gif","webp"].includes(extension)) {
            this.renderImage(previewPath);

        } else if (["mp4","webm","ogg"].includes(extension)) {
            this.renderVideo(previewPath);

        } else if (["mp3","wav"].includes(extension)) {
            this.renderAudio(previewPath);

        } else if (["txt","json","html","css","js","php","xml","md"].includes(extension)) {
            this.renderText(previewPath);

        } else {
            this.showError("Preview unavailable for this file type.");
        }
    }

    renderPdf(url) {
        this.contentArea.innerHTML = `
            <iframe
                src="${url}"
                class="w-full h-full bg-white"
                frameborder="0">
            </iframe>
        `;
    }

    renderImage(url) {
        this.contentArea.innerHTML = `
            <img
                src="${url}"
                class="max-w-full max-h-full object-contain"
                alt="Preview">
        `;
    }

    renderVideo(url) {
        this.contentArea.innerHTML = `
            <video controls class="w-full h-full bg-black">
                <source src="${url}">
            </video>
        `;
    }

    renderAudio(url) {
        this.contentArea.innerHTML = `
            <audio controls class="w-full max-w-xl">
                <source src="${url}">
            </audio>
        `;
    }

    renderText(url) {
        fetch(url)
            .then(response => response.text())
            .then(text => {
                this.contentArea.innerHTML = `
                    <pre class="w-full h-full overflow-auto p-4 bg-gray-900 text-green-400 text-sm text-left">
${this.escapeHtml(text)}
                    </pre>
                `;
            })
            .catch(() => {
                this.showError("Unable to load text preview.");
            });
    }

    showError(message) {
        this.contentArea.innerHTML = `
            <div class="text-center p-10">
                <i class="fas fa-exclamation-circle text-red-500 text-5xl mb-4"></i>
                <p class="text-lg font-semibold text-gray-700">${message}</p>
            </div>
        `;
    }

    closeViewer() {
        this.modal.classList.add("hidden");

        this.contentArea.innerHTML = `
            <div class="text-center">
                <i class="fas fa-spinner fa-spin text-4xl text-gray-600 mb-3"></i>
                <p class="text-gray-700">Loading preview...</p>
            </div>
        `;
    }

    escapeHtml(text) {
        return text
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;");
    }
}

document.addEventListener("DOMContentLoaded", () => {
    window.universalFileViewer = new UniversalFileViewer();
});

function openUniversalFileViewer(originalFilePath, previewFilePath, fileName) {
    window.universalFileViewer.openViewer(
        originalFilePath,
        previewFilePath,
        fileName
    );
}